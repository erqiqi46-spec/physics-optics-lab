# EXP-14 最终自动化验收报告

本报告只覆盖探究杠杆的平衡条件，不代表其他20项实验完成。

HTML SHA256：`554a3d2c2f865fe41e67d0bc7231b159ea2e14ecb59b31918ce0a594fd5e70cf`。71/71项数值/状态/教学评价单测通过；真实Chromium浏览器7/7项流程在同一构建上分两轮逐案通过。浏览器以file://加载，并在context.setOffline(true)下操作；无网络CDN、没有预录动画。构建成功是浏览器测试的前置门槛。

## 测试运行说明

首轮6项通过，倒计时案例因测试脚本同时打开第二个软件渲染页面而超时；已去掉重复的手机上下文（手机触摸另有独立用例），只重跑该案例并通过。应用HTML未修改，全部轨迹中的HTML哈希一致。保留browser-full-diagnostic.json及browser-timer-rerun.json原始报告，不将首轮失败改写为一次全绿。

## 教材与实现

正文105—106页（PDF110—111页），右F₁左F₂；见source-map.md。模式、评分、记录扩展、误差及归位是自拟教学设计，并非教材逐字或湖南官方细则。GLB为原创细化多部件器材，六个命名组件，见资产解析/PBR/有限顶点/尺度验证结果。2D图使用相同状态的角度、位置和力，力臂按垂直距离计算；杆和螺母自重也纳入力矩。

## 案例—脚本—截图—数值对照

全部浏览器脚本在tests/lever.spec.ts，每个测试只通过实际按钮、面板、鼠标/触摸执行，不使用写状态的测试接口。只读诊断提供实际GLB世界变换用于交叉核验。

|案例|可见现象截图（evidence/screenshots/）|数值/状态测试依据|
|---|---|---|
|规范流程+重复|01-standard-A.png / 02-standard-C.png / 03-standard-returned.png|physics/cases.test.ts规范A/B/C/重复；assessment有效轨迹|
|错误：未调平|04-error-untrimmed.png|cases.test.ts -0.0048N·m；空载核验单测|
|错误：斜杆用杆距当力臂|05-error-tilted-arm.png|30°时L=.12cos30°=.103923m|
|错误：左右侧别颠倒|06-error-sides.png|assessment错侧别核对actualsnapshot|
|极端参数|07-extreme-stop.png|6枚、28cm、螺母25mm；32°限位且非平衡|
|双向拖动|08-bidirectional-drag.png|constraints投影/步进/边界与真实GLB世界坐标|
|考核完整流程|09-exam-running.png / 10-exam-result.png|首次提交封存、控制变量配对、真实重复及归位得100/100|
|倒计时与恢复|11-timeout.png|store墙钟截止时间/模式隔离/持久化及超时锁定|
|手机触摸与720p|12-mobile.png / 13-mobile-touch.png / 14-desktop-720.png|原生touchStart/Move/End拖码；Enter等效移孔；宽度无溢出|

原始结果见evidence/browser-results.json、unit-results.json、numerical-cases.json、case-evidence.json；所有操作回放及轨迹见evidence/replay/。PNG是实际浏览器截图，不是效果图。

## 核心验收

- 3D直接装配、螺母及挂码拖动真实完成；UI同步，拖动不误转镜头。UI反向改变挂点后，实际GLB世界坐标被独立读取核验，不仅检查表单值。
- 同一配置和角度用于3D、受力图和读数；力臂不是倾斜杆距。机械挂点2cm步进、螺母1mm步进、各侧0—6件、限位±32°。触限静止不是平衡。
- 教学按有效不同条件、双向控制变量和真实重复推进，不靠重复点保存；自由模式不限时；考核参数只读，隐藏模型答案、即时正误颜色及乘积。考核备份与诊断也不直接给出expected模型读数。
- 15分钟默认配置及1分钟墙钟超时测试；刷新恢复和跨模式截止时间独立验证；交卷锁定读数/结论/权重，交卷后归位不能补实验分。实际器材全部归位后才展示评价。
- 一组实测规范轨迹完成100/100自定义模拟评分，逐项给出记录和事件编号；绝不是湖南省官方成绩。教学/自由模式只作证据回顾，不强制计分。
- 390×844手机触屏实际拖动及1280×720桌面无整页横向溢出，Tab/Enter等效操作可用。
- 实际GLB边界与最大角度/挂码堆叠计算未侵入桌面，见clearance-check.json。

## 测量与模型偏差

规范四行记录最大力读数偏差0.000000 N，最大长度偏差1.789e-7 m（相对于记录瞬间的模型垂直投影）。测试使用标称挂孔读数且已接近水平，这不是实物精度标定。显示三位小数是计算与单位统一，不表示尺的分度提高到1mm；实际刻度分度1cm、挂孔2cm。相对差定义为|F₁L₁−F₂L₂|/max(F₁L₁,F₂L₂)×100%，不等于真实仪器准确度；零载荷或未调平记录不能因乘积相等就判有效。

## 性能实测

环境：Chromium159 Linux headless, ANGLE SwiftShader; CPU/software rendering, not Windows/Edge real hardware。1440×1000，暖机后6个1秒窗口，录像关闭；原始样本在performance.json。

|画质|FPS中位数（最小—最大）|renderer.info调用数|三角形/帧|Chromium JS heap使用/分配 MiB|
|---|---:|---:|---:|---:|
| low | 16.8 (14.9–19.4) | 86 | 93480 | 33.2 / 45.6 |
| medium | 6.2 (2.5–11.3) | 86 | 93480 | 36.8 / 46.7 |
| high | 2.5 (0.7–3.9) | 86 | 93480 | 30.9 / 34.7 |

调用数为Three renderer.info本帧统计；不是操作系统GPU计数器。JS heap不含GPU显存，未虚报VRAM。高档使用PBR、环境反射、阴影及更高DPR；低档保留相同器材和模型，简化材质/阴影/DPR。软件渲染慢时应使用低档。不能把本次结果当作所有Windows电脑或手机的性能保证。

## 未验证项与局限

- 本次实测Linux Chromium159/SwiftShader；未获得Windows Chrome/Edge及真实Android/iOS设备实机，因此未伪称完成这些设备的实机性能验收。目标为现代Chrome/Edge的WebGL2标准浏览器，单文件file://路径已离线测试。
- 刚性单自由度近似，不模拟钩码摆动、杆挠曲、复杂惯性耦合；动态速率不作真实仪器标定。杆、螺母质量和重心等为明确设计假设。
- 原创GLB是教学器材设计，不是实物扫描/CAD认证。不宣称最终电影级或真实课堂学习效果已验证。
- 没有服务器身份验证与防篡改收卷；JSON只导出不导入，刷新恢复依赖本机存储。自定义评分权重需教师审核，建议总分>0。

最终判定：本报告列出的自动化案例、离线双向联动、科学边界及实际截图已通过；上述未验证项保持明确列出。
