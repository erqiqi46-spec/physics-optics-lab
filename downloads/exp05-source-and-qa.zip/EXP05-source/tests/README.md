# EXP-05 browser acceptance

Run `npm run build`, then `EXP05_BROWSER_RUN=final npm run test:browser` (Windows: set the environment variable with the shell's native syntax, or omit it: default final). Chromium must already be installed by Playwright; the delivered HTML itself needs no development tools.

Every scenario loads `dist/index.html` through `file://` with the browser context offline. HTTP(S) attempts and uncaught page errors fail acceptance. `window.__EXP05.read()` is used only to inspect state and projected apparatus locations; it never writes an answer or modifies the store. Actions are native UI controls, real mouse/touch pointer movements, or real keyboard input. Angle entries are independent manual records.

Scenarios cover: normative six rows and cleanup; incorrect normal, mirror angle reference, folded-screen misinterpretation and fabricated reading; normal-incidence hinge exception, 85° limit and backside; actual source, mirror knob and folding-screen drags plus two-way panel sync; complete exam with answers hidden until cleanup; persistence, mode isolation and absolute timeout; prediction/demo/takeover; native touch plus keyboard and responsive layouts. Desktop viewport is 1440×1000, additional 1280×720 and emulated mobile 390×844.

For timer tests only, Playwright's controlled clock advances the browser's time; the application still uses and persists its real deadline logic. Mobile touch is sent through Chromium's native input protocol, not synthetic DOM events. Emulation is not physical phone or Windows hardware certification.

Final screenshots and matching read-only snapshots are in `evidence/screenshots` and `evidence/cases`; `browser-case-evidence.json` includes the SHA256 of the HTML used. Videos and traces are retained. An additional mobile context writes its actual video into `evidence/mobile-replay`, while the fixture context trace also covers the 720p part of that case.

The initial run exposed a mode-unmount React DOM error and stale viewport picking targets after mobile scroll; those were reported and fixed in runtime before final acceptance. Initial and diagnostic runs are historical and must not be presented as final passes.
