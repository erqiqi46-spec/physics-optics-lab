import * as T from 'three';
import {GLTFExporter} from 'three/examples/jsm/exporters/GLTFExporter.js';
import {mergeGeometries,mergeVertices} from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import {writeFile,mkdir} from 'node:fs/promises';import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
if(!globalThis.FileReader)globalThis.FileReader=class{readAsArrayBuffer(b){b.arrayBuffer().then(x=>{this.result=x;this.onloadend?.()})}readAsDataURL(b){b.arrayBuffer().then(x=>{this.result=`data:${b.type};base64,${Buffer.from(x).toString('base64')}`;this.onloadend?.()})}};
const scene=new T.Group();scene.name='EXP05_OriginalReflectionApparatus';
const mat=(name,color,metalness,roughness)=>new T.MeshStandardMaterial({name,color,metalness,roughness});
const steel=mat('Satin stainless steel','#b4c4cb',.90,.22),aluminium=mat('Anodized aluminium','#7c929b',.83,.34),dark=mat('Midnight enamel','#183642',.6,.31),rubber=mat('Non marking rubber','#122027',0,.8),white=mat('Diffuse white optical screen','#dfe7df',0,.79),black=mat('Laser etched markings','#19323a',.1,.55),mint=mat('Mint index paint','#82ccb5',.1,.42),brass=mat('Brass precision adjuster','#c4a362',.88,.27),red=mat('Source status indicator red','#b34943',.1,.3);
const mirrorMat=new T.MeshPhysicalMaterial({name:'Protected silver optical mirror face',color:'#cadfe7',metalness:1,roughness:.045,clearcoat:1,clearcoatRoughness:.04});
const lens=new T.MeshPhysicalMaterial({name:'Source collimating optical glass',color:'#a3d7d6',metalness:0,roughness:.055,transmission:.65,thickness:.003,ior:1.5,transparent:true,opacity:.72});
const parts={};for(const n of['Mirror','ScreenLeft','ScreenRight','Source','Protractor','Stand']){parts[n]=new T.Group();parts[n].name=n;scene.add(parts[n])}let serial=0;
function mesh(g,geo,m,n,p=[0,0,0],r=[0,0,0]){const x=new T.Mesh(geo,m);x.name=n+' '+(++serial);x.position.set(...p);x.rotation.set(...r);x.castShadow=true;x.receiveShadow=true;g.add(x);return x}
function roundedShape(w,h,r){const s=new T.Shape(),x=-w/2,y=-h/2;s.moveTo(x+r,y);s.lineTo(x+w-r,y);s.quadraticCurveTo(x+w,y,x+w,y+r);s.lineTo(x+w,y+h-r);s.quadraticCurveTo(x+w,y+h,x+w-r,y+h);s.lineTo(x+r,y+h);s.quadraticCurveTo(x,y+h,x,y+h-r);s.lineTo(x,y+r);s.quadraticCurveTo(x,y,x+r,y);return s}
function panel(g,w,h,d,r,m,n,p=[0,0,0],rot=[0,0,0]){const geo=new T.ExtrudeGeometry(roundedShape(w,h,r),{depth:d,bevelEnabled:true,bevelSegments:2,steps:1,bevelSize:Math.min(.0007,d*.15),bevelThickness:Math.min(.0007,d*.15),curveSegments:7});geo.translate(0,0,-d/2);return mesh(g,geo,m,n,p,rot)}
function cyl(g,ra,rb,h,m,n,p=[0,0,0],rot=[0,0,0],seg=32){return mesh(g,new T.CylinderGeometry(ra,rb,h,seg),m,n,p,rot)}
function tor(g,r,t,m,n,p=[0,0,0],rot=[Math.PI/2,0,0]){return mesh(g,new T.TorusGeometry(r,t,6,40),m,n,p,rot)}
function screw(g,p,rot=[0,0,0]){const sub=new T.Group();sub.position.set(...p);sub.rotation.set(...rot);g.add(sub);cyl(sub,.0024,.0024,.0018,steel,'Captive screw');mesh(sub,new T.BoxGeometry(.0032,.0003,.0006),black,'Screw recessed drive',[0,.001,0]);}
function knurl(g,p,r,h,m=dark,rot=[0,0,0]){const sub=new T.Group();sub.position.set(...p);sub.rotation.set(...rot);g.add(sub);cyl(sub,r,r,h,m,'Precision knurled handwheel');for(let i=0;i<24;i++){let a=i*Math.PI/12;cyl(sub,.00045,.00045,h*.75,aluminium,'Fine knurled ribs',[Math.cos(a)*r,0,Math.sin(a)*r],[0,0,0],5)}return sub}
// Protected horizontal mirror: exact reflective face at local y=0. Different layers do not obscure it.
const mi=parts.Mirror;panel(mi,.710,.251,.009,.009,dark,'Radiused optical mirror backing',[0,-.009,0],[Math.PI/2,0,0]);panel(mi,.700,.240,.0014,.004,mirrorMat,'Silver mirror first surface',[0,-.0007,0],[Math.PI/2,0,0]);
const opticalFace=mi.children.find(x=>x.name.startsWith('Silver mirror first surface'));opticalFace.updateMatrixWorld(true);opticalFace.position.y-=new T.Box3().setFromObject(opticalFace).max.y;
for(const x of[-.352,.352])panel(mi,.006,.245,.004,.001,steel,'Mirror edge retaining strip',[x,-.001,0],[Math.PI/2,0,0]);
for(const x of[-.28,.28]){cyl(mi,.009,.011,.022,brass,'Mirror leveling spindle',[x,-.028,.071]);knurl(mi,[x,-.031,.071],.014,.009);tor(mi,.010,.0008,steel,'Leveling screw washer',[x,-.018,.071]);}
panel(mi,.490,.170,.012,.015,aluminium,'Beveled mirror carriage',[0,-.045,0],[Math.PI/2,0,0]);for(const x of[-.22,.22])for(const z of[-.06,.06]){cyl(mi,.012,.014,.009,rubber,'Mirror anti slip foot',[x,-.055,z]);screw(mi,[x,-.037,z]);}
for(const x of[-.330,.330])for(const z of[-.10,.10])screw(mi,[x,-.005,z]);
// Twin hinged scattering screens: fixed left x<0, folded right x>0, faces towards +Z.
for(const side of['Left','Right']){const g=parts['Screen'+side],sgn=side==='Left'?-1:1,cx=sgn*.21;
 panel(g,.416,.548,.008,.006,dark,'Screen structural backing',[cx,.275,-.009]);panel(g,.406,.536,.0018,.004,white,'Matte optical scattering face',[cx,.275,-.003]);
 for(const x of[cx-.199,cx+.199])panel(g,.003,.530,.001,.0005,aluminium,'Screen perimeter rail',[x,.275,-.001]);for(const y of[.012,.538])panel(g,.400,.003,.001,.0005,aluminium,'Screen horizontal perimeter rail',[cx,y,-.001]);
 for(const x of[cx-.190,cx+.190])for(const y of[.023,.526])screw(g,[x,y,-.0005],[Math.PI/2,0,0]);
 for(const y of[.07,.275,.48]){cyl(g,.006,.006,.049,brass,'Screen hinge knuckle',[0,y,-.009]);tor(g,.006,.0006,steel,'Hinge retaining ring',[0,y+.025,-.009]);}
 for(let i=0;i<=20;i++){let x=sgn*(.020+i*.018);mesh(g,new T.BoxGeometry(.0004,i%5===0?.008:.004,.00025),black,'Screen baseline distance ticks',[x,.022,-.0012]);}
 panel(g,.050,.018,.001,.002,mint,'Wing identifier inset',[sgn*.365,.504,-.0007]);
}
// Low-power enclosed LED slit ray box. Aperture at origin; outgoing axis local +Y.
const so=parts.Source;panel(so,.082,.139,.061,.012,dark,'Rounded optical source enclosure',[0,-.091,0]);panel(so,.079,.134,.002,.010,aluminium,'Source brushed cover',[0,-.091,.032]);
for(const x of[-.029,.029])for(const y of[-.140,-.043])screw(so,[x,y,.033],[Math.PI/2,0,0]);
for(let i=0;i<7;i++){panel(so,.004,.046,.001,.001,black,'Cooling ventilation slot',[-.025+i*.008,-.106,.034]);}
knurl(so,[.043,-.058,0],.010,.012,brass,[0,0,Math.PI/2]);cyl(so,.025,.025,.015,steel,'Lens retaining ferrule',[0,-.014,0]);tor(so,.024,.001,black,'Lens retainer polished lip',[0,-.006,0]);cyl(so,.021,.021,.002,lens,'Collimating source lens',[0,-.004,0]);panel(so,.010,.001,.036,.001,black,'Narrow slit mask',[0,-.001,0]);
cyl(so,.0022,.0022,.002,red,'Source power status lens',[.024,-.050,.034],[Math.PI/2,0,0],20);panel(so,.040,.014,.001,.002,ivory(),'Low power source information plate',[0,-.151,.034]);
function ivory(){return white}
// Protractor: engraved semicircle in xy, graduated 0..180 baseline x and normal +y.
const pr=parts.Protractor,rad=.32,shape=new T.Shape();shape.moveTo(-rad,0);shape.absarc(0,0,rad,Math.PI,0,true);shape.lineTo(-rad,0);
const geo=new T.ExtrudeGeometry(shape,{depth:.003,bevelEnabled:true,bevelSize:.0004,bevelThickness:.0004,bevelSegments:2,curveSegments:90});mesh(pr,geo,white,'Half circular engraved protractor substrate',[0,0,-.006]);
for(let d=0;d<=180;d++){const a=d*Math.PI/180,outer=.309,len=d%10===0?.021:d%5===0?.014:.007;const mid=outer-len/2;mesh(pr,new T.BoxGeometry(len,.00055,.0004),black,'One degree engraved protractor division',[Math.cos(a)*mid,Math.sin(a)*mid,-.0025],[0,0,a]);}
for(const r of[.275,.312]){const curve=new T.EllipseCurve(0,0,r,r,0,Math.PI,false,0),points=curve.getPoints(120).map(v=>new T.Vector3(v.x,v.y,-.0023));mesh(pr,new T.TubeGeometry(new T.CatmullRomCurve3(points),120,.0003,4,false),black,'Protractor concentric engraved reference arc');}
mesh(pr,new T.BoxGeometry(.636,.001,.0004),black,'Mirror baseline index',[0,.001,-.002]);mesh(pr,new T.BoxGeometry(.001,.318,.0004),mint,'Normal reference engraved index',[0,.159,-.002]);tor(pr,.006,.0005,black,'Protractor center crosshair',[0,0,-.002],[0,0,0]);
// Broad tabletop stand with separate articulated screen hinge mounting support behind apparatus.
const st=parts.Stand;panel(st,.900,.460,.025,.035,dark,'Optics instrument display plinth',[0,-.092,-.015],[Math.PI/2,0,0]);panel(st,.887,.447,.002,.030,aluminium,'Plinth machined edge trim',[0,-.078,-.015],[Math.PI/2,0,0]);panel(st,.875,.435,.001,.028,dark,'Plinth recessed top deck',[0,-.076,-.015],[Math.PI/2,0,0]);
for(const x of[-.365,.365])for(const z of[-.175,.145]){cyl(st,.025,.028,.016,rubber,'Adjustable plinth leveling foot',[x,-.110,z]);tor(st,.024,.001,steel,'Foot calibration rim',[x,-.102,z]);}
for(const x of[-.38,.38])for(const z of[-.18,.15])screw(st,[x,-.074,z]);
for(const x of[-.25,.25]){panel(st,.065,.090,.018,.008,steel,'Screen rear mounting clamp',[x,-.045,-.102],[Math.PI/2,0,0]);cyl(st,.006,.006,.075,steel,'Screen mounting pin',[x,-.015,-.095]);knurl(st,[x,-.035,-.152],.013,.012,dark,[Math.PI/2,0,0]);}
scene.updateMatrixWorld(true);const components={};for(const[name,g]of Object.entries(parts)){const buckets=new Map();let count=0;g.traverse(o=>{if(!o.isMesh)return;count++;let geo=o.geometry.clone().applyMatrix4(o.matrixWorld);if(!geo.index)geo=mergeVertices(geo);const a=buckets.get(o.material)||[];a.push(geo);buckets.set(o.material,a)});g.clear();for(const[m,geos]of buckets)mesh(g,mergeGeometries(geos,false),m,name+' / '+m.name);components[name]=count;g.userData={unit:'metre',components:count};}
scene.updateMatrixWorld(true);const glb=await new GLTFExporter().parseAsync(scene,{binary:true});await mkdir(root+'src/assets',{recursive:true});await writeFile(root+'src/assets/instruments.glb',Buffer.from(glb));
const inventory={asset:'instruments.glb',provenance:'Original compound models authored by reproducible script; no downloaded models or textures',unit:'metre',bytes:glb.byteLength,totalTriangles:0,totalMeshes:0,roots:{},coordinates:{mirror:'surface y=0; width0.7 x depth0.24; local x baseline, +y normal; scene rotates root around z for mirror angle',screen:'ScreenLeft x[-.42,0]; ScreenRight x[0,.42]; y[0,.55]; matte face z=-.0021; root origin hinge at (0,0,0); rotate ScreenRight around local y',source:'emission aperture at origin; emitted ray along local +Y; enclosure extends towards -Y',protractor:'xy halfcircle radius.32; baseline x-axis, normal+y; division1deg, major10deg; add dynamic numeric labels in app at radius.261,z=-.001',stand:'deck y=-.075; default shown under mirror'}};
for(const[name,g]of Object.entries(parts)){let triangles=0,meshes=0;g.traverse(o=>{if(o.isMesh){meshes++;triangles+=(o.geometry.index?.count||o.geometry.attributes.position.count)/3}});const b=new T.Box3().setFromObject(g);inventory.roots[name]={components:components[name],meshes,triangles,min:b.min.toArray(),max:b.max.toArray()};inventory.totalMeshes+=meshes;inventory.totalTriangles+=triangles;}
await writeFile(root+'src/assets/asset-inventory.json',JSON.stringify(inventory,null,2));console.log(JSON.stringify(inventory,null,2));
