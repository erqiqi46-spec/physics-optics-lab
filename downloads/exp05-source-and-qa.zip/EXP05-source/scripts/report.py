from pathlib import Path
import json,hashlib,shutil,datetime
R=Path(__file__).resolve().parents[1];E=R/'evidence'
def read(p):return json.loads((R/p).read_text())
h=hashlib.sha256((R/'dist/index.html').read_bytes()).hexdigest();u=read('evidence/unit-results.json');b=read('evidence/browser-results-final.json');p=read('evidence/performance.json');t=read('evidence/trace-build-identity.json');n=read('evidence/browser-numerical-validation.json');v=read('evidence/visual-review.json')
assert u['success'] and u['numPassedTests']==50
assert b['stats']['expected']==8 and not any(b['stats'][k] for k in ['unexpected','skipped','flaky']) and not b['errors']
assert t['allMatched'] and t['traceCount']==8 and t['finalSha256']==h
assert n['passed'] and n['htmlSha256']==h and v['passed'] and v['htmlSha256']==h
assert read('src/physics/numerical-cases.json')['passed'] and read('src/assets/asset-validation.json')['passed']
assert p['htmlSha256']==h and all(not x['errors'] and not x['remoteRequests'] for x in p['results'])
start=datetime.datetime.fromisoformat(b['stats']['startTime'].replace('Z','+00:00')).timestamp();assert (R/'dist/index.html').stat().st_mtime<=start
rep=E/'replay';rep.mkdir(exist_ok=True);cases=[]
def walk(s):
 for spec in s.get('specs',[]):
  cases.append(spec['title']);idx=len(cases)
  for test in spec['tests']:
   assert test['status']=='expected'
   for a in test['results'][-1].get('attachments',[]):
    if a['name'] in ['video','trace']:
     f=Path(a['path']);shutil.copyfile(f,rep/f'{idx:02d}-{a["name"]}{f.suffix}')
 for sub in s.get('suites',[]):walk(sub)
for s in b['suites']:walk(s)
mobile=[x for x in (E/'mobile-replay').rglob('*.webm') if x.stat().st_mtime>=start]
assert mobile;shutil.copyfile(max(mobile,key=lambda x:x.stat().st_mtime),rep/'08-mobile-actual.webm')
assert len(list(rep.glob('*.zip')))==8
shots=read('evidence/browser-case-evidence.json');assert all(x['htmlSha256']==h for x in shots)
report=f'''# EXP-05 探究光的反射定律：验收报告

交付HTML SHA256：`{h}`。仅对应本构建，不是湖南官方评分、Windows硬件认证或教学效果研究。

## 最终验证结果

- Vitest：50/50通过，涵盖反射向量、角度、可逆、屏面几何、背面与正入射边界、实际参数约束及三模式评价。
- Chromium真实浏览器：8/8通过，无跳过、意外失败或重试通过；file://断网运行，无远程请求和未处理页面错误。
- 8份trace内HTML与交付哈希一致；{len(shots)}张最终截图及状态；{len(n['checks'])}项独立数值/渲染参数核对通过。原始误差和容差见evidence/browser-numerical-validation.json。
- 10组确定性物理案例通过。角度公式误差检查容差1e-8°，不是声称仪器可测量到这些小数位；量角器按1°分度读数，手填容差0.51°。
- 原创GLB验证通过：35,844三角形、37个材质合并网格，无外部buffer或图片。不是实拍扫描资产；无原始几何体占位器材。
- 极端±25°镜面AABB到台面的保守净空全范围超过0.12m；支架底部落在台面上方不足1mm。浏览器极端姿态有可见截图与数值断言。

## 真实浏览器案例

'''+ '\n'.join(f'{i+1}. {c}' for i,c in enumerate(cases))+'''

测试通过真实点击、鼠标/原生触摸拖动、键盘、量角器微调、手填记录执行；读取状态仅用于断言，未注入store写入来绕过操作。回放是自动化真实浏览器录制，不替代可操作HTML。手机使用Chromium触摸设备仿真，不是手机硬件实测。

初版发现模式卸载DOM错误及手机滚动后测试命中坐标过期；已移除DOM型3D标签并改为GPU精灵，查询时按当前页面位置重算拾取目标。前一轮通过后视觉检查发现极端倾角台面相交，提升光学平台并校核支架落点；再复核折屏时量角器是否仍在原光路，将其暂移托盘避免形成额外接收面，再完整复验。历史报告单独留存，不把旧版通过数冒充最终构建结果。分批产物说明见batches/README.md。

## 科学正确性

设d为指向镜面的入射单位向量，n为正面单位法向，r=d−2(d·n)n。i=acos(−d·n)，r角=acos(r·n)。前向光源方位固定在实验坐标中，镜面转动不带动光源；相同入射方向下镜面倾转10°，反射方向改变20°。模型向量在以O为原点的光学坐标中计算，3D平台整体抬高0.25m，不改变几何关系。

|条件|实际i|实际r|现象|
|---|---:|---:|---|
|镜面0°，光源20°|20°|20°|平屏两侧有迹线|
|镜面0°，光源40°|40°|40°|角度从法线量起|
|镜面0°，光源60°|60°|60°|与前两组对照|
|60°入射，右屏折55°|60°|理论60°，不作折屏实测|反射仍存在，光迹离开右翼|
|沿原反射方向反向入射|60°|60°|返回原入射方向|
|光源40°，镜面10°|30°|30°|相对新法线读角|
|正入射后折屏|0°|0°|光路与折痕重合，不能用来判断一般折屏现象|
|光源85°，镜面−25°|不构成正面入射|不显示正面反射角|背面/掠射警告，没有正面反射光迹|

反向入射时折叠的可能是入射侧光屏，不能一律声称反射光迹消失。光屏是散射显示路径的介质；洁净空气中不直接画成可见的实线激光。空间虚线、2D投影明确标作教学辅助。无镜面、关光源、屏未就位、折屏等状态均由当前参数计算，非固定动画。

法线误认会留下红色错误线、操作错误事件，正确法线未成立时记录无效；从镜面量角、否认折屏后反射、把理论角度伪称折屏实测均有无效记录反馈。学生数据曲线只画已填写读数，无效点空心保留，不预画理论答案；重复点不随机移动。

教材原文栏目、器材和步骤见source-map.md：八上第四章第2节，印刷93—95页/PDF100—102页。原文描迹后取下纸板用量角器测角；实时量角器、镜面姿态扩展、三模式、计时和评分均属教学设计，不是教材逐字引用。

## 教学与考核边界

教/自由/考核状态隔离；切换询问是否保存。教学支持分步解释、先预测后真实状态演示和随时接管；自由不限定操作顺序。考核默认15分钟，可配置1—60分钟，绝对截止时间支持刷新恢复，切走不暂停，重置不增加时间；超时锁定数据，可提交已有或补写结论并归位。

考核隐藏理论角度、曲线、自查答案及评分直到提交并实际归位。数值输入只读，必须拖器材或使用1°微调控制。准备、操作、变量、有效手填数据、结论、归位均有事件/数据依据，六项分值可配置；不是湖南官方分值。结论关键词判断只是辅助，不替代教师审阅或防作弊系统。重置会清空当前尝试的数据与轨迹，需先导出以保留；评分针对当前尝试，没有不可篡改考务审计。没有课堂试用效果证据，附表仅为待执行计划。

## 性能实测

Linux Chromium159 / ANGLE SwiftShader软件渲染，1440×1000。每档独立离线上下文，实际镜头操作预热，再采6个活动窗口；FPS为真实Three渲染帧数/时间。按需渲染静止时不计入活动FPS。绘图调用通过包装全部WebGL draw方法测量，含渲染pass；JS堆不等于GPU/操作系统内存。

|画质|活动FPS中位数|平均绘图调用/帧|JS堆/MiB|
|---|---:|---:|---:|
'''+ '\n'.join(f"|{x['quality']}|{x['fpsMedian']:.2f}|{x['drawCalls']:.1f}|{x['jsHeapUsedMiB']:.1f}|" for x in p['results'])+'''

性能仅代表该云端软件渲染环境，不承诺低端显卡流畅或虚报60FPS；Windows Chrome/Edge实际显卡及真实手机待实测。低配建议低画质，近看刻度使用正面/器材特写。详细原始样本、渲染器和错误记录见evidence/performance.json。

## 局限与后续改进

理想零宽光束/零厚度屏面；忽略衍射、散射微结构、镜背反射及光源有限光强。屏铰链严格共面判断是理想近似，真实宽光束会有有限容差。镜面倾转属于教学运动学扩展，支撑结构不运行完整刚体接触引擎；已验证台面净空，但未声称所有器材间碰撞已作机械工程验证。镜面使用PBR环境反射，不是实时平面反射渲染。

数值核对比较独立公式与Three场景渲染参数/2D当前角度状态，不是从像素反演光路或GPU矩阵读回。美术已目视检查，但未进行独立教师或第三方电影级视觉验收。可进一步优化硬件性能、极近景标签、无障碍3D替代操作、描迹后取板测角活动及真实课堂试用。

离线HTML内嵌脚本与GLB，不依赖CDN。源码包包含测试、教材映射、截图和数值报告，视频/trace单独提供；完整教材PDF不分发。实际解压交付包的离线读回核验结果会另记evidence/packaged-file-check.json。
'''
(R/'qa-report.md').write_text(report)
(E/'final-acceptance.json').write_text(json.dumps({'passed':True,'htmlSha256':h,'unitTests':50,'browserCases':8,'analyticalChecks':len(n['checks']),'screenshots':len(shots),'scope':'Scientific and interaction acceptance; Windows hardware/classroom/independent art validation pending'},ensure_ascii=False,indent=2));print('FINAL_ACCEPTANCE_PASSED',len(shots),len(n['checks']))
