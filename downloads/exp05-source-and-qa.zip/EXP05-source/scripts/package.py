from pathlib import Path
import json,zipfile,hashlib,shutil
R=Path(__file__).resolve().parents[1];O=Path('/workspace/output');O.mkdir(exist_ok=True);q=json.loads((R/'evidence/final-acceptance.json').read_text());html=R/'dist/index.html';assert q['passed']and hashlib.sha256(html.read_bytes()).hexdigest()==q['htmlSha256']
name='EXP-05-光的反射定律.html';shutil.copyfile(html,O/name)
with zipfile.ZipFile(O/'EXP05-reflection-offline.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p,n in [(html,name),(R/'README.md','使用说明.md'),(R/'source-map.md','source-map.md'),(R/'qa-report.md','qa-report.md'),(R/'src/physics/model-notes.md','物理模型及边界.md'),(R/'THIRD_PARTY_LICENSES.md','THIRD_PARTY_LICENSES.md')]:z.write(p,n)
 for p in (R/'docs/pilot').glob('*.md'):z.write(p,'试用材料/'+p.name)
with zipfile.ZipFile(O/'EXP05-source-and-QA.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in R.rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(R)
  if any(k.startswith('browser-replays')for k in rel.parts):continue
  if any(k in ['node_modules','history','replay','mobile-replay','__pycache__','test-results']for k in rel.parts):continue
  if p.suffix=='.webm'or p.name.endswith('.tsbuildinfo')or p.name in ['smoke.mjs','publish.py','publish-results.txt','package-results.txt','published-downloads.json']:continue
  z.write(p,'EXP05-source/'+str(rel))
for p in O.glob('EXP05-traces-part*.zip'):p.unlink()
files=sorted((R/'evidence/replay').glob('*.zip'));groups=[];current=[];size=0
for p in files:
 if current and size+p.stat().st_size>28_000_000:groups.append(current);current=[];size=0
 current.append(p);size+=p.stat().st_size
if current:groups.append(current)
for i,group in enumerate(groups,1):
 with zipfile.ZipFile(O/f'EXP05-traces-part{i}.zip','w',zipfile.ZIP_DEFLATED)as z:
  for p in group:z.write(p,p.name)
with zipfile.ZipFile(O/'EXP05-browser-videos.zip','w',zipfile.ZIP_DEFLATED)as z:
 for p in (R/'evidence/replay').glob('*.webm'):z.write(p,p.name)
shutil.copyfile(R/'qa-report.md',O/'EXP05-qa-report.md');m={}
for p in list(O.glob('EXP05-*'))+list(O.glob('EXP-05-*')):
 if not p.is_file():continue
 if p.suffix=='.zip':
  with zipfile.ZipFile(p)as z:assert z.testzip()is None
 p.chmod(0o644);m[p.name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(O/'EXP05-delivery-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2));print(json.dumps(m,ensure_ascii=False,indent=2))
