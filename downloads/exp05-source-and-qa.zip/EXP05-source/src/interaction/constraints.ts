export type Part='source'|'mirror'|'screen'|'protractor';
export const LABELS:Record<Part,string>={source:'低功率光源',mirror:'平面镜',screen:'可折叠光屏',protractor:'量角器'};
export function clampAngle(v:number,min=0,max=85){return Math.round(Math.max(min,Math.min(max,Number.isFinite(v)?v:min))*10)/10}
export function sourceFromPoint(x:number,y:number){return clampAngle(Math.atan2(-x,y)*180/Math.PI)}
export function mirrorFromPoint(x:number,y:number){return clampAngle(Math.atan2(y,x)*180/Math.PI,-25,25)}
export function foldFromDrag(start:number,deltaX:number){return clampAngle(start+deltaX*.25)}
/** GLB mirror AABB conservative enclosure rotated about O. Table top at -0.075m. */
export const OPTICAL_ORIGIN_Y=.25;
export const TABLE_TOP_Y=-.075;
export function mirrorTableClearanceM(deg:number){const r=deg*Math.PI/180;return OPTICAL_ORIGIN_Y-(.3557*Math.abs(Math.sin(r))+.0595*Math.abs(Math.cos(r)))-TABLE_TOP_Y}
