/** Ideal geometrical optics, SI world coordinates; no rendered animation is a source of truth. */
export type Vec3 = [number, number, number];
export interface Config {
  incidenceDeg: number;
  mirrorYawDeg: number;
  foldDeg: number;
  reverse: boolean;
  sourceOn: boolean;
  mirrorPlaced: boolean;
  screenPlaced: boolean;
  normalMarked: boolean;
}
export const DEFAULT_CONFIG: Config = {
  incidenceDeg: 35, mirrorYawDeg: 0, foldDeg: 0, reverse: false,
  sourceOn: false, mirrorPlaced: false, screenPlaced: false, normalMarked: false,
};
export const RAY_LENGTH_M = 0.65;
const EPS = 1e-10;
export const dot = (a: Vec3, b: Vec3) => a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
export const scale = (a: Vec3, k: number): Vec3 => [a[0]*k,a[1]*k,a[2]*k];
export const add = (a: Vec3, b: Vec3): Vec3 => [a[0]+b[0],a[1]+b[1],a[2]+b[2]];
export const cross = (a: Vec3, b: Vec3): Vec3 => [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
export function normalize(v: Vec3): Vec3 {
  if (!v.every(Number.isFinite)) throw new Error('Vector components must be finite.');
  const length=Math.hypot(...v);
  if (length < EPS) throw new Error('A zero-length vector has no direction.');
  return scale(v,1/length);
}
/** Reflection remains valid if the caller supplies the opposite orientation of the normal. */
export function reflect(direction: Vec3, normal: Vec3): Vec3 {
  const d=normalize(direction),n=normalize(normal);
  return normalize(add(d,scale(n,-2*dot(d,n))));
}
export function angleBetweenDeg(a: Vec3,b: Vec3): number {
  return Math.acos(Math.max(-1,Math.min(1,dot(normalize(a),normalize(b)))))*180/Math.PI;
}
function bounded(v:number,min:number,max:number,fallback:number) {return Number.isFinite(v)?Math.max(min,Math.min(max,v)):fallback;}
export function sanitizeConfig(input: Config): Config {
  return {...input,incidenceDeg:bounded(input.incidenceDeg,0,85,35),mirrorYawDeg:bounded(input.mirrorYawDeg,-25,25,0),foldDeg:bounded(input.foldDeg,0,85,0),reverse:!!input.reverse,sourceOn:!!input.sourceOn,mirrorPlaced:!!input.mirrorPlaced,screenPlaced:!!input.screenPlaced,normalMarked:!!input.normalMarked};
}
export interface ReflectionResult {
  cfg: Config;
  normal: Vec3; tangent: Vec3; incoming: Vec3; outgoing: Vec3;
  source: Vec3; hit: Vec3; incidentEnd: Vec3; reflectedEnd: Vec3;
  /** Right wing basis after folding around the normal. */
  foldedTangent: Vec3; foldedPlaneNormal: Vec3;
  incidenceDeg: number; reflectionDeg: number; angleToMirrorDeg: number;
  rayActive: boolean; reflectedActive: boolean; frontHit: boolean;
  coplanar: boolean; onHinge: boolean;
  incidentTraceVisible: boolean; reflectedTraceVisible: boolean;
  foldedWingRayPlaneDeviationDeg: number;
  warnings: string[];
}
export function solveReflection(input: Config): ReflectionResult {
  const cfg=sanitizeConfig(input),i=cfg.incidenceDeg*Math.PI/180,y=cfg.mirrorYawDeg*Math.PI/180,f=cfg.foldDeg*Math.PI/180;
  const normal:Vec3=[-Math.sin(y),Math.cos(y),0],tangent:Vec3=[Math.cos(y),Math.sin(y),0];
  const forwardIncoming:Vec3=[Math.sin(i),-Math.cos(i),0];
  const forwardOutgoing=reflect(forwardIncoming,normal);
  const incoming=cfg.reverse?scale(forwardOutgoing,-1):forwardIncoming;
  const outgoing=reflect(incoming,normal);
  const source=scale(incoming,-RAY_LENGTH_M),reflectedEnd=scale(outgoing,RAY_LENGTH_M);
  // Rodrigues rotation about normal. Right wing is +tangent side; left wing stays flat.
  const foldedTangent=add(scale(tangent,Math.cos(f)),scale(cross(normal,tangent),Math.sin(f)));
  const foldedPlaneNormal=normalize(cross(foldedTangent,normal));
  const coplanar=Math.abs(cfg.foldDeg)<1e-7,onHinge=Math.abs(dot(scale(incoming,-1),tangent))<EPS;
  const frontHit=dot(scale(incoming,-1),normal)>EPS;
  const rayActive=cfg.sourceOn,reflectedActive=rayActive&&cfg.mirrorPlaced&&frontHit;
  const sourceOnFixedWing=dot(source,tangent)<=EPS;
  const reflectedOnFixedWing=dot(outgoing,tangent)<=EPS;
  const incidentTraceVisible=rayActive&&cfg.screenPlaced&&frontHit&&(sourceOnFixedWing||coplanar||onHinge);
  const reflectedTraceVisible=reflectedActive&&cfg.screenPlaced&&(reflectedOnFixedWing||coplanar||onHinge);
  const incidenceDeg=angleBetweenDeg(scale(incoming,-1),normal),reflectionDeg=angleBetweenDeg(outgoing,normal);
  const warnings:string[]=[];
  if (!frontHit) warnings.push('光源位于镜面背面或沿镜面掠射；本装置只模拟正面反射，需调整光源或镜面。');
  if (!cfg.mirrorPlaced) warnings.push('平面镜未就位，不能观察镜面反射。');
  if (!cfg.screenPlaced) warnings.push('光屏未就位；洁净空气中的光路不能直接看见。');
  if (!cfg.normalMarked) warnings.push('请以入射点处垂直镜面的法线作为角度零线。');
  if (!coplanar&&!onHinge) warnings.push(!sourceOnFixedWing?'折叠侧不再承接入射光迹；光源与入射光路的原位置不能随纸板转动。':'折叠侧不再承接反射光迹，并非反射光消失。');
  if(onHinge&&cfg.foldDeg>0)warnings.push('正入射时光路与折痕重合，不能用这个特殊位置判断折叠是否消除了光迹。');
  return {cfg,normal,tangent,incoming,outgoing,source,hit:[0,0,0],incidentEnd:[0,0,0],reflectedEnd,foldedTangent,foldedPlaneNormal,incidenceDeg,reflectionDeg,angleToMirrorDeg:90-incidenceDeg,rayActive,reflectedActive,frontHit,coplanar,onHinge,incidentTraceVisible,reflectedTraceVisible,foldedWingRayPlaneDeviationDeg:Math.asin(Math.min(1,Math.abs(dot(sourceOnFixedWing?outgoing:incoming,foldedPlaneNormal))))*180/Math.PI,warnings};
}
export type Result = ReflectionResult;
