import {describe,it,expect} from 'vitest';
import {DEFAULT_CONFIG,solveReflection,reflect,normalize,dot,scale,angleBetweenDeg,type Config} from './reflection';
const base:Config={...DEFAULT_CONFIG,sourceOn:true,mirrorPlaced:true,screenPlaced:true,normalMarked:true};
describe('vector reflection with a normalized surface normal',()=>{
 for(const i of [0,1,15,30,45,60,80,85])it(`reflects incidence ${i} degrees`,()=>{
  const q=solveReflection({...base,incidenceDeg:i});expect(q.incidenceDeg).toBeCloseTo(i,8);expect(q.reflectionDeg).toBeCloseTo(i,8);expect(dot(q.incoming,q.normal)).toBeCloseTo(-dot(q.outgoing,q.normal),10);expect(Math.hypot(...q.outgoing)).toBeCloseTo(1,12);
 });
 it('normal orientation is irrelevant',()=>expect(reflect([1,-2,0],[0,1,0])).toEqual(reflect([1,-2,0],[0,-1,0])));
 it('nonunit normal and direction are normalized',()=>expect(reflect([0,-4,0],[0,20,0])).toEqual([0,1,0]));
 it('rejects zero or nonfinite vectors',()=>{expect(()=>normalize([0,0,0])).toThrow();expect(()=>normalize([NaN,1,0])).toThrow();});
 it('tilting a mirror changes reflection for fixed incoming direction',()=>{const incoming=normalize([1,-2,0]);const a=reflect(incoming,[0,1,0]),b=reflect(incoming,normalize([-.2,1,0]));expect(angleBetweenDeg(a,b)).toBeGreaterThan(20);});
 it('mirror yaw changes actual incidence while source stays fixed',()=>{const q=solveReflection({...base,incidenceDeg:45,mirrorYawDeg:25});expect(q.incidenceDeg).toBeCloseTo(20);expect(q.reflectionDeg).toBeCloseTo(20);expect(dot(q.tangent,q.normal)).toBeCloseTo(0,12);expect(q.outgoing[0]).not.toBeCloseTo(Math.SQRT1_2);});
 it('extreme source and mirror can fall behind the one-sided mirror',()=>{const q=solveReflection({...base,incidenceDeg:85,mirrorYawDeg:-25});expect(q.source.every(Number.isFinite)).toBe(true);expect(q.reflectionDeg).toBeCloseTo(110);expect(q.frontHit).toBe(false);expect(q.reflectedActive).toBe(false);});
});
describe('screen scattering is distinct from ray propagation',()=>{
 it('coplanar screens display both traces',()=>{const q=solveReflection(base);expect(q.incidentTraceVisible).toBe(true);expect(q.reflectedTraceVisible).toBe(true);});
 it('folding removes reflected screen trace but not reflected ray',()=>{const q=solveReflection({...base,foldDeg:45});expect(q.incidentTraceVisible).toBe(true);expect(q.reflectedTraceVisible).toBe(false);expect(q.reflectedActive).toBe(true);expect(q.reflectionDeg).toBeCloseTo(35);expect(q.foldedWingRayPlaneDeviationDeg).toBeGreaterThan(0);});
 it('no screen does not mean no reflection',()=>{const q=solveReflection({...base,screenPlaced:false});expect(q.reflectedTraceVisible).toBe(false);expect(q.reflectedActive).toBe(true);});
 it('mirror absence prevents reflected ray',()=>{const q=solveReflection({...base,mirrorPlaced:false});expect(q.reflectedActive).toBe(false);expect(q.reflectedTraceVisible).toBe(false);expect(q.incidentTraceVisible).toBe(true);});
 it('source switch really removes both traces',()=>{const q=solveReflection({...base,sourceOn:false});expect(q.incidentTraceVisible||q.reflectedTraceVisible||q.reflectedActive).toBe(false);});
 it('normal incidence lies on fold hinge and is a special case',()=>{const q=solveReflection({...base,incidenceDeg:0,foldDeg:85});expect(q.onHinge).toBe(true);expect(q.reflectedTraceVisible).toBe(true);expect(q.foldedWingRayPlaneDeviationDeg).toBeCloseTo(0);});
});
describe('reversibility, determinism and boundaries',()=>{
 it('reverse retraces the original path',()=>{const a=solveReflection({...base,incidenceDeg:55,mirrorYawDeg:17}),b=solveReflection({...base,incidenceDeg:55,mirrorYawDeg:17,reverse:true});expect(b.incoming).toEqual(scale(a.outgoing,-1));for(let j=0;j<3;j++)expect(b.outgoing[j]).toBeCloseTo(-a.incoming[j],12);});
 it('reverse folded wing hides incident rather than fixed-side reflected trace',()=>{const q=solveReflection({...base,reverse:true,foldDeg:30});expect(q.incidentTraceVisible).toBe(false);expect(q.reflectedTraceVisible).toBe(true);});
 it('repeated measurement does not randomly drift',()=>expect(solveReflection(base)).toEqual(solveReflection(base)));
 it('angles are from the normal and mirror angle is complementary',()=>{const q=solveReflection({...base,incidenceDeg:30});expect(q.angleToMirrorDeg).toBeCloseTo(60);expect(q.reflectionDeg).not.toBeCloseTo(60);});
 it('clamps mechanical limits and repairs nonfinite values',()=>{const q=solveReflection({...base,incidenceDeg:1000,mirrorYawDeg:-200,foldDeg:NaN});expect(q.cfg.incidenceDeg).toBe(85);expect(q.cfg.mirrorYawDeg).toBe(-25);expect(q.cfg.foldDeg).toBe(0);});
 it('normal incidence to a tilted mirror does not create acos numerical errors',()=>{const q=solveReflection({...base,incidenceDeg:25,mirrorYawDeg:25});expect(q.incidenceDeg).toBeCloseTo(0,6);expect(q.reflectionDeg).toBeCloseTo(0,6);});
});

describe('fixed source and mirror side crossing',()=>{
 it('tilting mirror does not move source',()=>{const a=solveReflection({...base,mirrorYawDeg:0}),b=solveReflection({...base,mirrorYawDeg:20});expect(a.source).toEqual(b.source);expect(angleBetweenDeg(a.outgoing,b.outgoing)).toBeCloseTo(40,8);});
 it('source crosses to folded half when mirror yaw exceeds source bearing',()=>{const q=solveReflection({...base,incidenceDeg:10,mirrorYawDeg:20,foldDeg:30});expect(q.incidenceDeg).toBeCloseTo(10,8);expect(q.incidentTraceVisible).toBe(false);expect(q.reflectedTraceVisible).toBe(true);});
 it('hinge exception depends on actual normal, not source control zero',()=>{const q=solveReflection({...base,incidenceDeg:20,mirrorYawDeg:20,foldDeg:85});expect(q.onHinge).toBe(true);expect(q.reflectedTraceVisible).toBe(true);});
});
