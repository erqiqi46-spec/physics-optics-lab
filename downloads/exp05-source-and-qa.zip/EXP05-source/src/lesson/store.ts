import { create } from 'zustand';
import { DEFAULT_CONFIG, sanitizeConfig, solveReflection } from '../physics/reflection';
import type { Config, Result } from '../physics/reflection';
export type Mode = 'teach'|'free'|'exam';
export type Device = 'source'|'mirror'|'screen'|'protractor';
export const DEVICES:Device[]=['source','mirror','screen','protractor'];
export const DEFAULT_WEIGHTS=[10,30,20,20,10,10];
export interface Event {id:number;at:number;type:string;detail:any}
export interface RowInput {incidenceDeg:number;reflectionDeg:number|null;foldDeg:number;purpose:'angles'|'coplanar'|'reverse'|'repeat';reference:'normal'|'mirror';coplanarConclusion:'same-plane'|'no-reflection'|'exists-off-screen';unitChecked:boolean}
export interface Row extends RowInput {id:number;at:number;cfg:Config;expected:Result;valid:boolean;reasons:string[]}
interface Snapshot {cfg:Config;stowed:Device[];normalAttempt:'surface'|'perpendicular'|null}
export interface Session extends Snapshot {inspected:Device[];inventoryConfirmed:boolean;rows:Row[];events:Event[];predictions:Record<string,{choice:string;at:number}>;conclusion:string;started:boolean;startedAt:number|null;deadline:number|null;submitted:boolean;submittedAt:number|null;expired:boolean;returned:boolean;weights:number[];history:Snapshot[];frozen:boolean;lastWarning:string}
export interface GradePart {label:string;max:number;earned:number;basis:string[]}
export interface Grade {total:number;maximum:number;official:false;parts:GradePart[]}
const copy=<T,>(v:T):T=>JSON.parse(JSON.stringify(v));
const near=(a:number,b:number,t=.51)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=t;
const initialConfig=():Config=>({...DEFAULT_CONFIG,incidenceDeg:45,mirrorYawDeg:0,foldDeg:0,reverse:false,sourceOn:false,mirrorPlaced:false,screenPlaced:false,normalMarked:false});
export const freshSession=():Session=>({cfg:initialConfig(),stowed:[...DEVICES],normalAttempt:null,inspected:[],inventoryConfirmed:false,rows:[],events:[],predictions:{},conclusion:'',started:false,startedAt:null,deadline:null,submitted:false,submittedAt:null,expired:false,returned:false,weights:[...DEFAULT_WEIGHTS],history:[],frozen:false,lastWarning:''});
const add=(s:Session,type:string,detail:any={})=>s.events.push({id:s.events.length+1,at:Date.now(),type,detail:copy(detail)});
const snap=(s:Session):Snapshot=>({cfg:copy(s.cfg),stowed:[...s.stowed],normalAttempt:s.normalAttempt});
export function conditionKey(r:Row){return `${r.cfg.incidenceDeg}/${r.cfg.mirrorYawDeg}/${r.cfg.foldDeg}/${r.cfg.reverse}`}
function validate(s:Session,r:RowInput,q:Result):string[]{
 const reasons:string[]=[];
 if(!s.inventoryConfirmed)reasons.push('尚未完成器材检查');
 if(!s.cfg.mirrorPlaced||!s.cfg.screenPlaced)reasons.push('先摆放平面镜与光屏');
 if(!s.cfg.sourceOn)reasons.push('光源未开启，不能记录可见光迹');
 if(!q.frontHit)reasons.push('光源位于镜面背面或沿镜面掠射，未形成当前正面的反射实验');
 if(!s.cfg.normalMarked)reasons.push('尚未以镜面垂线标出法线');
 if(r.reference!=='normal')reasons.push('角度应从法线量起，而不是从镜面量起');
 if(!r.unitChecked)reasons.push('角度单位检查未完成');
 if(!near(r.foldDeg,s.cfg.foldDeg))reasons.push('光屏折叠状态记录不符');
 if(!near(r.incidenceDeg,q.incidenceDeg))reasons.push('入射角读数与实际不符');
 const folded=s.cfg.foldDeg>1;
 const foldedObservation=r.purpose==='coplanar'&&folded;
 if(foldedObservation){
  if(q.incidenceDeg<1)reasons.push('法线入射的光线位于铰链处，不能用此特殊位置判断折屏现象');
  if(r.reflectionDeg!==null)reasons.push('折屏后不能把原平面的理论反射角当成当前光屏的实测读数');
  if(r.coplanarConclusion!=='exists-off-screen')reasons.push('光屏上看不到光迹不等于没有反射；反射光离开折叠的屏面');
 }else{
  if(!q.incidentTraceVisible||!q.reflectedTraceVisible)reasons.push('光迹不同时落在两侧屏面，先恢复共面再测量两角');
  if(r.reflectionDeg===null||!near(r.reflectionDeg,q.reflectionDeg))reasons.push('反射角读数与实际不符');
  if(r.coplanarConclusion==='no-reflection')reasons.push('当前仍有反射，不能以屏上光迹缺失否认反射');
 }
 if(r.purpose==='reverse'&&!s.cfg.reverse)reasons.push('尚未执行反向入射操作');
 if(r.purpose==='repeat'&&!s.rows.some(a=>a.valid&&conditionKey(a)===`${s.cfg.incidenceDeg}/${s.cfg.mirrorYawDeg}/${s.cfg.foldDeg}/${s.cfg.reverse}`))reasons.push('重复测量应与先前一组保持同一装置条件');
 return reasons;
}
export function evaluate(s:Session):Grade{
 const seal=s.events.findIndex(e=>e.type==='submit'||e.type==='timeout');const ev=seal<0?s.events:s.events.slice(0,seal);
 const good=s.rows.filter(r=>r.valid&&ev.some(e=>e.type==='record'&&e.detail.rowId===r.id));
 const angleRows=good.filter(r=>r.reflectionDeg!==null&&r.cfg.foldDeg<=1);
 const distinct=new Set(angleRows.map(r=>Math.round(r.incidenceDeg))).size;
 const folded=good.some(r=>r.purpose==='coplanar'&&r.cfg.foldDeg>=20&&r.reflectionDeg===null&&r.coplanarConclusion==='exists-off-screen');
 const restored=ev.some((e,i)=>e.type==='fold'&&e.detail.after>=20&&ev.slice(i+1).some(a=>a.type==='fold'&&a.detail.after===0));
 const reverse=good.some(r=>r.purpose==='reverse'&&r.cfg.reverse)&&ev.some((e,i)=>e.type==='reverse'&&e.detail.after===true&&ev.slice(i+1).some(a=>a.type==='reverse'&&a.detail.after===false));
 const repeated=good.some((r,i)=>r.purpose==='repeat'&&good.slice(0,i).some(a=>conditionKey(a)===conditionKey(r)));
 const fixedMirror=angleRows.length>=3&&angleRows.every(r=>near(r.cfg.mirrorYawDeg,angleRows[0].cfg.mirrorYawDeg,.01));
 const conclusion=s.conclusion.includes('反射角')&&s.conclusion.includes('入射角')&&/(等于|相等)/.test(s.conclusion)&&/(同一平面|共面)/.test(s.conclusion)&&/(可逆|逆向|反向)/.test(s.conclusion);
 const fractions=[s.inventoryConfirmed&&ev.some(e=>e.type==='normal-marked')?1:s.inventoryConfirmed?.7:0,(Math.min(3,distinct)/3+Number(folded&&restored)+Number(reverse))/3,(Number(fixedMirror)+Number(repeated))/2,Math.min(1,good.length/6),conclusion?1:s.conclusion.trim().length>=15?.4:0,s.returned?1:0];
 const basis=[['器材清点与法线标记事件',`已检查${s.inspected.length}/4`],[`不同入射角${distinct}/3`,`折屏有效观察与恢复${folded&&restored}`,`反向入射及恢复${reverse}`],[`角度实验保持镜面姿态${fixedMirror}`,`同条件重复测量${repeated}`],[`有效手填记录${good.length}/6`],['结论关键词只是自定义辅助核对，仍需教师审阅'],[`提交后光源关闭、光屏展平、全部器材归位${s.returned}`]];
 const parts=['器材及准备','操作步骤','变量控制','数据和单位','结论','安全和归位'].map((label,i)=>({label,max:s.weights[i],earned:Math.round(s.weights[i]*fractions[i]*100)/100,basis:basis[i]}));
 return {total:Math.round(parts.reduce((n,p)=>n+p.earned,0)*100)/100,maximum:s.weights.reduce((a,b)=>a+b,0),official:false,parts};
}
export interface Lab {mode:Mode;sessions:Record<Mode,Session>;quality:'low'|'medium'|'high';setQuality:(q:Lab['quality'])=>void;start:(m:Mode,minutes?:number,weights?:number[])=>void;switchMode:(m:Mode,save:boolean)=>void;inspect:(d:Device)=>void;confirmInventory:()=>void;placeMirror:()=>void;placeScreen:()=>void;markNormal:(reference?:'surface'|'perpendicular')=>void;setIncidence:(v:number,source?:'panel'|'apparatus')=>void;setMirrorYaw:(v:number,source?:'panel'|'apparatus')=>void;setFold:(v:number,source?:'panel'|'apparatus')=>void;toggleReverse:()=>void;toggleSource:()=>void;record:(r:RowInput)=>void;setConclusion:(text:string)=>void;submit:(text?:string)=>void;stow:(d:Device)=>void;undo:()=>void;reset:()=>void;tick:()=>void;setFrozen:(v:boolean)=>void;setWeights:(v:number[])=>void;predict:(topic:string,choice:string)=>void}
let saved:any;try{saved=JSON.parse(localStorage.getItem('EXP05-reflection-v1')||'null')}catch{}
export const useLab=create<Lab>(set=>{
 const update=(fn:(s:Session,m:Mode)=>void,history=false)=>set(st=>{const s=copy(st.sessions[st.mode]);s.lastWarning='';if(st.mode==='exam'&&s.started&&!s.submitted&&!s.expired&&s.deadline!==null&&Date.now()>=s.deadline){s.expired=true;s.frozen=false;add(s,'timeout',{deadline:s.deadline})}if(history&&!s.submitted&&!s.expired){s.history.push(snap(s));s.history=s.history.slice(-50)}fn(s,st.mode);s.returned=s.submitted&&!s.cfg.sourceOn&&s.cfg.foldDeg===0&&!s.cfg.reverse&&!s.cfg.mirrorPlaced&&!s.cfg.screenPlaced&&DEVICES.every(d=>s.stowed.includes(d))&&DEVICES.every(d=>s.events.some(e=>e.type==='stow'&&e.detail.device===d&&e.at>=(s.submittedAt??0)));return{sessions:{...st.sessions,[st.mode]:s}}});
 const allowed=(s:Session)=>s.started&&!s.submitted&&!s.expired&&!s.frozen;
 const parameter=(s:Session,m:Mode,key:'incidenceDeg'|'mirrorYawDeg'|'foldDeg',v:number,source:'panel'|'apparatus')=>{
  if(!s.started||s.frozen||!Number.isFinite(v))return;
  if((s.submitted||s.expired)&&!(key==='foldDeg'&&v===0))return;
  if(m==='exam'&&source==='panel'&&!s.submitted){s.lastWarning='考核时请直接操作3D器材或器材微调键。';return}
  if(!s.inventoryConfirmed||!s.cfg.mirrorPlaced||!s.cfg.screenPlaced){s.lastWarning='先清点并摆放平面镜与光屏。';return}
  const before=s.cfg[key];s.cfg=sanitizeConfig({...s.cfg,[key]:Math.round(v)});const type=key==='incidenceDeg'?'incidence':key==='mirrorYawDeg'?'mirror-yaw':'fold';add(s,type,{before,after:s.cfg[key],source,result:solveReflection(s.cfg)});
  if(key==='foldDeg'&&s.cfg.foldDeg>1)s.lastWarning=s.cfg.incidenceDeg<1?'法线入射光线位于铰链处；换一个非零角度再观察折屏。':'折叠光屏后光迹可能离开屏面，不等于反射消失。';
 };
 return {mode:saved?.mode??'teach',sessions:saved?.sessions??{teach:freshSession(),free:freshSession(),exam:freshSession()},quality:saved?.quality??'medium',setQuality:quality=>set({quality}),
 start:(mode,minutes=15,weights)=>set(st=>{const s=copy(st.sessions[mode]);if(!s.started){s.started=true;s.startedAt=Date.now();s.deadline=mode==='exam'?Date.now()+Math.max(1,Math.min(60,Number.isFinite(minutes)?minutes:15))*60000:null;if(weights?.length===6&&weights.every(n=>Number.isFinite(n)&&n>=0)&&weights.some(n=>n>0))s.weights=weights.map(n=>Math.min(100,n));add(s,'start',{mode,minutes,weights:s.weights})}return{mode,sessions:{...st.sessions,[mode]:s}}}),
 switchMode:(mode,save)=>set(st=>({mode,sessions:save?st.sessions:{...st.sessions,[st.mode]:freshSession()}})),
 inspect:d=>update(s=>{if(allowed(s)&&DEVICES.includes(d)&&!s.inspected.includes(d)){s.inspected.push(d);add(s,'inspect',{device:d})}}),
 confirmInventory:()=>update(s=>{if(!allowed(s))return;if(!DEVICES.every(d=>s.inspected.includes(d))){s.lastWarning='先逐一检查光源、平面镜、光屏和量角器。';return}s.inventoryConfirmed=true;add(s,'inventory-confirmed',{devices:s.inspected})}),
 placeMirror:()=>update(s=>{if(!allowed(s)||!s.inventoryConfirmed)return;s.cfg.mirrorPlaced=true;s.stowed=s.stowed.filter(d=>d!=='mirror');add(s,'place-mirror',{normal:solveReflection(s.cfg).normal})},true),
 placeScreen:()=>update(s=>{if(!allowed(s)||!s.inventoryConfirmed)return;s.cfg.screenPlaced=true;s.stowed=s.stowed.filter(d=>d!=='screen'&&d!=='protractor');add(s,'place-screen',{foldDeg:s.cfg.foldDeg})},true),
 markNormal:(reference='perpendicular')=>update(s=>{if(!allowed(s)||!s.cfg.mirrorPlaced||!s.cfg.screenPlaced){s.lastWarning='先摆放镜面和光屏，再确定过入射点的镜面垂线。';return}s.normalAttempt=reference;if(reference==='surface'){s.cfg.normalMarked=false;const detail={reference,tangent:solveReflection(s.cfg).tangent,reason:'法线须过O且垂直镜面；沿镜面不是法线'};add(s,'normal-mistake',detail);add(s,'error',detail);s.lastWarning=detail.reason;return}s.cfg.normalMarked=true;add(s,'normal-marked',{normal:solveReflection(s.cfg).normal})},true),
 setIncidence:(v,source='panel')=>update((s,m)=>parameter(s,m,'incidenceDeg',v,source),true),setMirrorYaw:(v,source='panel')=>update((s,m)=>parameter(s,m,'mirrorYawDeg',v,source),true),setFold:(v,source='panel')=>update((s,m)=>parameter(s,m,'foldDeg',v,source),true),
 toggleSource:()=>update(s=>{if(!s.started||s.frozen)return;if(s.cfg.sourceOn){s.cfg.sourceOn=false;add(s,'source',{after:false});return}if(!allowed(s)||!s.inventoryConfirmed||!s.cfg.mirrorPlaced||!s.cfg.screenPlaced){s.lastWarning='开启光源前先完成器材检查并摆好镜面和光屏。';return}s.cfg.sourceOn=true;s.stowed=s.stowed.filter(d=>d!=='source');add(s,'source',{after:true})},true),
 toggleReverse:()=>update(s=>{if(!s.started||s.frozen||((s.submitted||s.expired)&&!s.cfg.reverse))return;if(!s.inventoryConfirmed||!s.cfg.mirrorPlaced||!s.cfg.screenPlaced)return;const before=s.cfg.reverse;s.cfg.reverse=!before;add(s,'reverse',{before,after:s.cfg.reverse,result:solveReflection(s.cfg)})},true),
 record:r=>update(s=>{if(!allowed(s))return;const q=solveReflection(s.cfg);const reasons=validate(s,r,q);const row:Row={...copy(r),id:s.rows.length+1,at:Date.now(),cfg:copy(s.cfg),expected:q,valid:reasons.length===0,reasons};s.rows.push(row);add(s,'record',{rowId:row.id,valid:row.valid,reasons,cfg:s.cfg});if(reasons.length){s.lastWarning=reasons.join('；');add(s,'error',{rowId:row.id,reasons})}}),
 setConclusion:conclusion=>update(s=>{if(s.started&&!s.submitted&&!s.frozen)s.conclusion=conclusion}),
 submit:text=>update(s=>{if(!s.started||s.submitted)return;if(text!==undefined)s.conclusion=text;if(s.conclusion.trim().length<10){s.lastWarning='请先填写独立实验结论，再提交。';return}s.submitted=true;s.submittedAt=Date.now();s.frozen=false;add(s,'submit',{rows:s.rows.length,conclusion:s.conclusion})}),
 stow:d=>update(s=>{if(!s.started||!s.submitted||!DEVICES.includes(d))return;if(s.cfg.sourceOn){s.lastWarning='先关闭光源再整理器材。';return}if(s.cfg.foldDeg!==0||s.cfg.reverse){s.lastWarning='先把光屏展平，并恢复正向入射。';return}if(!s.stowed.includes(d))s.stowed.push(d);if(d==='mirror'){s.cfg.mirrorPlaced=false;s.cfg.normalMarked=false}if(d==='screen')s.cfg.screenPlaced=false;add(s,'stow',{device:d})}),
 undo:()=>update(s=>{if(!allowed(s))return;const previous=s.history.pop();if(previous){s.cfg=previous.cfg;s.stowed=previous.stowed;s.normalAttempt=previous.normalAttempt??null;add(s,'undo',{cfg:s.cfg})}}),
 reset:()=>set(st=>{const old=st.sessions[st.mode];const s=freshSession();s.started=old.started;s.startedAt=old.startedAt;s.deadline=old.deadline;s.expired=old.expired;s.weights=[...old.weights];add(s,'reset');return{sessions:{...st.sessions,[st.mode]:s}}}),
 tick:()=>update((s,m)=>{if(m==='exam'&&s.started&&!s.submitted&&!s.expired&&s.deadline!==null&&Date.now()>=s.deadline){s.expired=true;s.frozen=false;add(s,'timeout',{deadline:s.deadline})}}),
 setFrozen:frozen=>update(s=>{if(s.started&&!s.submitted&&!s.expired){s.frozen=frozen;add(s,'freeze',{frozen})}}),
 setWeights:weights=>update(s=>{if(!s.started&&weights.length===6&&weights.every(n=>Number.isFinite(n)&&n>=0)&&weights.some(n=>n>0))s.weights=weights.map(n=>Math.min(100,n))}),
 predict:(topic,choice)=>update(s=>{if(allowed(s)){s.predictions[topic]={choice,at:Date.now()};add(s,'prediction',{topic,choice})}})
 };
});
useLab.subscribe(st=>{try{localStorage.setItem('EXP05-reflection-v1',JSON.stringify({mode:st.mode,sessions:st.sessions,quality:st.quality}))}catch{}});
