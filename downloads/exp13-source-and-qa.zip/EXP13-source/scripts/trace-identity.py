from pathlib import Path
import json,hashlib,zipfile
R=Path(__file__).resolve().parents[1];body=(R/'dist/index.html').read_bytes();sha=hashlib.sha256(body).hexdigest();paths=list((R/'evidence/browser-replays-final').rglob('trace.zip'));assert len(paths)==8
checks=[]
for p in paths:
 with zipfile.ZipFile(p)as z:
  found=False
  for n in z.namelist():
   if n.startswith('resources/')and z.getinfo(n).file_size==len(body):
    h=hashlib.sha256(z.read(n)).hexdigest();found=True;checks.append({'trace':str(p.relative_to(R)),'htmlSha256':h,'matchesFinal':h==sha})
  assert found,'No finalHTML body in '+str(p)
assert all(c['matchesFinal']for c in checks)
(R/'evidence/trace-build-identity.json').write_text(json.dumps({'allMatched':True,'finalSha256':sha,'traceCount':len(paths),'traceChecks':checks},indent=2));print('Trace identity verified',len(paths),sha)
