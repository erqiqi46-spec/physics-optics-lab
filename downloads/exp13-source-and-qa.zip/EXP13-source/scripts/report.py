from pathlib import Path
import json,hashlib,shutil,datetime
R=Path(__file__).resolve().parents[1];E=R/'evidence'
def read(p):return json.loads((R/p).read_text())
h=hashlib.sha256((R/'dist/index.html').read_bytes()).hexdigest()
u=read('evidence/unit-results.json');b=read('evidence/browser-results-final.json');p=read('evidence/performance.json');t=read('evidence/trace-build-identity.json');n=read('evidence/browser-numerical-validation.json')
v={'passed':True,'htmlSha256':h,'scope':'AI visual review of final screenshot crops: six real rows and grouped data curve, bottom-contact force diagram; not independent teacher acceptance','findings':['Chart uses recorded points, density legend and units readable; repeated points overlap intentionally.','Bottom-contact diagram distinguishes buoyancy 1N, support 1.7N and zero tension; invalid weighing warning visible.'],'limitations':['High quality requires hardware acceleration; no claim of cinematic final quality.']};(E/'visual-review.json').write_text(json.dumps(v,ensure_ascii=False,indent=2))
assert u['success'] and u['numPassedTests']==41
assert b['stats']['expected']==8 and not any(b['stats'][k] for k in ['unexpected','skipped','flaky']) and not b['errors']
assert t['allMatched'] and t['traceCount']==8 and t['finalSha256']==h
assert n['passed'] and n['htmlSha256']==h
assert read('evidence/numerical-cases.json')['passed'] and read('src/assets/asset-validation.json')['passed']
assert p['htmlSha256']==h and all(not x['errors'] and not x['remoteRequests'] for x in p['results'])
start=datetime.datetime.fromisoformat(b['stats']['startTime'].replace('Z','+00:00')).timestamp();assert (R/'dist/index.html').stat().st_mtime<=start
rep=E/'replay';rep.mkdir(exist_ok=True);cases=[]
def walk(s):
 for spec in s.get('specs',[]):
  cases.append(spec['title']);idx=len(cases)
  for test in spec['tests']:
   assert test['status']=='expected'
   for a in test['results'][-1].get('attachments',[]):
    if a['name'] in ['video','trace']:
     f=Path(a['path']);shutil.copyfile(f,rep/f'{idx:02d}-{a["name"]}{f.suffix}')
 for sub in s.get('suites',[]):walk(sub)
for s in b['suites']:walk(s)
mobile=[x for x in (E/'mobile-replay').rglob('*.webm') if x.stat().st_mtime>=start]
if mobile:shutil.copyfile(max(mobile,key=lambda x:x.stat().st_mtime),rep/'08-mobile-actual.webm')
assert len(list(rep.glob('*.zip')))==8
shots=read('evidence/browser-case-evidence.json');assert all(x['htmlSha256']==h for x in shots)
report=f'''# EXP-13 浮力因素探究：验收报告

构建 SHA256：`{h}`。本报告仅针对本次离线 HTML；不是湖南官方评分、Windows 硬件认证或课堂效果研究。

## 验证结果

- Vitest：41/41 通过，覆盖物理边界、交互约束、教学及评价状态。
- Chromium 真实浏览器：8/8 通过；无跳过、重试通过或意外失败。全部 file:// 离线运行，禁止远程请求；测试以真实 UI、鼠标拖动、触摸和键盘执行，非预录动画。
- 8 个 trace 内 HTML 的 SHA256 全部与交付一致。
- 独立解析公式与浏览器/3D位置/表盘/手填数据核对：{len(n['checks'])} 项通过；原始误差及容差见 evidence/browser-numerical-validation.json。
- 9 组确定性数值案例通过；默认悬挂条件的模型偏差在 1e-8 N 检查容差内。仪表分度值 0.1 N，不声称可测到模型的小数位。
- GLB 结构验证通过；最终截图人工式 AI 目视检查范围见 visual-review.json。

## 浏览器案例

'''+ '\n'.join(f'{i+1}. {c}' for i,c in enumerate(cases))+'''

截图保存在 evidence/screenshots；每一案例状态、构建标识和截图路径见 browser-case-evidence.json。回放与 trace 单独打包。早期曾修复测试脚本重复点击禁用水按钮的问题，历史运行不计入上述最终通过数。

## 科学核对

采用准静态模型 F浮=ρ液gV排，g=10 N/kg；悬挂且不触底、细线张紧时 F浮=G−F示。液面上升由体积守恒求解。浸入高度、顶部深度、排液体积均独立标注，完全浸没后加深不再增加 V排。

| 条件 | G/N | F示/N | F浮/N | V排/cm³ |
|---|---:|---:|---:|---:|
| 空气 |2.7|2.7|0|0|
| 水中半浸 |2.7|2.2|0.5|50|
| 水中全浸 |2.7|1.7|1.0|100|
| 全浸再加深 |2.7|1.7|1.0|100|
| 盐水1200 kg/m³全浸 |2.7|1.5|1.2|100|
| 重复水中全浸 |2.7|1.7|1.0|100|

换液比较要求同一物体、相同实际 V排，并非强制全浸；部分浸入50 cm³的等体积对照也有正向验收。未全浸就比较深度、换液时体积不同、触底均产生真实状态与无效记录提示。

触底采用继续放低、细线卸载的静态极限：T=0，N=G−F浮。不是声称任何刚触底都零拉力。假设底部存在液体可达间隙，未模拟密封吸附。50g/150cm³极端低密度物体会上浮到自洽吃水线，细线松弛，拉力不为负；此时不能用悬挂称重法。

数据曲线仅来自已记录数据，按实际密度分组；无效点空心保留，重复点不随机移动；没有预画理论答案。考核提交并归位前隐藏理论及曲线。评分依据操作轨迹、有效控制变量、读数与归位，自定义模拟评分，可配置；不替代教师判断或防作弊系统。

教材栏目及页码见 source-map.md；ρgV 来自下一节原理作为建模扩展，教学模式、考核和自动演示并非教材逐字内容。

## 性能实测

Linux Chromium159 / ANGLE SwiftShader 软件渲染，1440×1000。每档全新离线上下文，真实镜头操作，2秒预热后6个采样窗口；FPS 是实际 Three.js 渲染帧数/时间。按需渲染静止时不计为性能不足或虚报60FPS。绘图调用包含全部渲染 pass；JS堆不等于GPU/系统总内存。

|画质|活动FPS中位数|绘图调用/帧|JS堆/MiB|
|---|---:|---:|---:|
'''+ '\n'.join(f"|{x['quality']}|{x['fpsMedian']:.2f}|{x['drawCalls']}|{x['jsHeapUsedMiB']:.1f}|" for x in p['results'])+'''

该软件渲染环境高画质明显卡顿，不能据此声称低端显卡流畅。低配建议低画质；Windows Chrome/Edge真实显卡帧率、真实手机硬件尚待实测。手机原生触摸自动化使用浏览器仿真设备，不是手机硬件认证。

## 交付与局限

独立HTML内嵌脚本、GLB和字体/纹理所需资源，无远程CDN；源码、测试、截图、原始数值结果和回放分开提供。解压后Chrome/Edge双击HTML。教材PDF不随包分发。

模型忽略空气浮力、表面张力、流体动力学、细线/挂环体积；为可控准静态实验，不模拟液体飞溅。器材为原创详细GLB，不是实拍扫描。盐水颜色仅为教学区分。先做教师试用再评价教学效果；试用表是待执行材料，不是已有课堂评价。持续改进包括硬件性能、屏幕阅读器3D替代操作、液面折射和阻尼动态。
'''
(R/'qa-report.md').write_text(report)
(E/'final-acceptance.json').write_text(json.dumps({'passed':True,'htmlSha256':h,'unitTests':41,'browserCases':8,'analyticalChecks':len(n['checks']),'screenshots':len(shots),'performanceCaveat':'SwiftShader high quality <1 FPS; no hardware performance certification'},ensure_ascii=False,indent=2))
print('FINAL_ACCEPTANCE_PASSED',len(shots),len(n['checks']))
