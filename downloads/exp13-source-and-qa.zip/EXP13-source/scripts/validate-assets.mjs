import {readFileSync,writeFileSync} from 'node:fs';
import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js';
import * as T from 'three';
const root=new URL('../',import.meta.url);const bytes=readFileSync(new URL('src/assets/instruments.glb',root));const asset=await new GLTFLoader().parseAsync(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),'');const inventory=JSON.parse(readFileSync(new URL('src/assets/asset-inventory.json',root),'utf8'));
const expected=['Stand','Scale','Cylinder','Tank','BottleWater','BottleBrine'],errors=[];let meshes=0,triangles=0;const materials=new Set();
for(const n of expected)if(!asset.scene.getObjectByName(n))errors.push('Missing apparatus root '+n);
asset.scene.traverse(o=>{if(!o.isMesh)return;meshes++;triangles+=(o.geometry.index?.count||o.geometry.attributes.position.count)/3;for(const p of o.geometry.attributes.position.array)if(!Number.isFinite(p)){errors.push('Nonfinite vertex '+o.name);break}if(!o.material.isMeshStandardMaterial)errors.push('NonPBR material '+o.name);materials.add(o.material.name)});
const tankGlass=asset.scene.getObjectByName('TankGlass');if(!tankGlass||!tankGlass.isMesh||!tankGlass.material.transparent)errors.push('Missing named transparent tank glass');
const nominalVolume=Math.PI*inventory.cylinder.nominalRadius**2*inventory.cylinder.bodyHeight*1e6;if(Math.abs(nominalVolume-100)>1e-8)errors.push('Cylinder nominal SI conversion');
if(inventory.tank.containsBakedWater!==false)errors.push('Baked tank water forbidden');
const boxes={};for(const n of expected){const box=new T.Box3().setFromObject(asset.scene.getObjectByName(n));boxes[n]={min:box.min.toArray(),max:box.max.toArray()};if(n!=='Scale'&&box.min.y<-.0005)errors.push(n+' below table');}
if(boxes.Scale.max.y>.22||boxes.Scale.max.x>.045||boxes.Scale.max.z>.036)errors.push('Scale body orientation/extent invalid');
if(boxes.Cylinder.min.y<-.0001||Math.abs(boxes.Cylinder.max.y-.066)>.0001)errors.push('Cylinder eye height mismatch');
const value={passed:errors.length===0,unit:'metre',expectedRoots:expected,meshes,triangles,materials:[...materials],nominalVolumeCm3:nominalVolume,bounds:boxes,errors,scope:'GLB decoding, named mechanical units, finite vertices, PBR/transparency, floor clearance, nominal cylinder volume and coordinate extents. Browser visual acceptance is separate.'};writeFileSync(new URL('src/assets/asset-validation.json',root),JSON.stringify(value,null,2));console.log(JSON.stringify(value,null,2));if(errors.length)process.exitCode=1;
