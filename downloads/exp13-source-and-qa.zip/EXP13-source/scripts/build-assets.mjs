import * as T from 'three';
import {GLTFExporter} from 'three/examples/jsm/exporters/GLTFExporter.js';
import {mergeGeometries,mergeVertices} from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import {writeFile,mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
if(!globalThis.FileReader)globalThis.FileReader=class{readAsArrayBuffer(b){b.arrayBuffer().then(x=>{this.result=x;this.onloadend?.()})}readAsDataURL(b){b.arrayBuffer().then(x=>{this.result=`data:${b.type};base64,${Buffer.from(x).toString('base64')}`;this.onloadend?.()})}};
const scene=new T.Group();scene.name='EXP13_AuthoredBuoyancyApparatus';
const material=(name,color,metalness,roughness)=>new T.MeshStandardMaterial({name,color,metalness,roughness});
const steel=material('Satin stainless steel','#b2c4cc',.87,.27),aluminium=material('Brushed anodized aluminium','#8ba1a8',.88,.34),dark=material('Midnight enamel cast metal','#23414d',.66,.35),rubber=material('Non marking rubber','#152127',0,.82),ivory=material('Ivory calibrated enamel','#e0e3cf',.12,.4),black=material('Engraved instrument markings','#142b34',.1,.55),brass=material('Brass threaded adjuster','#c5a15c',.85,.28),mint=material('Mint instrument inlay','#85cdbb',.22,.39),blue=material('Brine blue identification','#638ca3',.12,.42),white=material('Water white identification','#d0e4df',.1,.4);
const tankGlass=new T.MeshPhysicalMaterial({name:'TankGlass clear structural glass',color:'#c3e4e8',metalness:0,roughness:.09,transmission:.5,thickness:.003,ior:1.47,transparent:true,opacity:.30,side:T.DoubleSide,depthWrite:false});
const bottleGlass=new T.MeshStandardMaterial({name:'Reagent bottle clear glass',color:'#a8d0d1',metalness:.05,roughness:.18,transparent:true,opacity:.28,depthWrite:false});
const parts={};for(const n of['Stand','Scale','Cylinder','Tank','BottleWater','BottleBrine']){parts[n]=new T.Group();parts[n].name=n;scene.add(parts[n])}let serial=0;
function mesh(g,geo,m,n,p=[0,0,0],r=[0,0,0]){const x=new T.Mesh(geo,m);x.name=n+'_'+(++serial);x.position.set(...p);x.rotation.set(...r);x.castShadow=true;x.receiveShadow=true;g.add(x);return x}
function shape(w,h,r){const s=new T.Shape(),x=-w/2,y=-h/2;s.moveTo(x+r,y);s.lineTo(x+w-r,y);s.quadraticCurveTo(x+w,y,x+w,y+r);s.lineTo(x+w,y+h-r);s.quadraticCurveTo(x+w,y+h,x+w-r,y+h);s.lineTo(x+r,y+h);s.quadraticCurveTo(x,y+h,x,y+h-r);s.lineTo(x,y+r);s.quadraticCurveTo(x,y,x+r,y);return s}
function plate(g,w,d,h,r,m,n,p=[0,0,0]){const geo=new T.ExtrudeGeometry(shape(w,d,r),{depth:h,bevelEnabled:true,bevelSegments:3,steps:1,bevelSize:Math.min(.00065,h*.15),bevelThickness:Math.min(.00065,h*.15),curveSegments:10});geo.translate(0,0,-h/2);geo.rotateX(-Math.PI/2);return mesh(g,geo,m,n,p)}
function cyl(g,ra,rb,h,m,n,p=[0,0,0],r=[0,0,0],segments=40){return mesh(g,new T.CylinderGeometry(ra,rb,h,segments),m,n,p,r)}
function tor(g,ra,t,m,n,p=[0,0,0],r=[Math.PI/2,0,0]){return mesh(g,new T.TorusGeometry(ra,t,7,40),m,n,p,r)}
function screw(g,p,rad=.003){cyl(g,rad,rad,.0015,steel,'Machined captive screw',p,[0,0,0],24);mesh(g,new T.BoxGeometry(rad*1.4,.00022,.00055),black,'Recessed screw slot',[p[0],p[1]+.00085,p[2]])}
function feet(g,w,d){for(const x of[-w,w])for(const z of[-d,d])cyl(g,.010,.012,.007,rubber,'Rubber isolator',[x,.0036,z])}
function post(g,x,y,z,col){cyl(g,.012,.013,.008,col,'Insulating terminal shoulder',[x,y-.014,z]);cyl(g,.008,.008,.019,col,'Binding post knurled cap',[x,y-.002,z]);cyl(g,.003,.003,.024,brass,'Conducting terminal pin',[x,y-.005,z]);tor(g,.0082,.0008,steel,'Terminal cap chamfer',[x,y+.007,z]);for(let k=0;k<20;k++){const a=k*Math.PI*2/20;cyl(g,.00045,.00045,.014,col,'Knurled post rib',[x+Math.cos(a)*.008,y-.002,z+Math.sin(a)*.008],[0,0,0],5)}cyl(g,.0023,.0023,.002,black,'Banana socket opening',[x,y+.009,z])}
function bar(g,w,h,p,m=aluminium,n='Engraved panel line'){return mesh(g,new T.BoxGeometry(w,.0003,h),m,n,p)}
function tube(g,points,r,m,n){return mesh(g,new T.TubeGeometry(new T.CatmullRomCurve3(points.map(p=>new T.Vector3(...p))),Math.min(400,Math.max(16,points.length*4)),r,8,false),m,n)}
function knurled(g,p,r,h,m,n){cyl(g,r,r,h,m,n,p);for(let i=0;i<24;i++){const a=i*Math.PI*2/24;cyl(g,.0005,.0005,h*.78,aluminium,n+' fine knurl',[p[0]+Math.cos(a)*r,p[1],p[2]+Math.sin(a)*r],[0,0,0],5)}}
// Stable stand kept to the left of the tank; original machined compound components.
const st=parts.Stand;const bx=-.24,bz=-.15;
for(const x of[-.327,-.153])for(const z of[-.222,-.078]){cyl(st,.014,.016,.009,rubber,'Stand leveling rubber foot',[x,.0047,z]);tor(st,.0135,.0007,aluminium,'Stand foot adjustment rim',[x,.0095,z]);}
plate(st,.228,.198,.017,.019,dark,'Radiused stand cast base',[bx,.019,bz]);plate(st,.222,.192,.003,.017,aluminium,'Base brushed perimeter',[bx,.029,bz]);plate(st,.210,.180,.002,.015,dark,'Recessed base top',[bx,.031,bz]);
for(const x of[-.328,-.152])for(const z of[-.220,-.080])screw(st,[x,.033,z],.0024);
plate(st,.056,.056,.006,.007,steel,'Column bolted mounting flange',[-.18,.036,-.12]);for(const x of[-.199,-.161])for(const z of[-.139,-.101])screw(st,[x,.040,-.12+(z+.12)],.0022);
cyl(st,.010,.011,.753,steel,'Ground upright support column',[-.18,.420,-.12]);
for(let i=0;i<=70;i++){const y=.067+i*.01;mesh(st,new T.BoxGeometry(i%5===0?.009:.004,.00045,.0005),black,'Etched stand height graduation',[-.176,y,-.1098]);}
for(const y of[.057,.780]){cyl(st,.015,.015,.012,dark,'Column retaining collar',[-.18,y,-.12]);tor(st,.0145,.0008,steel,'Collar polished lip',[-.18,y+.006,-.12]);}
plate(st,.044,.047,.029,.005,dark,'Cantilever clamp block',[-.18,.756,-.12]);cyl(st,.006,.006,.055,brass,'Threaded clamp spindle',[-.18,.756,-.158],[Math.PI/2,0,0]);
for(let i=0;i<10;i++)tor(st,.006,.00035,steel,'Clamp spindle thread',[-.18,.756,-.145-i*.002],[0,0,0]);
cyl(st,.013,.013,.012,dark,'Clamp knurled handwheel',[-.18,.756,-.177],[Math.PI/2,0,0]);for(let i=0;i<20;i++){const a=i*Math.PI*2/20;cyl(st,.0007,.0007,.010,aluminium,'Clamp handwheel knurl',[-.18+Math.cos(a)*.013,.756+Math.sin(a)*.013,-.177],[Math.PI/2,0,0],5)}
tube(st,[[-.18,.756,-.12],[-.07,.756,-.12],[-.01,.756,-.105],[0,.756,-.065],[0,.756,0]],.0055,steel,'Bent stainless suspension arm');
tor(st,.0085,.0014,steel,'Suspension arm hanging eye',[0,.750,0],[0,0,0]);
plate(st,.078,.020,.001,.003,mint,'Stand identity plaque',[-.24,.0325,-.076]);
// Transparent rectangular tank, separate interior with no water baked into the asset.
const ta=parts.Tank;
for(const x of[-.095,.095])for(const z of[-.095,.095])cyl(ta,.012,.014,.012,rubber,'Tank cushioned foot',[x,.0062,z]);
plate(ta,.230,.230,.012,.010,dark,'Tank load bearing bottom cradle',[0,.019,0]);plate(ta,.224,.224,.003,.008,aluminium,'Tank bottom trim rim',[0,.027,0]);
mesh(ta,new T.BoxGeometry(.206,.010,.206),tankGlass,'Tank floor glass',[0,.030,0]);
for(const x of[-.1015,.1015])mesh(ta,new T.BoxGeometry(.003,.238,.206),tankGlass,'Tank side glass',[x,.154,0]);
for(const z of[-.1015,.1015])mesh(ta,new T.BoxGeometry(.200,.238,.003),tankGlass,'Tank front back glass',[0,.154,z]);
for(const x of[-.108,.108]){plate(ta,.006,.224,.004,.002,aluminium,'Tank upper side guard',[x,.273,0]);plate(ta,.006,.220,.004,.002,dark,'Tank lower side band',[x,.040,0]);}
for(const z of[-.108,.108]){plate(ta,.224,.006,.004,.002,aluminium,'Tank upper front back guard',[0,.273,z]);plate(ta,.220,.006,.004,.002,dark,'Tank lower front back band',[0,.040,z]);}
for(const x of[-.108,.108])for(const z of[-.108,.108]){cyl(ta,.0025,.0025,.231,aluminium,'Tank corner protective tie',[x,.154,z], [0,0,0],12);screw(ta,[x,.276,z],.0023)}
for(let cm=1;cm<=22;cm++){const y=.035+cm*.01;mesh(ta,new T.BoxGeometry(cm%5===0?.012:.007,.0007,.0005),mint,'Tank centimetre graduation',[-.087,y,.104]);}
// Spring scale. Parent supplies moving pointer and numbers on the stated front plane.
const sc=parts.Scale;
plate(sc,.082,.170,.036,.012,dark,'Spring scale radiused enclosure',[0,.110,0]);
// plate helper lies horizontal; rotate this case to stand vertically and fix dimensions.
sc.children.at(-1).geometry.rotateX(Math.PI/2);
plate(sc,.076,.166,.002,.010,aluminium,'Meter front perimeter',[0,.110,.020]);sc.children.at(-1).geometry.rotateX(Math.PI/2);
plate(sc,.070,.156,.001,.008,ivory,'Calibrated enamel face substrate',[0,.110,.022]);sc.children.at(-1).geometry.rotateX(Math.PI/2);
for(const x of[-.032,.032])for(const y of[.041,.177]){cyl(sc,.0023,.0023,.0017,steel,'Scale bezel screw',[x,y,.024],[Math.PI/2,0,0],20);mesh(sc,new T.BoxGeometry(.0029,.0005,.00025),black,'Scale screw slot',[x,y,.025]);}
// Actual steel coil remains visible to the left of the parent printed scale.
const coil=[];for(let i=0;i<=300;i++){const t=i/300;coil.push([-.025+Math.cos(t*Math.PI*30)*.0034,.058+t*.108,.029+Math.sin(t*Math.PI*30)*.0034])}tube(sc,coil,.00045,steel,'Visible helical instrument spring');
for(const y of[.054,.170]){cyl(sc,.0035,.0035,.008,brass,'Spring end anchor',[-.025,y,.029]);}
mesh(sc,new T.BoxGeometry(.004,.117,.001),black,'Pointer travel slot',[.005,.101,.023]);
for(let i=0;i<=50;i++){const y=.140-i*.0019;mesh(sc,new T.BoxGeometry(i%5===0?.012:.006,.00035,.0003),black,'5N instrument graduation',[.024,y,.0248]);}
cyl(sc,.005,.005,.005,steel,'Mechanical zero adjuster',[.025,.030,.024],[Math.PI/2,0,0]);mesh(sc,new T.BoxGeometry(.006,.0008,.0006),black,'Zero screw driver slot',[.025,.030,.027]);
const lowerHook=[[0,.028,0],[0,.019,0],[-.004,.011,0],[-.004,.004,0],[0,.001,0],[.006,.003,0],[.007,.009,0]];tube(sc,lowerHook,.0012,steel,'Spring scale lower suspension hook');
cyl(sc,.004,.004,.012,brass,'Lower hook threaded collar',[0,.024,0]);
tor(sc,.009,.0015,steel,'Spring scale top suspension ring',[0,.204,0],[0,0,0]);cyl(sc,.0035,.0035,.010,steel,'Top ring anchor',[0,.194,0]);
for(const x of[-.040,.040]){cyl(sc,.004,.004,.006,aluminium,'Scale side assembly pin',[x,.113,0],[0,0,Math.PI/2],20)}
// Nominal 100 cm³ cylindrical body: ideal enveloping cylinder is used in physics.
const cy=parts.Cylinder,r=Math.sqrt(.000100/(Math.PI*.05));
const profile=[[0,0],[r-.0008,0],[r,.0008],[r,.0492],[r-.0008,.05],[0,.05]].map(p=>new T.Vector2(...p));
mesh(cy,new T.LatheGeometry(profile,64),aluminium,'Nominal 100cm3 machined cylinder');
for(const y of[.002,.048])tor(cy,r-.0002,.00028,steel,'Turned cylinder end rim',[0,y,0]);
for(const y of[.007,.043])tor(cy,r+.00002,.00013,dark,'Cylinder identification groove',[0,y,0]);
cyl(cy,.005,.005,.003,steel,'Cylinder eye threaded seat',[0,.0515,0]);tor(cy,.0055,.001,steel,'Cylinder top suspension eye',[0,.0595,0],[0,0,0]);
plate(cy,.025,.012,.0005,.002,mint,'Cylinder nominal identity plaque',[0,.025,r-.0001]);cy.children.at(-1).geometry.rotateX(Math.PI/2);
// Bottles: lathed shoulder/neck, ribbed threaded cap, wrap label and index ridges.
for(const[name,color]of[['BottleWater',white],['BottleBrine',blue]]){const bo=parts[name];const curve=[[0,.001],[.030,.001],[.036,.006],[.038,.019],[.038,.105],[.035,.119],[.024,.134],[.018,.142],[.018,.160],[0,.160]].map(p=>new T.Vector2(...p));mesh(bo,new T.LatheGeometry(curve,48),bottleGlass,name+' curved glass body');cyl(bo,.034,.034,.093,new T.MeshStandardMaterial({name:name+' transparent liquid',color:name==='BottleWater'?'#78bcca':'#79b9aa',roughness:.15,metalness:0,transparent:true,opacity:name==='BottleWater'?.20:.26,depthWrite:false}),name+' contents visual identity',[0,.054,0]);
 tor(bo,.0345,.001,aluminium,'Bottle bottom edge',[0,.007,0]);for(let i=0;i<3;i++)tor(bo,.0184,.00045,steel,'Bottle neck screw thread',[0,.148+i*.003,0]);knurled(bo,[0,.167,0],.023,.023,dark,'Threaded bottle safety cap');tor(bo,.022,.0006,steel,'Bottle cap lower edge',[0,.156,0]);
 const label=plate(bo,.060,.050,.0007,.005,ivory,'Bottle write on label',[0,.070,.038]);label.geometry.rotateX(Math.PI/2);for(let i=0;i<3;i++)mesh(bo,new T.BoxGeometry(i===0?.037:.043,.0012,.0003),color,'Bottle label ruled identifier',[0,.079-i*.010,.039]);
 for(const x of[-.015,0,.015])mesh(bo,new T.BoxGeometry(.001,.003,.0003),black,'Bottle type code',[x,.057,.039]);
}
scene.updateMatrixWorld(true);const counts={};
for(const[name,g]of Object.entries(parts)){const buckets=new Map();let components=0;g.traverse(o=>{if(!o.isMesh)return;components++;let geo=o.geometry.clone().applyMatrix4(o.matrixWorld);if(!geo.index)geo=mergeVertices(geo);const list=buckets.get(o.material)||[];list.push(geo);buckets.set(o.material,list)});g.clear();for(const[m,geos]of buckets){const o=mesh(g,mergeGeometries(geos,false),m,name+' '+m.name);if(name==='Tank'&&m===tankGlass)o.name='TankGlass'}g.userData={unit:'metre',authoredComponents:components};counts[name]=components}
scene.updateMatrixWorld(true);const glb=await new GLTFExporter().parseAsync(scene,{binary:true,onlyVisible:true});await mkdir(root+'src/assets',{recursive:true});await writeFile(root+'src/assets/instruments.glb',Buffer.from(glb));
const inventory={asset:'instruments.glb',source:'Original detailed compound apparatus generated by this script, without downloaded assets',unit:'metre',bytes:glb.byteLength,roots:{},totalTriangles:0,totalMeshes:0,tank:{innerWidth:.20,innerDepth:.20,innerFloorY:.035,rimY:.275,glassMesh:'TankGlass',containsBakedWater:false},scale:{lowerHook:[0,0,0],topRing:[0,.204,0],faceCenter:[0,.102,.024],faceWidth:.07,faceHeight:.14,front:'+Z',overlayZ:.026,pointerZ:.035,zeroTickY:.140,fullScaleTickY:.045,rangeN:5,divisionN:.1},cylinder:{nominalVolumeCm3:100,bodyHeight:.05,nominalRadius:r,bodyBottomY:0,bodyTopY:.05,eyeCenter:[0,.0595,0],eyeTopY:.066},stand:{columnXZ:[-.18,-.12],baseCenterXZ:[-.24,-.15],suspensionPoint:[0,.750,0]},bottles:{radius:.038,height:.18}};
for(const[name,g]of Object.entries(parts)){let meshes=0,triangles=0;g.traverse(o=>{if(o.isMesh){meshes++;triangles+=(o.geometry.index?.count||o.geometry.attributes.position.count)/3}});const box=new T.Box3().setFromObject(g);inventory.roots[name]={meshes,triangles,authoredComponents:counts[name],min:box.min.toArray(),max:box.max.toArray()};inventory.totalTriangles+=triangles;inventory.totalMeshes+=meshes}
await writeFile(root+'src/assets/asset-inventory.json',JSON.stringify(inventory,null,2));console.log(JSON.stringify(inventory,null,2));
