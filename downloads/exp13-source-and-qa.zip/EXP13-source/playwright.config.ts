import { defineConfig } from '@playwright/test';
const run = (process.env.EXP13_BROWSER_RUN ?? 'final').replace(/[^a-zA-Z0-9_-]/g, '');
export default defineConfig({
  testDir: 'tests', outputDir: 'evidence/browser-replays-' + run,
  timeout: 240000, expect: { timeout: 20000 }, workers: 1, fullyParallel: false, retries: 0,
  reporter: [['list'], ['json', { outputFile: 'evidence/browser-results-' + run + '.json' }]],
  use: {
    viewport: { width: 1440, height: 1000 }, headless: true, actionTimeout: 12000, navigationTimeout: 30000,
    trace: 'on', video: 'on', screenshot: 'only-on-failure',
    launchOptions: { args: ['--no-sandbox', '--enable-precise-memory-info', '--enable-unsafe-swiftshader', '--use-gl=angle', '--use-angle=swiftshader'] },
  },
});
