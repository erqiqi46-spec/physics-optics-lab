import { test, expect, type Page } from '@playwright/test';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs';

const html = resolve('dist/index.html');
const url = pathToFileURL(html).href;
const devices = ['scale', 'body', 'tank', 'liquids'] as const;
const conclusion = '浮力与排开液体的体积、液体密度有关；保持物体及液体不变，完全浸没后仅增加深度，浮力不变。触底或绳松弛时不能直接用称重法。';
let htmlSha256 = '', snapshots: any[] = [], errors: string[] = [], remoteRequests: string[] = [];
const read = (p: Page) => p.evaluate(() => (window as any).__EXP13.read());
test.beforeAll(() => {
  if (!existsSync(html)) throw new Error('Build this EXP13 source before browser acceptance.');
  htmlSha256 = createHash('sha256').update(readFileSync(html)).digest('hex');
  mkdirSync('evidence/screenshots', { recursive: true }); mkdirSync('evidence/cases', { recursive: true });
  const old = existsSync('evidence/browser-case-evidence.json') ? JSON.parse(readFileSync('evidence/browser-case-evidence.json', 'utf8')) : [];
  snapshots = old.filter((x: any) => (x.artifactSha256 ?? x.htmlSha256) === htmlSha256);
  writeFileSync('evidence/browser-case-evidence.json', JSON.stringify(snapshots, null, 2));
});
test.beforeEach(async ({ context }) => { errors = []; remoteRequests = []; await context.setOffline(true); });
test.afterEach(() => {
  expect(errors, 'No unhandled page errors').toEqual([]);
  expect(remoteRequests, 'The independent HTML must not request a remote CDN').toEqual([]);
});
function watch(p: Page) {
  p.on('pageerror', e => errors.push(e.message));
  p.on('request', r => { if (/^https?:/i.test(r.url())) remoteRequests.push(r.url()); });
}
async function shot(p: Page, name: string) {
  const screenshot = `evidence/screenshots/${name}.png`;
  await p.screenshot({ path: screenshot, fullPage: true });
  const item = { case: name, artifactSha256: htmlSha256, htmlSha256, url, screenshot, offline: true, viewport: p.viewportSize(), state: await read(p),
    usedJsHeapSize: await p.evaluate(() => (performance as any).memory?.usedJSHeapSize ?? null) };
  const previous = snapshots.findIndex(x => x.case === name);
  if (previous < 0) snapshots.push(item); else snapshots.splice(previous, 1, item);
  writeFileSync(`evidence/cases/${name}.json`, JSON.stringify(item, null, 2));
  writeFileSync('evidence/browser-case-evidence.json', JSON.stringify(snapshots, null, 2));
  await test.info().attach(name, { path: screenshot, contentType: 'image/png' });
}
async function open(p: Page, mode = 'teach', minutes?: number) {
  watch(p); await p.goto(url);
  if (mode !== 'teach') await p.getByTestId('start-mode-' + mode).click();
  if (minutes !== undefined) await p.getByTestId('exam-minutes').fill(String(minutes));
  await p.getByTestId('start').click(); await p.getByLabel('画质').selectOption('low');
  await p.waitForFunction(() => (window as any).__EXP13?.read().stats.ready === true);
}
async function inventory(p: Page) {
  for (const d of devices) await p.getByTestId('inspect-' + d).click();
  await p.getByTestId('confirm-inventory').click(); expect((await read(p)).session.inventoryConfirmed).toBe(true);
}
async function prepare(p: Page) {
  await inventory(p); expect((await read(p)).session.attached).toBe(false);
  await p.getByTestId('zero-minus').click(); expect((await read(p)).session.zeroOffsetN).toBe(0);
  await p.getByTestId('attach').click(); expect((await read(p)).session.attached).toBe(true);
  await expect.poll(async () => (await read(p)).stats.scaleReadingN).toBeCloseTo(2.7, 8);
}
async function height(p: Page, h: number) {
  await p.getByTestId('input-height').fill(String(h));
  await expect.poll(async () => (await read(p)).session.cfg.bottomCm).toBe(h);
}
async function front(p: Page) {
  await p.getByTestId('camera-front').click(); await p.getByTestId('scene').scrollIntoViewIfNeeded();
  for (const [i, v] of [0, .43, 1.20].entries()) await expect.poll(async () => (await read(p)).stats.camera[i]).toBeCloseTo(v, 3);
}
function point(v: any) { return Array.isArray(v) ? { x: v[0], y: v[1] } : { x: v.x, y: v.y }; }
async function canvasPoint(p: Page, v: any) {
  const position = point(v);
  expect(await p.evaluate(a => document.elementFromPoint(a.x, a.y)?.tagName, position), 'The 3D scale must be directly reachable on the canvas').toBe('CANVAS');
  return position;
}
async function dragHeight(p: Page, h: number) {
  await p.getByTestId('scene').scrollIntoViewIfNeeded();
  const before = await read(p), start = await canvasPoint(p, before.targets.scale), end = point(before.targets['height-' + h]);
  expect(end.x).toBeGreaterThan(0); expect(end.y).toBeGreaterThan(0);
  await p.mouse.move(start.x, start.y); await p.mouse.down();
  await p.mouse.move(end.x, end.y, { steps: 14 }); await p.mouse.up();
  const dragged = await read(p);
  expect(Math.abs(dragged.session.cfg.bottomCm - h), 'Native drag must reach the requested apparatus position before fine adjustment').toBeLessThanOrEqual(.375);
  if (Math.abs(before.session.cfg.bottomCm - h) > .5) expect(dragged.session.cfg.bottomCm).not.toBe(before.session.cfg.bottomCm);
  for (let i = 0; i < 3; i++) expect(dragged.stats.camera[i]).toBeCloseTo(before.stats.camera[i], 2);
  // Subpixel pointer quantization can span one graduation. Correct only with
  // the real fine-adjustment buttons, never through a state injection.
  if (before.session.submitted && h === 24 && dragged.session.cfg.bottomCm >= 24) return;
  for (let i = 0; i < 3; i++) {
    const actual = (await read(p)).session.cfg.bottomCm;
    if (actual === h) break;
    await p.getByTestId(actual < h ? 'fineup' : 'finedown').click();
  }
  expect((await read(p)).session.cfg.bottomCm).toBe(h);
}
async function record(p: Page, G: number, F: number, B: number, rho: number, state: string, purpose: string) {
  const count = (await read(p)).session.rows.length;
  for (const [id, v] of [['read-gravity', G], ['read-force', F], ['read-buoyancy', B], ['read-density', rho]] as const)
    await p.getByTestId(id).fill(String(v));
  await p.getByTestId('read-state').selectOption(state); await p.getByTestId('read-purpose').selectOption(purpose);
  for (const id of ['zero', 'suspended', 'unit']) await p.getByTestId('check-' + id).check();
  await p.getByTestId('save-record').click(); expect((await read(p)).session.rows).toHaveLength(count + 1);
}
async function assertReading(p: Page, expectedN: number) {
  await expect.poll(async () => (await read(p)).stats.scaleReadingN).toBeCloseTo(expectedN, 7);
  await expect.poll(async () => Number(await p.getByTestId('scale-pointer').first().getAttribute('data-reading'))).toBeCloseTo(expectedN, 7);
}
async function assertDiagram(p: Page, volume: number, buoyancy: number, immersion?: number, depth?: number) {
  const d = p.getByTestId('buoyancy-diagram');
  await expect.poll(async () => Number(await d.getAttribute('data-displaced'))).toBeCloseTo(volume, 7);
  await expect.poll(async () => Number(await d.getAttribute('data-buoyancy'))).toBeCloseTo(buoyancy, 7);
  if (immersion !== undefined) await expect.poll(async () => Number(await d.getAttribute('data-immersion'))).toBeCloseTo(immersion, 7);
  if (depth !== undefined) await expect.poll(async () => Number(await d.getAttribute('data-depth'))).toBeCloseTo(depth, 7);
}
async function examHidden(p: Page) {
  for (const id of ['teacher-view', 'prediction-topic', 'prediction-choice', 'run-demo', 'diagram-volume', 'diagram-buoyancy', 'data-curve', 'evaluation'])
    await expect(p.getByTestId(id)).toHaveCount(0);
  for (const attr of ['data-immersion', 'data-displaced', 'data-depth', 'data-buoyancy'])
    expect(await p.getByTestId('buoyancy-diagram').getAttribute(attr)).toBeNull();
  await expect(p.getByTestId('records')).not.toContainText('自查');
  const a = await read(p); expect(a.result).toBeUndefined();
  expect(a.session.rows.every((r: any) => !('expected' in r) && !('valid' in r) && !('reasons' in r))).toBe(true);
}
async function normalRows(p: Page, native = false, capture = false) {
  const move = native ? dragHeight : height;
  if (native) { await front(p); await dragHeight(p, 32); await dragHeight(p, 24); }
  await expect(p.getByTestId('read-gravity')).toHaveValue(''); await expect(p.getByTestId('read-force')).toHaveValue('');
  await record(p, 2.7, 2.7, 0, 1000, 'air', 'air');
  expect((await read(p)).session.measuredAirGravityN).toBe(2.7);
  if (capture) await shot(p, '01-air-gravity');
  await move(p, 11.625); await assertReading(p, 2.2);
  await expect(p.getByTestId('read-force')).toHaveValue('2.7'); // no automatic replacement with the answer
  if (!native) await assertDiagram(p, 50, .5, 2.5, 0);
  await record(p, 2.7, 2.2, .5, 1000, 'partial', 'volume'); if (capture) await shot(p, '02-partial-volume');
  await move(p, 8); await assertReading(p, 1.7);
  if (!native) await assertDiagram(p, 100, 1, 5, 1.25);
  await record(p, 2.7, 1.7, 1, 1000, 'full', 'volume'); if (capture) await shot(p, '03-full-immersion');
  await move(p, 3); await assertReading(p, 1.7); if (!native) await assertDiagram(p, 100, 1, 5, 6.25);
  await record(p, 2.7, 1.7, 1, 1000, 'full', 'depth');
  await move(p, 24); await p.getByTestId('liquid-brine').click(); await move(p, 8); await assertReading(p, 1.5);
  if (!native) await assertDiagram(p, 100, 1.2, 5, 1.25);
  await record(p, 2.7, 1.5, 1.2, 1200, 'full', 'density'); if (capture) await shot(p, '04-controlled-density');
  await move(p, 24); await p.getByTestId('liquid-water').click(); await move(p, 8); await assertReading(p, 1.7);
  await record(p, 2.7, 1.7, 1, 1000, 'full', 'repeat');
}
async function submitCleanup(p: Page) {
  await p.getByTestId('conclusion').fill(conclusion); p.once('dialog', d => d.accept()); await p.getByTestId('submit').click();
  await expect(p.getByTestId('evaluation')).toHaveCount(0);
  if ((await read(p)).mode === 'exam') await examHidden(p);
  await front(p); await dragHeight(p, 24);
  if ((await read(p)).session.cfg.liquid !== 'water') await p.getByTestId('liquid-water').click();
  await p.getByTestId('detach').click();
  for (const d of devices) await p.getByTestId('stow-' + d).click();
  await expect(p.getByTestId('evaluation')).toBeVisible(); expect((await read(p)).session.returned).toBe(true);
  expect((await read(p)).session.attached).toBe(false);
}
async function score(p: Page) { return Number((await p.getByTestId('score').innerText()).match(/^\s*(\d+(?:\.\d+)?)/)?.[1]); }

test('01 教学规范：称G、体积、浸没后加深、等体积换液、真实重复及归位', async ({ page }) => {
  await open(page); await expect(page.getByTestId('data-curve')).toHaveCount(0);
  await prepare(page); await normalRows(page, false, true);
  const a = await read(page); expect(a.session.rows).toHaveLength(6); expect(a.session.rows.every((r: any) => r.valid)).toBe(true);
  expect(a.session.rows.map((r: any) => r.readingN)).toEqual([2.7, 2.2, 1.7, 1.7, 1.5, 1.7]);
  expect(a.session.rows.map((r: any) => r.buoyancyN)).toEqual([0, .5, 1, 1, 1.2, 1]);
  expect(a.session.rows[2].expected.displacedCm3).toBe(a.session.rows[3].expected.displacedCm3);
  expect(a.session.rows[3].expected.depthCm).toBeGreaterThan(a.session.rows[2].expected.depthCm);
  const curve = page.getByTestId('data-curve');
  await expect(curve).toHaveAttribute('data-source', 'recorded-data');
  await expect(curve).toHaveAttribute('data-count', '6');
  await expect(curve.locator('circle[data-record-point]')).toHaveCount(6);
  await expect(curve.locator('[data-recorded-line]')).toHaveCount(1);
  await expect(curve.locator('[data-recorded-line]').first()).toHaveAttribute('data-recorded-line', '1000');
  for (const axis of ['cx', 'cy']) expect(await curve.locator('[data-record-point]').nth(5).getAttribute(axis)).toBe(await curve.locator('[data-record-point]').nth(2).getAttribute(axis));
  await shot(page, '05-repeat-and-six-records'); await page.getByTestId('scale-enlarge').click();
  await expect(page.getByRole('dialog')).toContainText('测力计实时放大观察');
  await page.getByRole('button', { name: '返回操作', exact: true }).click();
  await submitCleanup(page); await shot(page, '06-teach-returned');
});

test('02 三类真实错误：触底G−F含支持力、未浸没比较深度、换液时V排不一致', async ({ page }) => {
  await open(page, 'free'); await prepare(page); await record(page, 2.7, 2.7, 0, 1000, 'air', 'air');
  await height(page, 0); const bottom = (await read(page)).result;
  expect(bottom.state).toBe('bottom'); expect(bottom.tensionN).toBe(0); expect(bottom.normalN).toBeCloseTo(1.7, 9);
  expect(bottom.buoyancyN).toBeCloseTo(1, 9); expect(bottom.apparentBuoyancyN).toBe(2.7);
  await assertReading(page, 0); await expect(page.getByTestId('fault-panel')).toContainText('支持力');
  await record(page, 2.7, 0, 2.7, 1000, 'bottom', 'volume');
  expect((await read(page)).session.rows.at(-1).valid).toBe(false);
  const invalidPoint = page.getByTestId('data-curve').locator('[data-record-point]').nth(1);
  await expect(invalidPoint.locator('title')).toContainText('填写F浮=2.7 N');
  await expect(invalidPoint).toHaveAttribute('fill', '#10232e');
  await expect(page.getByTestId('data-curve').locator('[data-recorded-line]')).toHaveCount(0);
  await shot(page, '07-error-bottom-support');
  await height(page, 11.625); await record(page, 2.7, 2.2, .5, 1000, 'partial', 'depth');
  expect((await read(page)).session.rows.at(-1).valid).toBe(false);
  await expect(page.getByTestId('records')).toContainText('比较深度前物体必须浸没'); await shot(page, '08-error-depth-while-partial');
  await height(page, 8); await record(page, 2.7, 1.7, 1, 1000, 'full', 'volume');
  await height(page, 24); await page.getByTestId('liquid-brine').click(); await height(page, 11.625);
  await record(page, 2.7, 2.1, .6, 1200, 'partial', 'density');
  const state = await read(page); expect(state.session.rows.at(-1).valid).toBe(false);
  expect(new Set(state.session.events.filter((e: any) => e.type === 'error').map((e: any) => e.detail.category))).toEqual(new Set(['bottom', 'depth-not-full', 'density-volume']));
  await expect(page.getByTestId('records')).toContainText('排开液体体积'); await shot(page, '09-error-density-volume-uncontrolled');
  // Partial immersion itself is not wrong: an equal displaced volume is a
  // valid density comparison. The preceding rejected pair was100cm³→50cm³.
  await height(page, 24); await page.getByTestId('liquid-water').click(); await height(page, 11.625);
  await record(page, 2.7, 2.2, .5, 1000, 'partial', 'volume');
  expect((await read(page)).session.rows.at(-1).valid).toBe(true);
  await height(page, 24); await page.getByTestId('liquid-brine').click(); await height(page, 11.625);
  await record(page, 2.7, 2.1, .6, 1200, 'partial', 'density');
  const controlled = (await read(page)).session.rows.slice(-2);
  expect(controlled.every((r: any) => r.valid)).toBe(true);
  expect(controlled.map((r: any) => r.expected.displacedCm3)).toEqual([50, 50]);
  expect(controlled.map((r: any) => r.expected.buoyancyN)).toEqual([.5, .6]);
  await shot(page, '09b-valid-partial-density-equal-volume');
});

test('03 极端轻物体浮起：50g/150cm³、绳松弛零张力，不能压入水或称重记录', async ({ page }) => {
  await open(page, 'free'); await prepare(page);
  await page.getByTestId('input-mass').fill('50'); await page.getByTestId('input-volume').fill('150');
  const cfg = (await read(page)).session.cfg; expect(cfg.massKg).toBe(.05); expect(cfg.volumeCm3).toBe(150);
  await assertReading(page, .5); await record(page, .5, .5, 0, 1000, 'air', 'air'); await shot(page, '10-extreme-light-air-reference');
  await height(page, 0); const q = (await read(page)).result;
  expect(q.state).toBe('floating'); expect(q.lineSlack).toBe(true); expect(q.tensionN).toBe(0); expect(q.normalN).toBe(0);
  expect(q.buoyancyN).toBeCloseTo(.5, 9); expect(q.displacedCm3).toBeCloseTo(50, 9);
  expect(q.bodyBottomCm).toBeGreaterThan(12); expect(q.commandBottomCm).toBe(0); expect(q.validSuspended).toBe(false);
  await expect.poll(async () => (await read(page)).stats.objects.body[1]).toBeGreaterThan(.1);
  await assertReading(page, 0); await assertDiagram(page, 50, .5);
  await expect(page.getByTestId('fault-panel')).toContainText('绳');
  await record(page, .5, 0, .5, 1000, 'floating', 'volume'); expect((await read(page)).session.rows.at(-1).valid).toBe(false);
  await shot(page, '11-extreme-floating-slack');
});

test('04 真实竖拖与双向同步、冻结、量程约束、模式保存丢弃和完整重置', async ({ page }) => {
  await open(page, 'free'); const initialCamera = (await read(page)).stats.camera;
  await prepare(page); await front(page); await dragHeight(page, 11.625); await assertReading(page, 2.2);
  await expect(page.getByTestId('input-height')).toHaveValue('11.625'); await assertDiagram(page, 50, .5);
  const beforeY = (await read(page)).stats.objects.body[1]; await height(page, 3); await assertReading(page, 1.7);
  await expect.poll(async () => (await read(page)).stats.objects.body[1]).toBeLessThan(beforeY);
  await page.getByTestId('freeze').click(); await expect(page.getByTestId('input-height')).toHaveAttribute('readonly', '');
  expect((await read(page)).session.cfg.bottomCm).toBe(3); await page.getByTestId('freeze').click();
  await height(page, 32); await page.getByTestId('input-height').fill('999'); expect((await read(page)).session.cfg.bottomCm).toBe(32);
  await page.getByTestId('input-height').fill('-8'); expect((await read(page)).session.cfg.bottomCm).toBe(0);
  await height(page, 24); await page.getByTestId('input-mass').fill('320'); await page.getByTestId('input-density').fill('1250');
  await page.getByTestId('liquid-brine').click(); await shot(page, '12-bidirectional-and-parameters');
  await page.getByTestId('mode-teach').click(); await expect(page.getByRole('dialog')).toContainText('是否保存');
  await page.getByTestId('save-switch').click(); await page.getByTestId('start').click();
  expect((await read(page)).session.cfg.massKg).toBe(.27); expect((await read(page)).session.cfg.liquid).toBe('water');
  await page.getByTestId('mode-free').click(); await page.getByTestId('save-switch').click();
  expect((await read(page)).session.cfg.massKg).toBe(.32); expect((await read(page)).session.cfg.densityKgM3).toBe(1250);
  await page.getByTestId('read-gravity').fill('3.2'); await page.getByTestId('read-force').fill('2');
  await page.getByTestId('read-buoyancy').fill('1.2'); await page.getByTestId('read-state').selectOption('full');
  await page.getByTestId('read-purpose').selectOption('depth'); await page.getByTestId('check-unit').check();
  await page.getByTestId('conclusion').fill('尚未提交的临时草稿');
  page.once('dialog', d => d.accept()); await page.getByRole('button', { name: '↺ 重置', exact: true }).click(); await page.getByTestId('start').click();
  const fresh = await read(page); expect(fresh.session.cfg.bottomCm).toBe(24); expect(fresh.session.cfg.liquid).toBe('water');
  expect(fresh.session.cfg.massKg).toBe(.27); expect(fresh.session.attached).toBe(false); expect(fresh.session.rows).toHaveLength(0);
  for (const id of ['read-gravity', 'read-force', 'read-buoyancy', 'conclusion']) await expect(page.getByTestId(id)).toHaveValue('');
  await expect(page.getByTestId('read-state')).toHaveValue('air'); await expect(page.getByTestId('read-purpose')).toHaveValue('air');
  await expect(page.getByTestId('check-unit')).not.toBeChecked();
  for (let i = 0; i < 3; i++) await expect.poll(async () => (await read(page)).stats.camera[i]).toBeCloseTo(initialCamera[i], 2);
  await height(page, 32); await page.getByTestId('mode-teach').click(); await page.getByTestId('discard-switch').click();
  await page.getByTestId('mode-free').click(); await page.getByTestId('save-switch').click(); await page.getByTestId('start').click();
  expect((await read(page)).session.cfg.bottomCm).toBe(24); await shot(page, '13-full-reset-and-discard');
});

test('05 模拟考核：只读面板、实际3D升降六组测量、隐藏理论直到归位后100分', async ({ page }) => {
  await open(page, 'exam'); const s = (await read(page)).session; expect(s.deadline - s.startedAt).toBe(900000);
  await examHidden(page); await expect(page.getByTestId('input-height')).toHaveAttribute('readonly', '');
  await prepare(page); await normalRows(page, true); await examHidden(page);
  expect((await read(page)).session.rows.map((r: any) => r.readingN)).toEqual([2.7, 2.2, 1.7, 1.7, 1.5, 1.7]);
  await shot(page, '14-exam-six-independent-readings'); await submitCleanup(page);
  expect(await score(page)).toBe(100); await expect(page.getByTestId('evaluation')).toContainText('非官方');
  await expect(page.getByTestId('data-curve')).toHaveAttribute('data-count', '6');
  await expect(page.getByTestId('data-curve').locator('circle[data-record-point]')).toHaveCount(6);
  await shot(page, '15-exam-result-after-return');
});

test('06 考核墙钟：刷新保留独立空气测量与截止时间，超时锁定且不提前揭示', async ({ page }) => {
  await page.clock.install(); await open(page, 'exam', 1); await prepare(page);
  await record(page, 2.7, 2.7, 0, 1000, 'air', 'air'); const before = await read(page);
  await page.reload(); await expect(page.getByTestId('timer')).toBeVisible(); const restored = await read(page);
  expect(restored.session.deadline).toBe(before.session.deadline); expect(restored.session.startedAt).toBe(before.session.startedAt);
  expect(restored.session.attached).toBe(true); expect(restored.session.rows).toHaveLength(1);
  await page.clock.fastForward(61000); await expect.poll(async () => (await read(page)).session.expired).toBe(true);
  await expect(page.getByTestId('save-record')).toBeDisabled(); await expect(page.getByTestId('conclusion')).toBeDisabled();
  await examHidden(page); await shot(page, '16-exam-timeout-and-recovery');
});

test('07 教师投影、先预测再真实体积/深度/密度/触底演示、可立即接管', async ({ page }) => {
  await open(page); await prepare(page); await page.getByTestId('teacher-view').click();
  await expect(page.locator('main')).toHaveClass(/presentation/); await expect(page.locator('aside.controls')).toBeHidden();
  await shot(page, '17-teacher-presentation'); await page.getByTestId('teacher-view').click();
  await expect(page.locator('aside.controls')).toBeVisible();
  for (const [topic, choice] of [['volume', 'increase'], ['depth', 'unchanged'], ['density', 'increase'], ['bottom', 'invalid']]) {
    await page.getByTestId('prediction-topic').selectOption(topic); await expect(page.getByTestId('run-demo')).toBeDisabled();
    await page.getByTestId('prediction-choice').selectOption(choice); await page.getByTestId('run-demo').click();
    await expect(page.getByTestId('demo-status')).toContainText('演示完成'); const a = await read(page);
    expect(a.session.rows).toHaveLength(0);
    if (topic === 'volume') { expect(a.result.displacedCm3).toBeCloseTo(100, 8); expect(a.result.buoyancyN).toBeCloseTo(1, 8); }
    if (topic === 'depth') { expect(a.result.isFull).toBe(true); expect(a.session.cfg.bottomCm).toBe(3); expect(a.result.buoyancyN).toBeCloseTo(1, 8); }
    if (topic === 'density') { expect(a.result.liquid).toBe('brine'); expect(a.result.buoyancyN).toBeCloseTo(1.2, 8); }
    if (topic === 'bottom') { expect(a.result.state).toBe('bottom'); expect(a.result.normalN).toBeGreaterThan(0); expect(a.result.validSuspended).toBe(false); }
    await shot(page, '18-demonstration-' + topic);
  }
  await page.getByTestId('prediction-topic').selectOption('volume'); await page.getByTestId('run-demo').click();
  await page.getByTestId('take-over').click();
  if (!(await read(page)).session.attached) await page.getByTestId('attach').click();
  await height(page, 13); const taken = await read(page); await page.waitForTimeout(3200);
  expect((await read(page)).session.cfg).toEqual(taken.session.cfg); await shot(page, '19-student-takeover');
});

test('08 手机原生触摸竖拖和键盘升降、390px与1280x720离线自适应', async ({ browser }) => {
  const context = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true,
    recordVideo: { dir: 'evidence/mobile-replay', size: { width: 390, height: 844 } } });
  await context.setOffline(true); const p = await context.newPage(); await open(p, 'free'); await prepare(p);
  await record(p, 2.7, 2.7, 0, 1000, 'air', 'air'); await front(p);
  await p.getByTestId('scene').scrollIntoViewIfNeeded(); const before = await read(p);
  const start = await canvasPoint(p, before.targets.scale), end = point(before.targets['height-11.625']);
  const cdp = await context.newCDPSession(p);
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ ...start, id: 1 }] });
  for (let i = 1; i <= 12; i++) {
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: start.x + (end.x - start.x) * i / 12, y: start.y + (end.y - start.y) * i / 12, id: 1 }] });
    await p.waitForTimeout(35);
  }
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  const after = await read(p); expect(Math.abs(after.session.cfg.bottomCm - 11.625)).toBeLessThanOrEqual(.375);
  expect(after.session.cfg.bottomCm).not.toBe(before.session.cfg.bottomCm);
  for (let i = 0; i < 3; i++) expect(after.stats.camera[i]).toBeCloseTo(before.stats.camera[i], 2);
  const value = after.session.cfg.bottomCm; await p.getByTestId('raise').focus(); await p.keyboard.press('Enter');
  expect((await read(p)).session.cfg.bottomCm).toBe(value + .5);
  await expect(p.getByTestId('data-curve')).toHaveAttribute('data-count', '1');
  const graphBox = await p.getByTestId('data-curve').boundingBox(); expect(graphBox?.width).toBeLessThanOrEqual(390);
  expect(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true); await shot(p, '20-mobile-native-touch');
  await context.close();
  const desktop = await browser.newContext({ viewport: { width: 1280, height: 720 } }); await desktop.setOffline(true);
  const d = await desktop.newPage(); await open(d); expect(await d.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await shot(d, '21-desktop-720'); await desktop.close();
});
