# 阶段可运行产物与对照

physics/与lesson/模块先分别完成公式/状态数值测试，再将交互和原创资产集成到完整HTML；未独立保存的早期HTML不虚构。

`03-core-before-data-curve/index.html` 是补充记录曲线前的真实可运行集成快照，原始8/8浏览器报告和日志保留在同目录。`before-data-curve.png`为该阶段六组记录实际截图。该快照不是最终交付，请勿用它代替最终验收。

最终运行版本在dist/index.html；新增曲线只使用真实记录、按密度分组、无预设理论线，新增考核隐藏及点数检查后再次完整验收。最终对照截图在evidence/screenshots/05-repeat-and-six-records.png，各案例绑定最终HTML哈希。
