import {it,expect} from 'vitest';
import {mkdirSync,writeFileSync} from 'node:fs';
import {solveBuoyancy,DEFAULT_CONFIG,type Config} from './buoyancy';
it('writes actual numerical case evidence without fabricated measurements',()=>{
 const defs:{name:string;cfg:Partial<Config>;B:number;T:number;V:number;valid:boolean}[]=[
  {name:'air-weight',cfg:{bottomCm:22},B:0,T:2.7,V:0,valid:true},
  {name:'half-water',cfg:{bottomCm:11.625},B:.5,T:2.2,V:50,valid:true},
  {name:'full-water-shallow',cfg:{bottomCm:8},B:1,T:1.7,V:100,valid:true},
  {name:'full-water-deeper',cfg:{bottomCm:3},B:1,T:1.7,V:100,valid:true},
  {name:'full-brine1200',cfg:{bottomCm:8,liquid:'brine',densityKgM3:1200},B:1.2,T:1.5,V:100,valid:true},
  {name:'error-bottom-contact',cfg:{bottomCm:0},B:1,T:0,V:100,valid:false},
  {name:'error-slack-floating',cfg:{bottomCm:0,massKg:.05},B:.5,T:0,V:50,valid:false},
  {name:'extreme-heavy-air',cfg:{bottomCm:32,massKg:.45,volumeCm3:50},B:0,T:4.5,V:0,valid:true},
  {name:'repeat-full-water',cfg:{bottomCm:8},B:1,T:1.7,V:100,valid:true}
 ];
 const cases=defs.map(d=>{const config={...DEFAULT_CONFIG,...d.cfg},actual=solveBuoyancy(config),errorN=Math.max(Math.abs(actual.buoyancyN-d.B),Math.abs(actual.tensionN-d.T)),errorCm3=Math.abs(actual.displacedCm3-d.V);expect(errorN,d.name).toBeLessThan(1e-9);expect(errorCm3,d.name).toBeLessThan(1e-9);expect(actual.validSuspended).toBe(d.valid);return{case:d.name,config,expected:{buoyancyN:d.B,tensionN:d.T,displacedCm3:d.V,validSuspended:d.valid},actual,errorN,errorCm3,passed:true}});
 expect(cases[2].actual).toEqual(cases[8].actual);mkdirSync('evidence',{recursive:true});writeFileSync('evidence/numerical-cases.json',JSON.stringify({model:'quasi-static Archimedes + liquid volume conservation + unilateral rope/contact',gNPerKg:10,tolerance:1e-9,passed:true,cases},null,2));
});
