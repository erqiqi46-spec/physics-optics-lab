/** Deterministic quasi-static Archimedes model. Length cm, volume cm³, force N. */
export type Liquid='water'|'brine';
export interface Config {bottomCm:number;liquid:Liquid;densityKgM3?:number;massKg:number;volumeCm3:number;bodyHeightCm?:number;waterBaseCm?:number}
export type BuoyancyConfig=Config;
export const G=10;
export const TANK={floorWorldM:.035,depthCm:24,areaCm2:400} as const;
export const LIMITS={bottomCm:{min:0,max:32},massKg:{min:.05,max:.45},volumeCm3:{min:50,max:150},bodyHeightCm:{min:3,max:10},densityKgM3:{min:1000,max:1250},waterBaseCm:{min:8,max:18},springMaxN:5,springDivisionN:.1} as const;
export const DEFAULT_CONFIG:Config={bottomCm:22,liquid:'water',densityKgM3:1200,massKg:.27,volumeCm3:100,bodyHeightCm:5,waterBaseCm:14};
export interface Result {
 commandBottomCm:number;bodyBottomCm:number;bodyTopCm:number;surfaceCm:number;immersionCm:number;displacedCm3:number;submergedFraction:number;
 /** Nonnegative depth of the top face; 0 until the entire cylinder is underwater. */
 depthCm:number;
 /** Signed depths below surface, negative when above it. */
 topDepthCm:number;centerDepthCm:number;
 buoyancyN:number;gravityN:number;tensionN:number;normalN:number;apparentBuoyancyN:number;
 validSuspended:boolean;state:'air'|'partial'|'full'|'bottom'|'floating';isFull:boolean;lineSlack:boolean;rangeExceeded:boolean;warnings:string[];
 massKg:number;densityKgM3:number;volumeCm3:number;bodyHeightCm:number;bodyAreaCm2:number;bodyRadiusCm:number;waterBaseCm:number;liquid:Liquid;
}
export type BuoyancyResult=Result;
const finite=(x:number|undefined,f:number)=>Number.isFinite(x)?x!:f;
const clamp=(v:number,min:number,max:number)=>Math.max(min,Math.min(max,v));
export function clampConfig(c:Config):Required<Config>{return{
 bottomCm:clamp(finite(c.bottomCm,22),0,32),liquid:c.liquid==='brine'?'brine':'water',densityKgM3:clamp(finite(c.densityKgM3,1200),1000,1250),massKg:clamp(finite(c.massKg,.27),.05,.45),volumeCm3:clamp(finite(c.volumeCm3,100),50,150),bodyHeightCm:clamp(finite(c.bodyHeightCm,5),3,10),waterBaseCm:clamp(finite(c.waterBaseCm,14),8,18)
}}
/** Solve the volume conservation equation surface=base+displaced/tankArea. */
export function immersedGeometry(bottomCm:number,heightCm:number,volumeCm3:number,baseCm:number){
 const area=volumeCm3/heightCm;
 const immersionCm=clamp((baseCm-bottomCm)/(1-area/TANK.areaCm2),0,heightCm);
 const displacedCm3=area*immersionCm,surfaceCm=baseCm+displacedCm3/TANK.areaCm2;
 return{immersionCm,displacedCm3,surfaceCm};
}
export function solveBuoyancy(input:Config):Result {
 const c=clampConfig(input),rho=c.liquid==='water'?1000:c.densityKgM3;
 const gravityN=c.massKg*G,bodyAreaCm2=c.volumeCm3/c.bodyHeightCm;
 let bottom=c.bottomCm,lineSlack=false;
 const maximumBuoyancy=rho*G*c.volumeCm3*1e-6;
 // A string can pull upwards but cannot push a buoyant object downwards.
 // If lowering the support would slacken it, solve free-floating equilibrium.
 if(maximumBuoyancy>gravityN+1e-10){
  const equilibriumDisplaced=c.massKg/rho*1e6;
  const floatingSurface=c.waterBaseCm+equilibriumDisplaced/TANK.areaCm2;
  const floatingBottom=floatingSurface-equilibriumDisplaced/bodyAreaCm2;
  if(bottom<=floatingBottom+1e-10){bottom=floatingBottom;lineSlack=true}
 }
 const geo=immersedGeometry(bottom,c.bodyHeightCm,c.volumeCm3,c.waterBaseCm);
 const buoyancyN=rho*G*geo.displacedCm3*1e-6;
 const contact=!lineSlack&&bottom<=1e-10;
 const normalN=contact?Math.max(0,gravityN-buoyancyN):0;
 const tensionN=lineSlack||contact?0:Math.max(0,gravityN-buoyancyN);
 const isFull=geo.immersionCm>=c.bodyHeightCm-1e-9;
 const state=contact?'bottom':lineSlack?'floating':geo.displacedCm3<=1e-9?'air':isFull?'full':'partial';
 const warnings:string[]=[];
 if(contact)warnings.push('物体接触底部，支持力参与平衡；G−T包含支持力，不能当作浮力测量值。');
 if(lineSlack)warnings.push('物体自由浮起，绳松弛；不能靠上方绳子把浮体继续压入液体。');
 const validSuspended=!contact&&!lineSlack&&tensionN>1e-9;
 if(!validSuspended&&!contact&&!lineSlack)warnings.push('绳的张力为零，不是有效的悬挂称重状态。');
 const rangeExceeded=tensionN>LIMITS.springMaxN+1e-9;
 if(rangeExceeded)warnings.push('测力计超出5 N量程，不能读取正常示数。');
 const topDepthCm=geo.surfaceCm-(bottom+c.bodyHeightCm);
 return {commandBottomCm:c.bottomCm,bodyBottomCm:bottom,bodyTopCm:bottom+c.bodyHeightCm,...geo,submergedFraction:geo.displacedCm3/c.volumeCm3,depthCm:Math.max(0,topDepthCm),topDepthCm,centerDepthCm:geo.surfaceCm-(bottom+c.bodyHeightCm/2),buoyancyN,gravityN,tensionN,normalN,apparentBuoyancyN:gravityN-tensionN,validSuspended,state,isFull,lineSlack,rangeExceeded,warnings,massKg:c.massKg,densityKgM3:rho,volumeCm3:c.volumeCm3,bodyHeightCm:c.bodyHeightCm,bodyAreaCm2,bodyRadiusCm:Math.sqrt(bodyAreaCm2/Math.PI),waterBaseCm:c.waterBaseCm,liquid:c.liquid};
}
export const solve=solveBuoyancy;
