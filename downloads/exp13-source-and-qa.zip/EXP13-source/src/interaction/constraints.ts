export const FLOOR_Y=.035,ROPE_LENGTH=.12,SUPPORT_Y=.75;
export function constrainHeight(cm:number){return Math.round(Math.max(0,Math.min(32,Number.isFinite(cm)?cm:24))*8)/8}
export function scaleHookY(bottomCm:number,heightCm=5){return FLOOR_Y+(bottomCm+heightCm)/100+ROPE_LENGTH}
export function positionFromDrag(startCm:number,deltaWorldY:number){return constrainHeight(startCm+deltaWorldY*100)}
export const DEVICE_LABELS={scale:'弹簧测力计',body:'金属圆柱体',tank:'透明水槽',liquids:'清水与盐水'} as const;
