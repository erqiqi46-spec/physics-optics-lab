# 来源与授权

`src/assets/instruments.glb` 与 `scripts/build-assets.mjs` 为本项目原创生成，可随独立课件及源码交付、修改和再生。无第三方图库或远程资源依赖。GLB 使用原生PBR与玻璃扩展；Three.js GLTFExporter/BufferGeometryUtils 按其MIT许可证使用。

数字标签、液面、指针、绳索和受力/浮力辅助图由运行层基于同一物理状态生成，模型中没有预先制作的测量结果或实验动画。
