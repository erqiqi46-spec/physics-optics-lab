from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[1];body=(R/'dist/index.html').read_bytes();sha=hashlib.sha256(body).hexdigest();checks=[]
paths=list((R/'evidence/browser-replays-final').rglob('trace.zip'));assert len(paths)==9
for p in paths:
 with zipfile.ZipFile(p)as z:
  matches=[]
  for n in z.namelist():
   if n.startswith('resources/')and z.getinfo(n).file_size==len(body):
    h=hashlib.sha256(z.read(n)).hexdigest();checks.append({'trace':str(p.relative_to(R)),'htmlSha256':h,'matchesFinal':h==sha});matches.append(h)
  assert matches,'No HTML response in '+str(p)
assert checks and all(c['matchesFinal']for c in checks)
(R/'evidence/trace-build-identity.json').write_text(json.dumps({'allMatched':True,'finalSha256':sha,'traces':len(paths),'traceChecks':checks},indent=2));print('Trace identities verified',len(paths),sha)
