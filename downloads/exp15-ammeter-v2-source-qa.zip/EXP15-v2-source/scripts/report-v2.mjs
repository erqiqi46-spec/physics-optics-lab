import{readFileSync,writeFileSync,existsSync,mkdirSync,copyFileSync,readdirSync,statSync}from'node:fs';import{createHash}from'node:crypto';
const j=p=>JSON.parse(readFileSync(p,'utf8')),u=j('evidence/unit-results.json'),b=j('evidence/browser-results-final.json'),p=j('evidence/performance.json'),a=j('src/assets/asset-validation.json'),v=j('evidence/visual-review.json'),num=j('evidence/numerical-cases.json'),cross=j('evidence/browser-numerical-validation.json'),identity=j('evidence/trace-build-identity.json');const sha=createHash('sha256').update(readFileSync('dist/index.html')).digest('hex');
if(!u.success||u.numFailedTests||b.stats.expected!==9||b.stats.unexpected||b.stats.flaky||b.stats.skipped||b.stats.interrupted||b.errors.length||!a.passed||!v.passed||v.htmlSha256!==sha||!num.passed||!cross.passed||cross.htmlSha256!==sha||!identity.allMatched||identity.finalSha256!==sha||p.htmlSha256!==sha||p.results.some(r=>r.errors.length))throw Error('Final acceptance gate failed');
if(Date.parse(b.stats.startTime)<statSync('dist/index.html').mtimeMs-1000)throw Error('Stale build tested');const cases=[];function walk(s){for(const x of s.specs||[])for(const t of x.tests)cases.push({title:x.title,status:t.status,results:t.results});for(const x of s.suites||[])walk(x)}for(const s of b.suites)walk(s);if(cases.length!==9||cases.some(c=>c.status!=='expected'||c.results.at(-1).status!=='passed'))throw Error('Final browser cases failed');mkdirSync('evidence/replay',{recursive:true});for(const[i,c]of cases.entries())for(const f of c.results.at(-1).attachments||[])if(f.path&&existsSync(f.path)&&['video','trace'].includes(f.name))copyFileSync(f.path,`evidence/replay/${i+1}-${f.name}.${f.name==='video'?'webm':'zip'}`);
if(existsSync('evidence/mobile-replay')){const mobile=readdirSync('evidence/mobile-replay').filter(n=>n.endsWith('.webm')).map(n=>'evidence/mobile-replay/'+n).filter(n=>statSync(n).mtimeMs>=Date.parse(b.stats.startTime)).sort((a,b)=>statSync(b).mtimeMs-statSync(a).mtimeMs);if(mobile[0])copyFileSync(mobile[0],'evidence/replay/6-mobile-actual.webm')}
const md=`# EXP-15 v2 · 科学、交互与性能验收报告

只覆盖用电流表测量电流，不代表其他实验完成。最终HTML SHA256：\`${sha}\`。

## 来源与改进

人教九年级全一册2022版，第十五章第4节，正文56—57/PDF63—64。源文件哈希、栏目和教学扩展界限见source-map.md。没有湖南地方官方评分原件，评分与教师复核均为自定义、非官方。

默认理想教学模型，3 V、10 Ω得到0.30 A，两量程相同。可选非理想扩展明确公开源0.5 Ω、开关0.02 Ω、小量程0.2 Ω/大量程0.04 Ω，并在主界面展示模型及当前计算依据。记录表和CSV显式列模型与灯泡电阻；记录快照不可随切换模型被改写。

原课件的隐藏内阻问题已修正。理想短路没有有限稳态电流解；零阻环支路电流不唯一。这两者明确保护隔离、无有效读数，隔离后回零不能当正常0 A。有限超量程仍计算实际电流。正常开关断开仅在真实源电流为零且无其他故障时提示正常无电流。

## 自动化结果

- ${u.numPassedTests}/${u.numTotalTests}项Vitest通过：理想/非理想公式、断路/反接/短路/超量程、零阻环、连续参数、机械约束、模型冻结、模式隔离、故障去重与扣分、预测、教师复核及重复测量。
- 最终构建完整一轮9/9项真实Chromium案例通过，0失败、0跳过；file:// + context.setOffline(true)，无远程CDN请求、无未处理页面异常。
- 开发阶段曾出现测试夹具重复启动trace的失败（24ms、尚未进入页面），已删除重复启动；原始诊断另保留，不算最终轮通过。本报告仅使用browser-results-final.json的完整9案。
- 每张验收截图和状态带当前HTML哈希；9条操作trace响应体核对一致。原始记录和独立解析式交叉核验见browser-numerical-validation.json，${cross.checks.length}项均通过。

|案例|截图（evidence/screenshots/）|实际检查|
|---|---|---|
|规范教学、位置比较、重复、归位|01、02、03|0.30 A，保持电源/灯泡不变实际重新接线A/B/A，3条手填数据|
|反接、并联、跨源、带电换线、极端|04、05、05b、06、07|负电流、理想保护不伪报0 A、实际危险轨迹、6 V/2 Ω有限3 A超量程；止挡不能记录为0.60 A|
|3D/UI双向、复位、模式隔离|08、08b|真实鼠标拖动、独立GLB世界坐标、面板及SVG同状态；镜头不误转；草稿/勾选/选中/视角复位|
|完整考核与超时恢复|09、10、11|15分钟默认；真实0.30/0.15/0.30记录；整理前隐藏理论，归位后自定义100分样例；刷新不重置截止时间|
|手机与720p|12、13|原生touchStart/Move/End直接拖灯泡，标签不抢触摸；键盘等效接线；无整页横向溢出|
|模型公开与表针同步|14、15、16、16b|正常开路无红色故障；公开全部内阻；3D/2D指针按同一量程和电流；记录/CSV保留原模型|
|投影、预测、真实演示及接管|17、18系列、19|投影隐藏复杂控制；先预测才可揭示；反接/并联/超量程通过真实接线求解；接管取消后续步骤且保留现状|
|错误评分及复核|20、21|反接有事件依据并扣分；连续同故障去重；整理后教师评语/调整另存，自动分不被覆盖|

脚本：tests/ammeter.spec.ts；截图为实际浏览器输出，不是效果图。源码包含代码、截图、原始报告和数值；录像及trace另行打包，包内编号与上表/测试序号对应。

## 科学核验

理想规范电流为3/10=0.3 A；反接为−0.3 A；6/2=3 A有有限解但超0.6 A量程。非理想小量程3/10.72≈0.279850746 A，大量程3/10.56≈0.284090909 A。计算保留精度，学生按分度估读，0.28 A对小量程模型偏差约0.000149254 A，并非真实仪表精度认证。规范理想0.30 A与计算一致。独立浏览器解析式最大绝对误差${cross.maxAnalyticErrorA.toExponential(3)} A。

量程均30小格：0.6 A每格0.02 A，3 A每格0.1 A；理论数的显示精度不增加仪表分辨率。按真实量程、电路有效性、零位及安全接线轨迹检验记录，不靠勾选或保存按钮计分。

## 性能与视觉

环境：${p.browser}。1440×1000，真实UI建立理想3 V/10 Ω串联回路；无录像、无虚拟时钟。按需渲染，暖机后持续真实鼠标旋转镜头，以6个约1秒窗口的实际Three帧增量/浏览器时间测活动帧率。静止时不重复绘制，不能把空闲少帧当作低FPS。

|画质|活动FPS中位数（最小—最大）|WebGL调用/活动帧|三角形/活动帧|JS heap MiB|
|---|---:|---:|---:|---:|
${p.results.map(r=>`|${r.quality}|${r.fpsMedian.toFixed(1)} (${r.fpsMin.toFixed(1)}—${r.fpsMax.toFixed(1)})|${r.drawCalls}|${r.triangles}|${r.jsHeapUsedMiB.toFixed(1)}|`).join('\n')}

WebGL计数覆盖drawArrays/Elements及实例绘制，含离屏通道；不是系统GPU计数器。JS heap不含GPU/native内存，不虚报显存。旧v1静态常绘制软件渲染约6.4/2.4/2.2 FPS（低/中/高）；新表为活动镜头按需渲染，方法不同，不据此虚构严格倍数提升。

优化包括低/中档廉价透明玻璃、高档保留透射、环境一次捕获、阴影按需刷新、移除每帧材质遍历和空闲常绘制。GLB结构验证通过：原创细化资产${a.triangles}三角形，非扫描/CAD计量资产，不宣称电影级。

## 评分与使用边界

- 安全项按开始前配置和真实事件逐类扣分，封顶安全项；一个接法可能触发多种类别，明细公开，教师可调整。教学/自由模式只用于自查，不强制计分。
- 教师复核独立于自动分，无教师身份认证；结论只作基础规则检查，不是正式防作弊考试或官方成绩。
- 仅在Linux Chromium/SwiftShader和模拟手机触摸验证；未获得普通Windows学校电脑、真实手机实机，不能保证所有低端显卡流畅。实机仍须按提供的试用表验证。
- 定值灯丝、准静态电路，未模拟真实温升/熔断/指针磁电惯性；亮度由实际I²R定性驱动。危险接法仅限安全虚拟环境，不能照此接市电。
- 本机localStorage恢复依赖路径；JSON只导出不导入，无服务器收卷/防篡改。
- 教学效果和付费需求尚未由真人验证；随包提供教师观察表和学生任务单，不把准备材料冒充已试用结论。

最终判定：本报告列出的科学、双向交互、三种模式及独立离线案例通过；上述设备、教学效果与正式考核边界仍明确保留。
`;
writeFileSync('qa-report.md',md);writeFileSync('evidence/final-acceptance.json',JSON.stringify({passed:true,version:2,htmlSha256:sha,unitPassed:u.numPassedTests,browserPassed:9,analyticalChecks:cross.checks.length,cases:cases.map(c=>({title:c.title,status:c.status})),scope:'EXP15 v2 only; Linux Chromium offline + emulated mobile; not Windows hardware certification'},null,2));console.log('V2_ACCEPTED',sha);
