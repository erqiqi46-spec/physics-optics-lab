import{readFileSync,writeFileSync}from'node:fs';import{createHash}from'node:crypto';
const sha=createHash('sha256').update(readFileSync('dist/index.html')).digest('hex'),cases=JSON.parse(readFileSync('evidence/browser-case-evidence.json','utf8')),checks=[];
const get=name=>{const c=cases.find(x=>x.case===name);if(!c||c.artifactSha256!==sha)throw Error('Missing current-build snapshot '+name);return c.state};
function check(name,actual,expected,tolerance=1e-9){const error=Math.abs(actual-expected);checks.push({name,actual,expected,error,tolerance,passed:Number.isFinite(error)&&error<=tolerance})}
function truth(name,value){checks.push({name,passed:value===true})}
check('ideal normal',get('01-teach-normal').result.meterCurrent,.3);check('ideal reverse',get('04-error-reverse').result.meterCurrent,-.3);
for(const name of ['05-error-parallel','05b-error-across-source','18-demo-parallel']){const c=get(name);truth(name+' protected unknown current',c.result.protected&&!c.result.currentKnown&&!c.result.validSeries)}
check('finite ideal overrange 6V/2ohm',get('07-extreme-overrange').result.meterCurrent,3);check('ideal visible baseline',get('15-ideal-baseline').result.meterCurrent,.3);
check('explicit nonideal low',get('16-explicit-nonideal').result.meterCurrent,3/10.72);check('explicit nonideal high',get('16b-nonideal-large-range').result.meterCurrent,3/10.56);
check('actual reverse demo',get('18-demo-reverse').result.meterCurrent,-.3);check('actual range demo',get('18-demo-range').result.meterCurrent,3);
for(const name of ['03-teach-returned','10-exam-result','16-explicit-nonideal'])for(const r of get(name).session.rows){const extra=r.cfg.model==='nonideal'?.5+.02+(r.range===.6?.2:.04):0;const expected=r.cfg.voltage/(r.cfg.lampResistance+extra);check(`${name} row${r.id} solved snapshot`,r.expected.current,expected);check(`${name} row${r.id} actual manual reading`,r.current,expected,r.division*.51)}
const non=get('16-explicit-nonideal').session.rows;truth('mixed-model records retain immutable model',non.some(r=>r.cfg.model==='ideal')&&non.some(r=>r.cfg.model==='nonideal'));
const passed=checks.every(c=>c.passed);writeFileSync('evidence/browser-numerical-validation.json',JSON.stringify({passed,htmlSha256:sha,checks,maxAnalyticErrorA:Math.max(...checks.filter(c=>c.tolerance===1e-9).map(c=>c.error))},null,2));if(!passed)throw Error('Numerical browser validation failed');console.log('Crosschecks passed',checks.length);
