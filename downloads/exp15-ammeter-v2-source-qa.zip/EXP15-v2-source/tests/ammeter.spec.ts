import { test, expect, type Page } from '@playwright/test';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { mkdirSync, writeFileSync, readFileSync, existsSync } from 'node:fs';

const artifact = resolve('dist/index.html');
const url = pathToFileURL(artifact).href;
const devices = ['power', 'switch', 'lamp', 'meter'] as const;
let artifactSha256 = '';
let snapshots: any[] = [];
let pageErrors: string[] = [];
let remoteRequests: string[] = [];
const read = (p: Page) => p.evaluate(() => (window as any).__EXP15.read());

// This suite drives only the public UI and real canvas pointer/touch input.
// __EXP15 is read-only observation, never a state injection or shortcut.
test.beforeAll(() => {
  if (!existsSync(artifact)) throw new Error('Build the current v2 source before running browser acceptance.');
  artifactSha256 = createHash('sha256').update(readFileSync(artifact)).digest('hex');
  mkdirSync('evidence/screenshots', { recursive: true });
  mkdirSync('evidence/cases', { recursive: true });
  const previous = existsSync('evidence/browser-case-evidence.json')
    ? JSON.parse(readFileSync('evidence/browser-case-evidence.json', 'utf8')) : [];
  // A rebuilt artifact must never inherit the passing snapshots of an older HTML.
  snapshots = previous.filter((x: any) => x.artifactSha256 === artifactSha256);
  writeFileSync('evidence/browser-case-evidence.json', JSON.stringify(snapshots, null, 2));
});
test.beforeEach(async ({ context }) => {
  pageErrors = []; remoteRequests = [];
  await context.setOffline(true);
});
test.afterEach(async () => {
  expect(pageErrors, 'No unhandled application/browser errors').toEqual([]);
  expect(remoteRequests, 'The independent HTML must not request a remote CDN').toEqual([]);
});
function watch(p: Page) {
  p.on('pageerror', e => pageErrors.push(e.message));
  p.on('request', r => { if (/^https?:/i.test(r.url())) remoteRequests.push(r.url()); });
}
async function shot(p: Page, name: string) {
  const screenshot = `evidence/screenshots/${name}.png`;
  await p.screenshot({ path: screenshot, fullPage: true });
  const item = {
    case: name, artifactSha256, url, screenshot, viewport: p.viewportSize(),
    offline: true, state: await read(p),
    usedJsHeapSize: await p.evaluate(() => (performance as any).memory?.usedJSHeapSize ?? null),
  };
  const old = snapshots.findIndex(x => x.case === name);
  if (old >= 0) snapshots.splice(old, 1, item); else snapshots.push(item);
  writeFileSync(`evidence/cases/${name}.json`, JSON.stringify(item, null, 2));
  writeFileSync('evidence/browser-case-evidence.json', JSON.stringify(snapshots, null, 2));
  await test.info().attach(name, { path: screenshot, contentType: 'image/png' });
}
async function open(p: Page, mode = 'teach') {
  watch(p); await p.goto(url);
  if (mode !== 'teach') await p.getByTestId('start-mode-' + mode).click();
  await p.getByTestId('start').click();
  await p.getByLabel('画质').selectOption('low');
  await p.waitForFunction(() => (window as any).__EXP15?.read().stats.ready === true);
}
async function inventory(p: Page) {
  for (const d of devices) await p.getByTestId('inspect-' + d).click();
  await p.getByTestId('confirm-inventory').click();
}
async function place(p: Page) {
  for (const d of devices) {
    await p.getByTestId('inspect-' + d).click(); await p.getByTestId('place-selected').click();
  }
  expect((await read(p)).session.placed).toHaveLength(4);
}
async function zero(p: Page) {
  for (let i = 0; i < 5; i++) await p.getByTestId('zero-minus').click();
  expect((await read(p)).session.zeroOffset).toBe(0);
  expect((await read(p)).session.zeroChecked).toBe(true);
}
async function connect(p: Page, a: string, b: string) {
  const before = (await read(p)).session.cfg.wires.length;
  await p.getByTestId('terminal-' + a).click(); await p.getByTestId('terminal-' + b).click();
  await expect.poll(async () => (await read(p)).session.cfg.wires.length).toBe(before + 1);
}
async function remove(p: Page, a: string, b: string) { await p.getByTestId('remove-' + a + '-' + b).click(); }
async function clearWires(p: Page) {
  for (const w of (await read(p)).session.cfg.wires) await remove(p, w.from, w.to);
}
async function series(p: Page, range = 'A3') {
  for (const [a, b] of [['P+', 'S1'], ['S2', range], ['A-', 'L1'], ['L2', 'P-']]) await connect(p, a, b);
}
async function off(p: Page) {
  if ((await read(p)).session.cfg.switchClosed) await p.getByTestId('switch').click();
  if ((await read(p)).session.cfg.power) await p.getByTestId('power').click();
  expect((await read(p)).session.cfg.power).toBe(false);
}
async function on(p: Page) {
  if (!(await read(p)).session.cfg.power) await p.getByTestId('power').click();
  if (!(await read(p)).session.cfg.switchClosed) await p.getByTestId('switch').click();
}
async function record(p: Page, current: string, range = '.6') {
  const before = (await read(p)).session.rows.length;
  await p.getByTestId('read-range').selectOption(range);
  await p.getByTestId('read-division').fill(range === '3' ? '.1' : '.02');
  await p.getByTestId('read-current').fill(current);
  for (const x of ['series', 'polarity', 'range', 'poweroff']) await p.getByTestId('check-' + x).check();
  await p.getByTestId('save-record').click();
  expect((await read(p)).session.rows).toHaveLength(before + 1);
}
async function lowTrial(p: Page) {
  await series(p); await p.getByTestId('power').click(); await p.getByTestId('trial').click();
  await expect.poll(async () => (await read(p)).session.trialUntil).toBeNull();
  await off(p); await remove(p, 'S2', 'A3'); await connect(p, 'S2', 'A06'); await on(p);
}
async function measurements(p: Page) {
  await record(p, '.30'); await off(p); await p.getByTestId('battery-1.5').click(); await on(p);
  await record(p, '.15'); await off(p); await p.getByTestId('battery-3').click(); await on(p); await record(p, '.30');
}
async function assertExamHidden(p: Page) {
  for (const id of ['model-info', 'prediction-topic', 'prediction-choice', 'run-demo', 'teacher-view', 'diagram-meter-current', 'review-comment'])
    await expect(p.getByTestId(id)).toHaveCount(0);
  await expect(p.getByTestId('records')).not.toContainText('记录自查');
  await expect(p.getByTestId('evaluation')).toHaveCount(0);
}
async function submitCleanup(p: Page) {
  await p.getByTestId('conclusion').fill('电流表应串联接入，电流正进负出。先大量程试触，再选合适量程，按分度值读数。改变接线位置或实验条件后再恢复，电流回到原值。');
  p.once('dialog', d => d.accept()); await p.getByTestId('submit').click();
  await expect(p.getByTestId('evaluation')).toHaveCount(0);
  if ((await read(p)).mode === 'exam') await assertExamHidden(p);
  await off(p); await clearWires(p);
  for (const d of devices) { await p.getByTestId('inspect-' + d).click(); await p.getByTestId('stow-selected').click(); }
  await expect(p.getByTestId('evaluation')).toBeVisible();
  expect((await read(p)).session.returned).toBe(true);
}
async function score(p: Page) {
  const text = await p.getByTestId('score').innerText();
  return Number(text.match(/^\s*(\d+(?:\.\d+)?)/)?.[1]);
}
async function assertSynchronizedMeter(p: Page, current: number, range: number) {
  const ratio = Math.max(-.1, Math.min(1.07, current / range));
  const angle = (-150 + Math.max(-.1, Math.min(1.07, current / range)) * 120) * Math.PI / 180;
  expect((await read(p)).result.meterCurrent).toBeCloseTo(current, 8);
  await expect.poll(async () => (await read(p)).stats.needleAngle).toBeCloseTo(angle, 5);
  await expect.poll(async () => Number(await p.getByTestId('needle').first().getAttribute('data-ratio'))).toBeCloseTo(ratio, 5);
  const precision = (await read(p)).result.model === 'ideal' ? 2 : 3;
  await expect(p.getByTestId('diagram-meter-current')).toContainText(current.toFixed(precision));
}
async function topCamera(p: Page) {
  await p.getByTestId('camera-top').click(); await p.locator('.scene-area').scrollIntoViewIfNeeded();
  for (const [index, expected] of [0, 1.43, .001].entries())
    await expect.poll(async () => (await read(p)).stats.camera[index]).toBeCloseTo(expected, 3);
}
async function bodyPoint(p: Page, device: 'lamp' | 'meter') {
  const t = (await read(p)).targets[device];
  const point = await p.evaluate(({ t }) => {
    for (const [dx, dy] of [[0, 0], [0, -8], [-8, 0], [8, 0], [0, 8], [0, -16]]) {
      const x = t.x + dx, y = t.y + dy;
      if (x > 0 && x < innerWidth && y > 0 && y < innerHeight && document.elementFromPoint(x, y)?.tagName === 'CANVAS') return { x, y };
    }
    return null;
  }, { t });
  expect(point, 'A real canvas body target must be reachable, not covered by an HTML label').not.toBeNull();
  return point!;
}

test('01 教学规范流程：0.30A试触换档、实际接线位置A/B/A与归位', async ({ page }) => {
  await open(page); await inventory(page); await place(page); await zero(page); await lowTrial(page);
  await record(page, '.30'); expect((await read(page)).session.rows[0].valid).toBe(true);
  await assertSynchronizedMeter(page, .3, .6); await shot(page, '01-teach-normal');
  await off(page); await clearWires(page);
  for (const [a, b] of [['P+', 'S1'], ['S2', 'L1'], ['L2', 'A06'], ['A-', 'P-']]) await connect(page, a, b);
  await on(page); await record(page, '.30'); await off(page); await clearWires(page);
  await series(page, 'A06'); await on(page); await record(page, '.30');
  const measured = await read(page);
  expect(measured.session.rows.every((r: any) => r.valid)).toBe(true);
  expect(measured.session.rows.map((r: any) => r.current)).toEqual([.3, .3, .3]);
  await page.getByTestId('meter-enlarge').click(); await expect(page.getByRole('dialog')).toContainText('实时放大观察');
  await page.getByRole('button', { name: '返回操作', exact: true }).click();
  await shot(page, '02-repeat-and-records'); await submitCleanup(page); await shot(page, '03-teach-returned');
});

test('02 错误及极端：反接、理想并联短路保护、带电换线、6V/2Ω超量程', async ({ page }) => {
  await open(page, 'free'); await inventory(page); await place(page); await zero(page);
  for (const [a, b] of [['P+', 'S1'], ['S2', 'A-'], ['A06', 'L1'], ['L2', 'P-']]) await connect(page, a, b);
  await on(page); expect((await read(page)).result.reverse).toBe(true);
  expect((await read(page)).result.meterCurrent).toBeCloseTo(-.3, 8);
  await expect(page.getByTestId('circuit-status')).toContainText('反向'); await shot(page, '04-error-reverse');
  await off(page); await clearWires(page);
  for (const [a, b] of [['P+', 'S1'], ['S2', 'L1'], ['L2', 'P-'], ['A06', 'L1'], ['A-', 'L2']]) await connect(page, a, b);
  await on(page); let r = (await read(page)).result;
  expect(r.faults).toContain('meter-parallel-lamp'); expect(r.protected).toBe(true); expect(r.currentKnown).toBe(false);
  await expect(page.getByTestId('fault-panel')).toContainText(/保护|不可求|不确定/);
  await expect(page.getByTestId('diagram-meter-current')).toContainText('无有效读数');
  await expect(page.getByTestId('analog').first()).toContainText('保护隔离');
  await shot(page, '05-error-parallel');
  await off(page); await clearWires(page); await connect(page, 'A06', 'P+'); await connect(page, 'A-', 'P-');
  await on(page); r = (await read(page)).result;
  expect(r.faults).toContain('meter-across-source'); expect(r.protected).toBe(true); expect(r.currentKnown).toBe(false);
  await shot(page, '05b-error-across-source');
  await off(page); await clearWires(page); await series(page, 'A06'); await on(page);
  await connect(page, 'P+', 'A3'); const live = await read(page);
  expect(live.session.cfg.power).toBe(false); expect(live.session.events.some((e: any) => e.type === 'live-rewire')).toBe(true);
  await shot(page, '06-error-live-rewire');
  await off(page); await clearWires(page); await series(page, 'A06');
  await page.getByTestId('input-voltage').fill('6'); await page.getByTestId('input-resistance').fill('2'); await on(page);
  const extreme = await read(page);
  expect(extreme.result.overrange).toBe(true); expect(extreme.result.meterCurrent).toBeCloseTo(3, 8);
  expect(extreme.result.lampPower).toBeCloseTo(18, 8);
  await assertSynchronizedMeter(page, 3, .6);
  await record(page, '.60'); expect((await read(page)).session.rows[0].valid).toBe(false);
  await shot(page, '07-extreme-overrange');
  await page.getByTestId('emergency-off').click(); expect((await read(page)).session.cfg.power).toBe(false);
});

test('03 真正3D拖动、接线反馈、双向同步、模式隔离及完整复位', async ({ page }) => {
  await open(page, 'free'); const originalCamera = (await read(page)).stats.camera;
  await inventory(page); await place(page); await topCamera(page);
  const before = await read(page), a = await bodyPoint(page, 'lamp');
  await page.mouse.move(a.x, a.y); await page.mouse.down(); await page.mouse.move(a.x - 65, a.y + 18, { steps: 10 }); await page.mouse.up();
  await expect.poll(async () => JSON.stringify((await read(page)).session.positions.lamp)).not.toBe(JSON.stringify(before.session.positions.lamp));
  const afterDrag = await read(page);
  for (let i = 0; i < 3; i++) expect(afterDrag.stats.camera[i]).toBeCloseTo(before.stats.camera[i], 2);
  await page.getByTestId('inspect-lamp').click();
  await expect.poll(async () => Number(await page.getByTestId('position-x').inputValue())).toBe(afterDrag.session.positions.lamp[0]);
  await page.getByTestId('position-x').fill('.1');
  await expect.poll(async () => (await read(page)).stats.objects.lamp[0]).toBeCloseTo(.1, 5);
  await page.getByTestId('place-selected').click(); expect((await read(page)).session.placed).toContain('lamp');
  await page.locator('.scene-area').scrollIntoViewIfNeeded();
  for (const t of ['P+', 'S1']) { const point = (await read(page)).targets[t]; await page.mouse.click(point.x, point.y); }
  await expect.poll(async () => (await read(page)).session.cfg.wires.length).toBe(1);
  await expect(page.getByTestId('circuit-diagram').locator('path[data-wire]')).toHaveCount(1);
  await connect(page, 'S2', 'L1'); await expect(page.getByTestId('circuit-diagram').locator('path[data-wire]')).toHaveCount(2);
  await page.getByTestId('input-voltage').fill('4.5');
  await page.getByTestId('freeze').click(); await expect(page.getByTestId('input-voltage')).toHaveAttribute('readonly', '');
  expect((await read(page)).session.cfg.voltage).toBe(4.5); await page.getByTestId('freeze').click(); await shot(page, '08-bidirectional');
  await page.getByTestId('mode-teach').click(); await expect(page.getByRole('dialog')).toContainText('是否保存');
  await page.getByTestId('save-switch').click(); await page.getByTestId('start').click(); expect((await read(page)).session.cfg.wires).toHaveLength(0);
  await page.getByTestId('mode-free').click(); await page.getByTestId('save-switch').click();
  expect((await read(page)).session.cfg.voltage).toBe(4.5); expect((await read(page)).session.cfg.wires).toHaveLength(2);
  await page.getByTestId('read-range').selectOption('3'); await page.getByTestId('read-division').fill('.1');
  await page.getByTestId('read-current').fill('.4'); await page.getByTestId('check-series').check();
  page.once('dialog', d => d.accept()); await page.getByRole('button', { name: '↺ 重置', exact: true }).click(); await page.getByTestId('start').click();
  const reset = await read(page);
  expect(reset.session.cfg.wires).toHaveLength(0); expect(reset.session.cfg.voltage).toBe(3); expect(reset.session.rows).toHaveLength(0);
  await expect(page.getByTestId('read-current')).toHaveValue(''); await expect(page.getByTestId('read-range')).toHaveValue('.6');
  await expect(page.getByTestId('read-division')).toHaveValue('.02'); await expect(page.getByTestId('check-series')).not.toBeChecked();
  await expect(page.getByTestId('position-x')).toHaveCount(0);
  for (let i = 0; i < 3; i++) await expect.poll(async () => (await read(page)).stats.camera[i]).toBeCloseTo(originalCamera[i], 2);
  await shot(page, '08b-full-reset');
});

test('04 考核：理论及预测隐藏，0.30/0.15/0.30真实记录，归位后100分', async ({ page }) => {
  await open(page, 'exam'); await expect(page.getByTestId('timer')).toBeVisible();
  const beginning = await read(page); expect(beginning.session.deadline - beginning.session.startedAt).toBe(900000);
  await assertExamHidden(page); await inventory(page); await place(page); await zero(page); await lowTrial(page); await measurements(page);
  const a = await read(page); expect(a.result).toBeUndefined();
  expect(a.session.rows.every((r: any) => !('expected' in r) && !('valid' in r))).toBe(true);
  expect(a.session.rows.map((r: any) => r.current)).toEqual([.3, .15, .3]);
  await expect(page.getByTestId('input-voltage')).toHaveAttribute('readonly', ''); await shot(page, '09-exam-before-submit');
  await submitCleanup(page); expect(await score(page)).toBe(100);
  await expect(page.getByTestId('evaluation')).toContainText('非官方'); await shot(page, '10-exam-result');
});

test('05 考核计时：刷新恢复、60秒到时锁定，整理前不泄露答案', async ({ page }) => {
  watch(page); await page.clock.install(); await page.goto(url); await page.getByTestId('start-mode-exam').click();
  await page.getByTestId('exam-minutes').fill('1'); await page.getByTestId('start').click();
  await page.getByLabel('画质').selectOption('low'); await inventory(page);
  const before = await read(page); await page.reload(); await expect(page.getByTestId('timer')).toBeVisible();
  const restored = await read(page); expect(restored.session.inventoryConfirmed).toBe(true);
  expect(restored.session.deadline).toBe(before.session.deadline); expect(restored.session.startedAt).toBe(before.session.startedAt);
  await page.clock.fastForward(61000); await expect.poll(async () => (await read(page)).session.expired).toBe(true);
  await expect(page.getByTestId('conclusion')).toBeDisabled(); await expect(page.getByTestId('save-record')).toBeDisabled();
  await assertExamHidden(page); await shot(page, '11-exam-timeout');
});

test('06 手机原生触摸拖动与键盘接线、桌面720p离线加载', async ({ browser }) => {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true,
    recordVideo: { dir: 'evidence/mobile-replay', size: { width: 390, height: 844 } } });
  await ctx.setOffline(true); // Playwright's trace:on also manages manually-created contexts.
  const p = await ctx.newPage(); await open(p, 'free'); await inventory(p); await place(p); await topCamera(p);
  const before = await read(p), start = await bodyPoint(p, 'lamp');
  expect(await p.evaluate(s => document.elementFromPoint(s.x, s.y)?.tagName, start)).toBe('CANVAS');
  const cdp = await ctx.newCDPSession(p);
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ ...start, id: 1 }] });
  for (let i = 1; i <= 10; i++) {
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: start.x - 30 * i / 10, y: start.y + 12 * i / 10, id: 1 }] });
    await p.waitForTimeout(35);
  }
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  await expect.poll(async () => JSON.stringify((await read(p)).session.positions.lamp)).not.toBe(JSON.stringify(before.session.positions.lamp));
  const moved = await read(p); for (let i = 0; i < 3; i++) expect(moved.stats.camera[i]).toBeCloseTo(before.stats.camera[i], 2);
  await p.getByTestId('terminal-P+').focus(); await p.keyboard.press('Enter');
  await p.getByTestId('terminal-S1').focus(); await p.keyboard.press('Enter'); expect((await read(p)).session.cfg.wires).toHaveLength(1);
  expect(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true); await shot(p, '12-mobile-touch');
  await ctx.close();
  const desk = await browser.newContext({ viewport: { width: 1280, height: 720 } }); await desk.setOffline(true);
  const d = await desk.newPage(); await open(d); expect(await d.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await shot(d, '13-desktop-720'); await desk.close();
});

test('07 默认理想0.30A与显式非理想0.27985A，3D针/2D针/仪表同源', async ({ page }) => {
  await open(page, 'free'); await inventory(page); await place(page); await zero(page); await series(page, 'A06');
  await expect(page.getByTestId('model-select')).toHaveValue('ideal');
  await page.getByTestId('power').click();
  expect((await read(page)).result.faults).toContain('open-circuit');
  await expect(page.getByTestId('fault-panel')).toHaveCount(0);
  await expect(page.getByTestId('circuit-status')).not.toHaveClass(/danger/); await shot(page, '14-open-normal');
  await page.getByTestId('switch').click(); await assertSynchronizedMeter(page, .3, .6);
  await expect(page.getByTestId('model-info')).toContainText(/理想/);
  await record(page, '.30'); expect((await read(page)).session.rows[0].valid).toBe(true);
  expect((await read(page)).session.rows[0].cfg.model).toBe('ideal');
  await shot(page, '15-ideal-baseline');
  await off(page); await page.getByTestId('model-select').selectOption('nonideal'); await on(page);
  const nonideal = (await read(page)).result; expect(nonideal.model).toBe('nonideal');
  expect(nonideal.parameters).toEqual({ sourceResistance: .5, switchResistance: .02, meterResistance: { A06: .2, A3: .04 } });
  for (const re of [/0\.5\s*Ω/, /0\.02\s*Ω/, /0\.2\s*Ω/, /0\.04\s*Ω/]) await expect(page.getByTestId('model-info')).toContainText(re);
  await assertSynchronizedMeter(page, 3 / 10.72, .6); await record(page, '.28');
  expect((await read(page)).session.rows[1].valid).toBe(true);
  expect((await read(page)).session.rows[1].cfg.model).toBe('nonideal');
  await expect(page.getByTestId('records').getByRole('columnheader', { name: /模型/ })).toBeVisible();
  await expect(page.getByTestId('records').getByRole('columnheader', { name: /(?:灯泡|电阻|R).*Ω/ })).toBeVisible();
  await expect(page.getByTestId('row-model-1')).toHaveText('理想教学');
  await expect(page.getByTestId('row-model-2')).toHaveText('非理想扩展');
  await shot(page, '16-explicit-nonideal');
  await off(page); await remove(page, 'S2', 'A06'); await connect(page, 'S2', 'A3'); await on(page);
  await assertSynchronizedMeter(page, 3 / 10.56, 3); await shot(page, '16b-nonideal-large-range');
  await off(page); await page.getByTestId('model-select').selectOption('ideal'); await on(page);
  await assertSynchronizedMeter(page, .3, 3);
  const frozen = (await read(page)).session.rows;
  expect(frozen.map((r: any) => r.cfg.model)).toEqual(['ideal', 'nonideal']);
  expect(frozen.map((r: any) => r.cfg.lampResistance)).toEqual([10, 10]);
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: '导出 CSV ↗', exact: true }).click();
  const download = await downloadPromise, csvPath = await download.path();
  expect(csvPath).not.toBeNull(); const csv = readFileSync(csvPath!, 'utf8');
  expect(csv.split(/\r?\n/)[0]).toContain('模型');
  expect(csv.split(/\r?\n/)[0]).toMatch(/(?:灯泡|电阻|R).*Ω/);
  const cells = csv.replace(/^\uFEFF/, '').trim().split(/\r?\n/).map(line => line.split(','));
  const modelColumn = cells[0].findIndex(label => label.includes('模型'));
  const resistanceColumn = cells[0].findIndex(label => label.includes('Ω'));
  expect(cells[1][modelColumn]).toBe('理想教学'); expect(cells[2][modelColumn]).toBe('非理想扩展');
  expect(cells[1][resistanceColumn]).toBe('10'); expect(cells[2][resistanceColumn]).toBe('10');
  await shot(page, '16c-frozen-model-records-and-csv');
});

test('08 教师展示、先预测后真实示范、立即接管取消后续自动操作', async ({ page }) => {
  await open(page); await inventory(page); await place(page); await zero(page);
  await page.getByTestId('teacher-view').click(); await expect(page.locator('main')).toHaveClass(/presentation/);
  await expect(page.locator('aside.controls')).toBeHidden(); await expect(page.getByTestId('scene')).toBeVisible();
  await shot(page, '17-teacher-presentation'); await page.getByTestId('teacher-view').click(); await expect(page.locator('aside.controls')).toBeVisible();
  for (const [topic, choice] of [['reverse', 'reverse'], ['parallel', 'short'], ['range', 'overrange']]) {
    await page.getByTestId('prediction-topic').selectOption(topic); await expect(page.getByTestId('run-demo')).toBeDisabled();
    await page.getByTestId('prediction-choice').selectOption(choice); await expect(page.getByTestId('run-demo')).toBeEnabled();
    await page.getByTestId('run-demo').click(); await expect(page.getByTestId('demo-status')).toContainText('演示完成');
    const a = await read(page);
    if (topic === 'reverse') { expect(a.result.reverse).toBe(true); expect(a.result.meterCurrent).toBeCloseTo(-.3, 8); }
    if (topic === 'parallel') { expect(a.result.protected).toBe(true); expect(a.result.currentKnown).toBe(false); }
    if (topic === 'range') { expect(a.result.overrange).toBe(true); expect(a.result.meterCurrent).toBeCloseTo(3, 8); }
    await shot(page, '18-demo-' + topic);
  }
  await page.getByTestId('prediction-topic').selectOption('correct'); await page.getByTestId('prediction-choice').selectOption('0.30');
  await page.getByTestId('run-demo').click(); await page.getByTestId('take-over').click();
  await page.getByTestId('input-voltage').fill('4.5');
  const takeover = await read(page); await page.waitForTimeout(2800);
  expect((await read(page)).session.cfg).toEqual(takeover.session.cfg);
  expect((await read(page)).session.cfg.voltage).toBe(4.5); await shot(page, '19-demo-takeover');
});

test('09 故障有事件依据并扣模拟分，教师复核只在交卷归位后开放', async ({ page }) => {
  await open(page, 'exam'); await inventory(page); await place(page); await zero(page);
  for (const [a, b] of [['P+', 'S1'], ['S2', 'A-'], ['A3', 'L1'], ['L2', 'P-']]) await connect(page, a, b);
  await on(page); await assertExamHidden(page); await shot(page, '20-exam-fault-before-return');
  await off(page); await clearWires(page); await lowTrial(page); await measurements(page); await submitCleanup(page);
  const originalScore = await score(page); expect(originalScore).toBeLessThan(100); expect(originalScore).toBeGreaterThan(0);
  await expect(page.getByTestId('safety-breakdown')).toContainText(/反接|反向/);
  await expect(page.getByTestId('safety-breakdown')).toContainText(/事件|#/);
  const comment = '教师复核：反接曾发生且已纠正，实际记录和归位完整。';
  await page.getByTestId('review-comment').fill(comment); await page.getByTestId('review-adjustment').fill('2');
  await page.getByTestId('save-review').click(); await expect(page.getByTestId('review-result')).toContainText(comment);
  expect(await score(page)).toBe(originalScore);
  expect((await read(page)).session.events.some((e: any) => e.type === 'teacher-review' && JSON.stringify(e.detail).includes(comment))).toBe(true);
  await shot(page, '21-fault-score-and-teacher-review');
});
