import type {CircuitConfig,CircuitResult} from '../physics/model';
export const SAFETY_CATEGORIES=['reverse','meter-parallel-lamp','meter-across-source','source-short','overrange','both-ranges','live-rewire'] as const;
export type SafetyFault=typeof SAFETY_CATEGORIES[number];
export type SafetyPenalties=Record<SafetyFault,number>;
export const DEFAULT_SAFETY_PENALTIES:SafetyPenalties={'reverse':1,'meter-parallel-lamp':3,'meter-across-source':4,'source-short':4,'overrange':2,'both-ranges':2,'live-rewire':3};
export const SAFETY_LABELS:Record<SafetyFault,string>={'reverse':'正负接线反接','meter-parallel-lamp':'电流表并联灯泡','meter-across-source':'电流表跨接电源','source-short':'电源短路','overrange':'超过量程','both-ranges':'同时接入两个量程','live-rewire':'带电改线或调整'};
export interface FaultDetail{category:SafetyFault;triggerEventId:number;cfg:CircuitConfig;result:CircuitResult;protected:boolean;}
export function normalizePenalties(input:Partial<SafetyPenalties>,fallback=DEFAULT_SAFETY_PENALTIES):SafetyPenalties{const out={...fallback};for(const category of SAFETY_CATEGORIES){const n=input[category];if(typeof n==='number'&&Number.isFinite(n)&&n>=0)out[category]=Math.min(100,n)}return out}
export const predictionQuestions:Record<string,string>={reverse:'如果电流从电流表负接线柱流入，指针会怎样？',parallel:'把电流表并联在小灯泡两端，可以正确测量灯泡电流吗？',range:'同一电流使用0—0.6 A和0—3 A量程，读数和分度值分别有什么变化？'};
export const predictionQuestion=(topic:string)=>predictionQuestions[topic]??'请先预测本次操作会出现的现象。';
export interface Prediction{question:string;choice:string;at:number;observed:boolean;observedAt:number|null;snapshot?:{cfg:CircuitConfig;result:CircuitResult};}
export interface TeacherReview{comment:string;adjustment:number;at:number;label:'教师复核（非官方）';}
