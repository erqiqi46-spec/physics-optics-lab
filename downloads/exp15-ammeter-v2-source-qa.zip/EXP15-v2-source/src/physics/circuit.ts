/** DC, quasi-static resistor network. SI units; no random display drift. */
export const TERMINALS = ['P+','P-','S1','S2','L1','L2','A-','A06','A3'] as const;
export type Terminal = typeof TERMINALS[number];
export interface Wire { id: string; from: Terminal; to: Terminal }
export interface CircuitConfig { wires: Wire[]; voltage: number; lampResistance: number; power: boolean; switchClosed: boolean; model?:'ideal'|'nonideal' }
export type Fault = 'source-short'|'meter-across-source'|'meter-parallel-lamp'|'both-ranges'|'reverse'|'overrange'|'lamp-bypassed'|'open-circuit'|'ideal-loop';
export interface ModelParameters { sourceResistance:number; switchResistance:number; meterResistance:{A06:number;A3:number} }
export interface CircuitResult { model:'ideal'|'nonideal'; parameters:ModelParameters; protected:boolean; currentKnown:boolean; lampCurrent:number; meterCurrent:number; sourceCurrent:number; switchCurrent:number; meterRange:0.6|3|null; division:0.02|0.1|null; nodeV:Record<Terminal,number>; faults:Fault[]; energized:boolean; validSeries:boolean; overrange:boolean; reverse:boolean; tripRecommended:boolean; lampPower:number; meterVoltage:number }
export const SOURCE_RESISTANCE=.5, SWITCH_RESISTANCE=.02;
export const METER_RESISTANCE={A06:.2,A3:.04} as const;
export const LIMITS={voltage:{min:0,max:6},lampResistance:{min:2,max:30}} as const;
export function clampConfig(input:CircuitConfig):CircuitConfig {
 const finite=(v:number,fallback:number)=>Number.isFinite(v)?v:fallback;
 return {...input,voltage:Math.max(0,Math.min(6,finite(input.voltage,3))),lampResistance:Math.max(2,Math.min(30,finite(input.lampResistance,10))),wires:input.wires.filter(w=>TERMINALS.includes(w.from)&&TERMINALS.includes(w.to)&&w.from!==w.to)};
}
function linear(a:number[][],b:number[]):number[]{
 const n=b.length,m=a.map((r,i)=>[...r,b[i]]);
 for(let k=0;k<n;k++){let p=k;for(let i=k+1;i<n;i++)if(Math.abs(m[i][k])>Math.abs(m[p][k]))p=i;
  if(Math.abs(m[p][k])<1e-12)throw Error('Singular grounded circuit matrix');[m[k],m[p]]=[m[p],m[k]];
  const d=m[k][k];for(let j=k;j<=n;j++)m[k][j]/=d;
  for(let i=0;i<n;i++)if(i!==k){const f=m[i][k];for(let j=k;j<=n;j++)m[i][j]-=f*m[k][j]}
 }return m.map(r=>r[n]);
}
function solveNonideal(input:CircuitConfig):CircuitResult {
 const c=clampConfig(input),parent=new Map<Terminal,Terminal>(TERMINALS.map(t=>[t,t]));
 const root=(t:Terminal):Terminal=>{const p=parent.get(t)!;if(p===t)return t;const r=root(p);parent.set(t,r);return r};
 for(const w of c.wires)parent.set(root(w.from),root(w.to));
 const ground=root('P-'),plus=root('P+');
 const connected=(t:Terminal)=>c.wires.some(w=>w.from===t||w.to===t);
 const small=connected('A06'),large=connected('A3');
 const meterRange:0.6|3|null=small&&!large?.6:large&&!small?3:null;
 const division:0.02|0.1|null=meterRange===.6?.02:meterRange===3?.1:null;
 type Edge={a:Terminal;b:Terminal;r:number};
 const edges:Edge[]=[{a:'L1',b:'L2',r:c.lampResistance}];
 if(c.switchClosed)edges.push({a:'S1',b:'S2',r:SWITCH_RESISTANCE});
 // Both sockets are physically modeled; that connection is invalid as a range selection.
 if(small)edges.push({a:'A06',b:'A-',r:METER_RESISTANCE.A06});
 if(large)edges.push({a:'A3',b:'A-',r:METER_RESISTANCE.A3});
 const graph=new Map<Terminal,Set<Terminal>>();for(const t of TERMINALS)graph.set(root(t),new Set());
 for(const e of edges){graph.get(root(e.a))!.add(root(e.b));graph.get(root(e.b))!.add(root(e.a))}
 graph.get(plus)!.add(ground);graph.get(ground)!.add(plus);
 const reachable=new Set<Terminal>([ground]),queue=[ground];while(queue.length){for(const n of graph.get(queue.shift()!)!)if(!reachable.has(n)){reachable.add(n);queue.push(n)}}
 const nodes=[...reachable].filter(n=>n!==ground),idx=new Map(nodes.map((n,i)=>[n,i]));
 const a=nodes.map(()=>nodes.map(()=>0)),b=nodes.map(()=>0);
 const stamp=(x:Terminal,y:Terminal,r:number)=>{if(x===y)return;const i=idx.get(x),j=idx.get(y),g=1/r;if(i!==undefined)a[i][i]+=g;if(j!==undefined)a[j][j]+=g;if(i!==undefined&&j!==undefined){a[i][j]-=g;a[j][i]-=g}};
 for(const e of edges)if(reachable.has(root(e.a)))stamp(root(e.a),root(e.b),e.r);
 stamp(plus,ground,SOURCE_RESISTANCE);
 const voltage=c.power?c.voltage:0;if(plus!==ground)b[idx.get(plus)!]+=voltage/SOURCE_RESISTANCE;
 const solved=linear(a,b),V=(t:Terminal)=>root(t)===ground?0:solved[idx.get(root(t))??-1]??0;
 const nodeV=Object.fromEntries(TERMINALS.map(t=>[t,V(t)])) as Record<Terminal,number>;
 const lampCurrent=(V('L1')-V('L2'))/c.lampResistance;
 const switchCurrent=c.switchClosed?(V('S1')-V('S2'))/SWITCH_RESISTANCE:0;
 const smallI=small?(V('A06')-V('A-'))/.2:0,largeI=large?(V('A3')-V('A-'))/.04:0;
 const meterCurrent=smallI+largeI,sourceCurrent=(voltage-(V('P+')-V('P-')))/SOURCE_RESISTANCE;
 const active=small?'A06':'A3';const samePair=(a:Terminal,b:Terminal,x:Terminal,y:Terminal)=>(root(a)===root(x)&&root(b)===root(y))||(root(a)===root(y)&&root(b)===root(x));
 const faults:Fault[]=[];
 if(root('P+')===root('P-'))faults.push('source-short');
 if(small&&large)faults.push('both-ranges');
 for(const t of ['A06','A3'] as const)if(connected(t)){
  if(samePair(t,'A-','P+','P-')&&!faults.includes('meter-across-source'))faults.push('meter-across-source');
  if(samePair(t,'A-','L1','L2')&&!faults.includes('meter-parallel-lamp'))faults.push('meter-parallel-lamp');
 }
 const reverse=meterCurrent< -1e-7,overrange=meterRange!==null&&Math.abs(meterCurrent)>meterRange+1e-8;
 if(reverse)faults.push('reverse');if(overrange)faults.push('overrange');
 if(root('L1')===root('L2'))faults.push('lamp-bypassed');
 if(c.power&&c.voltage>0&&Math.abs(sourceCurrent)<1e-7)faults.push('open-circuit');
 const validSeries=c.power&&c.switchClosed&&meterRange!==null&&Math.abs(lampCurrent)>1e-6&&Math.abs(Math.abs(lampCurrent)-Math.abs(meterCurrent))<1e-6&&Math.abs(Math.abs(meterCurrent)-Math.abs(sourceCurrent))<1e-6&&Math.abs(Math.abs(switchCurrent)-Math.abs(sourceCurrent))<1e-6&&!faults.some(f=>f!=='open-circuit');
 return {model:'nonideal',parameters:modelParameters('nonideal'),protected:false,currentKnown:true,lampCurrent,meterCurrent,sourceCurrent,switchCurrent,meterRange,division,nodeV,faults,energized:c.power&&c.voltage>0,validSeries,overrange,reverse,tripRecommended:c.power&&(sourceCurrent>3||overrange||faults.includes('source-short')||faults.includes('meter-across-source')),lampPower:lampCurrent*lampCurrent*c.lampResistance,meterVoltage:V(active)-V('A-')};
}
/** Explicit pedagogic choice; ideal is default, no hidden burden resistance. */
export function modelParameters(config:CircuitConfig|'ideal'|'nonideal'='ideal'):ModelParameters {
 const model=typeof config==='string'?config:config.model??'ideal';
 return model==='nonideal'?{sourceResistance:.5,switchResistance:.02,meterResistance:{A06:.2,A3:.04}}:{sourceResistance:0,switchResistance:0,meterResistance:{A06:0,A3:0}};
}
export const resistances=modelParameters;
export function solveCircuit(input:CircuitConfig):CircuitResult {
 if(input.model==='nonideal')return solveNonideal(input);
 const c=clampConfig(input),wireParent=new Map<Terminal,Terminal>(TERMINALS.map(t=>[t,t]));
 const wroot=(t:Terminal):Terminal=>{const p=wireParent.get(t)!;if(p===t)return t;const r=wroot(p);wireParent.set(t,r);return r};
 for(const w of c.wires)wireParent.set(wroot(w.from),wroot(w.to));
 const used=(t:Terminal)=>c.wires.some(w=>w.from===t||w.to===t),small=used('A06'),large=used('A3');
 const meterRange:0.6|3|null=small&&!large?.6:large&&!small?3:null;
 const division:0.02|0.1|null=meterRange===.6?.02:meterRange===3?.1:null;
 type ZeroEdge={id:'switch'|'small'|'large';a:Terminal;b:Terminal};
 const edges:ZeroEdge[]=[];
 if(c.switchClosed)edges.push({id:'switch',a:wroot('S1'),b:wroot('S2')});
 if(small)edges.push({id:'small',a:wroot('A06'),b:wroot('A-')});
 if(large)edges.push({id:'large',a:wroot('A3'),b:wroot('A-')});
 const zeroParent=new Map<Terminal,Terminal>(TERMINALS.map(t=>[wroot(t),wroot(t)]));
 const zroot=(t:Terminal):Terminal=>{t=wroot(t);const p=zeroParent.get(t)!;if(p===t)return t;const r=zroot(p);zeroParent.set(t,r);return r};
 for(const e of edges)zeroParent.set(zroot(e.a),zroot(e.b));
 const plus=zroot('P+'),minus=zroot('P-'),l1=zroot('L1'),l2=zroot('L2'),voltage=c.power?c.voltage:0;
 const faults:Fault[]=[];
 if(plus===minus)faults.push('source-short');
 if(small&&large)faults.push('both-ranges');
 // Fault topology uses wire + closed switch equivalence, but not the meter itself.
 const logical=(t:Terminal)=>c.switchClosed&&wroot('S1')!==wroot('S2')&&wroot(t)===wroot('S2')?wroot('S1'):wroot(t);
 const samePair=(a:Terminal,b:Terminal,x:Terminal,y:Terminal)=>(logical(a)===logical(x)&&logical(b)===logical(y))||(logical(a)===logical(y)&&logical(b)===logical(x));
 for(const t of ['A06','A3'] as const)if(used(t)){
  if(samePair(t,'A-','P+','P-')&&!faults.includes('meter-across-source'))faults.push('meter-across-source');
  if(samePair(t,'A-','L1','L2')&&!faults.includes('meter-parallel-lamp'))faults.push('meter-parallel-lamp');
 }
 if(l1===l2)faults.push('lamp-bypassed');
 const components=new Set(TERMINALS.map(zroot)),potential=new Map<Terminal,number>([...components].map(t=>[t,0]));
 if(plus!==minus){potential.set(plus,voltage);potential.set(minus,0);
  // One lamp is the only nonzero passive resistance. Unanchored end assumes
  // the anchored end's potential, giving zero current through a dangling branch.
  const anchored=(n:Terminal)=>n===plus||n===minus;
  if(anchored(l1)&&!anchored(l2))potential.set(l2,potential.get(l1)!);
  if(anchored(l2)&&!anchored(l1))potential.set(l1,potential.get(l2)!);
 }
 const V=(t:Terminal)=>potential.get(zroot(t))??0;
 let lampCurrent=(V('L1')-V('L2'))/c.lampResistance;
 let sourceCurrent=l1===plus?lampCurrent:l2===plus?-lampCurrent:0;
 const divergence=new Map<Terminal,number>(TERMINALS.map(t=>[wroot(t),0]));
 const add=(t:Terminal,v:number)=>divergence.set(wroot(t),(divergence.get(wroot(t))??0)+v);
 add('L1',lampCurrent);add('L2',-lampCurrent);add('P+',-sourceCurrent);add('P-',sourceCurrent);
 const edgeCurrents=new Map<string,number>();let ambiguous=false;
 for(const e of edges){const reachable=new Set<Terminal>([e.a]),queue=[e.a];while(queue.length){const n=queue.shift()!;for(const other of edges){if(other===e)continue;const next=other.a===n?other.b:other.b===n?other.a:null;if(next!==null&&!reachable.has(next)){reachable.add(next);queue.push(next)}}}
  if(reachable.has(e.b)){ambiguous=true;edgeCurrents.set(e.id,0)}else{const total=[...reachable].reduce((n,t)=>n+(divergence.get(t)??0),0);edgeCurrents.set(e.id,-total||0)}
 }
 if(ambiguous)faults.push('ideal-loop');
 // Incompatible ideal voltage-source/zero-ohm path has no finite solution.
 // Cyclic parallel zero-ohm branch currents are non-unique. Never invent a
 // large finite resistor or pretend an isolation sentinel is a measured zero.
 const protectedState=voltage>0&&(plus===minus||ambiguous),currentKnown=!protectedState;
 let meterCurrent=(edgeCurrents.get('small')??0)+(edgeCurrents.get('large')??0),switchCurrent=edgeCurrents.get('switch')??0;
 if(protectedState){lampCurrent=0;sourceCurrent=0;meterCurrent=0;switchCurrent=0;for(const n of potential.keys())potential.set(n,0)}
 const reverse=currentKnown&&meterCurrent< -1e-7,overrange=currentKnown&&meterRange!==null&&Math.abs(meterCurrent)>meterRange+1e-8;
 if(reverse)faults.push('reverse');if(overrange)faults.push('overrange');
 if(voltage>0&&!protectedState&&Math.abs(sourceCurrent)<1e-7)faults.push('open-circuit');
 const validSeries=currentKnown&&c.power&&c.switchClosed&&meterRange!==null&&Math.abs(lampCurrent)>1e-6&&Math.abs(Math.abs(lampCurrent)-Math.abs(meterCurrent))<1e-7&&Math.abs(Math.abs(sourceCurrent)-Math.abs(meterCurrent))<1e-7&&Math.abs(Math.abs(switchCurrent)-Math.abs(meterCurrent))<1e-7&&faults.length===0;
 return {model:'ideal',parameters:modelParameters('ideal'),protected:protectedState,currentKnown,lampCurrent,meterCurrent,sourceCurrent,switchCurrent,meterRange,division,nodeV:Object.fromEntries(TERMINALS.map(t=>[t,V(t)])) as Record<Terminal,number>,faults,energized:c.power&&c.voltage>0&&!protectedState,validSeries,overrange,reverse,tripRecommended:protectedState||c.power&&overrange,lampPower:lampCurrent*lampCurrent*c.lampResistance,meterVoltage:V(small?'A06':'A3')-V('A-')};
}
export const STANDARD_WIRES:Wire[]=[['P+','S1'],['S2','A3'],['A-','L1'],['L2','P-']].map(([from,to],i)=>({id:`w${i+1}`,from:from as Terminal,to:to as Terminal}));
export const DEFAULT_CONFIG:CircuitConfig={wires:[],voltage:3,lampResistance:10,power:false,switchClosed:false,model:'ideal'};
