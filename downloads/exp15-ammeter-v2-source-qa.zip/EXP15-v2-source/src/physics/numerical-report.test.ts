import {it,expect} from 'vitest';
import {mkdirSync,writeFileSync} from 'node:fs';
import {solveCircuit,STANDARD_WIRES,type CircuitConfig,type Wire} from './circuit';
const base:CircuitConfig={model:'nonideal',wires:STANDARD_WIRES,power:true,switchClosed:true,voltage:3,lampResistance:10};
const w=(from:Wire['from'],to:Wire['to'],i:number):Wire=>({id:'n'+i,from,to});
it('writes actual numerically verified scientific case evidence',()=>{
 const low=STANDARD_WIRES.map(w=>({...w,to:w.to==='A3'?'A06' as const:w.to}));
 const reverse=STANDARD_WIRES.map(w=>({...w,from:w.from==='A-'?'A3' as const:w.from,to:w.to==='A3'?'A-' as const:w.to}));
 const definitions=[
  {name:'standard-high',cfg:base,expected:3/10.56,field:'meterCurrent' as const},
  {name:'standard-low',cfg:{...base,wires:low},expected:3/10.72,field:'meterCurrent' as const},
  {name:'error-reverse',cfg:{...base,wires:reverse},expected:-3/10.56,field:'meterCurrent' as const},
  {name:'error-across-source',cfg:{...base,wires:[w('P+','A06',1),w('A-','P-',2)]},expected:3/.7,field:'meterCurrent' as const},
  {name:'error-parallel-lamp',cfg:{...base,wires:[w('P+','S1',1),w('S2','L1',2),w('L2','P-',3),w('L1','A06',4),w('A-','L2',5)]},expected:(3/((10*.2)/(10+.2)+.5+.02))*(10/(10+.2)),field:'meterCurrent' as const},
  {name:'extreme-6V-2ohm-low',cfg:{...base,wires:low,voltage:6,lampResistance:2},expected:6/2.72,field:'meterCurrent' as const},
  {name:'extreme-source-short',cfg:{...base,wires:[w('P+','P-',1)],voltage:6},expected:12,field:'sourceCurrent' as const},
  {name:'open-switch',cfg:{...base,switchClosed:false},expected:0,field:'sourceCurrent' as const},
  {name:'repeat-high-after-low',cfg:base,expected:3/10.56,field:'meterCurrent' as const},
 ];
 const idealDefinitions=[{name:'ideal-standard-high',cfg:{...base,model:'ideal' as const},expected:.3},{name:'ideal-standard-low',cfg:{...base,model:'ideal' as const,wires:low},expected:.3},{name:'ideal-reverse',cfg:{...base,model:'ideal' as const,wires:reverse},expected:-.3},{name:'ideal-extreme-finite-overrange',cfg:{...base,model:'ideal' as const,wires:low,voltage:6,lampResistance:2},expected:3},{name:'ideal-repeat-high-after-low',cfg:{...base,model:'ideal' as const},expected:.3}];
 const cases=definitions.map(c=>{const actual=solveCircuit(c.cfg),error=Math.abs(actual[c.field]-c.expected);expect(error,c.name).toBeLessThan(1e-9);return{case:c.name,config:c.cfg,expected:{[c.field]:c.expected},actual,errorA:error,passed:error<1e-9}});
 expect(cases[0].actual).toEqual(cases[8].actual);
 const idealCases=idealDefinitions.map(c=>{const actual=solveCircuit(c.cfg),error=Math.abs(actual.meterCurrent-c.expected);expect(error,c.name).toBeLessThan(1e-9);return{case:c.name,config:c.cfg,expected:{meterCurrent:c.expected},actual,errorA:error,passed:error<1e-9}});
 const protectionCases=[{name:'ideal-short-protection',cfg:{...base,model:'ideal' as const,wires:[w('P+','P-',1)]}},{name:'ideal-across-source-protection',cfg:{...base,model:'ideal' as const,wires:[w('P+','A06',1),w('A-','P-',2)]}},{name:'ideal-parallel-lamp-protection',cfg:{...base,model:'ideal' as const,wires:[w('P+','S1',1),w('S2','L1',2),w('L2','P-',3),w('L1','A06',4),w('A-','L2',5)]}}].map(c=>{const actual=solveCircuit(c.cfg);expect(actual.protected,c.name).toBe(true);expect(actual.currentKnown,c.name).toBe(false);return{case:c.name,config:c.cfg,expected:{currentKnown:false,protected:true,currentBeforeIsolation:'no finite ideal voltage-source solution'},actual,passed:true}});
 mkdirSync('evidence',{recursive:true});writeFileSync('evidence/numerical-cases.json',JSON.stringify({model:'Explicit ideal zero-ohm graph/KCL plus nonideal conductance; fixed lamp; SI',passed:true,toleranceA:1e-9,cases:[...idealCases,...protectionCases,...cases]},null,2));
});
