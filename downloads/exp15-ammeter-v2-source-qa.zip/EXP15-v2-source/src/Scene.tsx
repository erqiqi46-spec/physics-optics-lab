import React,{Suspense,useEffect,useMemo,useRef,useState} from 'react';
import {Canvas,useFrame,useThree,type ThreeEvent} from '@react-three/fiber';
import {OrbitControls,Environment,Html,Line,useGLTF} from '@react-three/drei';
import * as THREE from 'three';
import assetURL from './assets/instruments.glb?url';
import {useLab} from './lesson/store';
import {solveCircuit,type Terminal} from './physics/circuit';
import {terminalWorld,terminals,curvePoints,deviceNames,type Device} from './interaction/layout';
import './scene-v2.css';
export type SceneProps={quality:string;camera:string;selected:Device|null;onSelect:(d:Device)=>void;pending:Terminal|null;onTerminal:(t:Terminal)=>void;onRemoveWire:(id:string)=>void;meterObserved:number;statsRef:React.MutableRefObject<any>};
const DEVICES:Device[]=['power','switch','lamp','meter'];
const needleAngle=(current:number,range:number)=>(-150+120*Math.max(-.10,Math.min(1.07,current/range)))*Math.PI/180;
function faceTexture(){const c=document.createElement('canvas');c.width=1024;c.height=700;const x=c.getContext('2d')!;x.fillStyle='#f1f0dc';x.fillRect(0,0,1024,700);const cx=512,cy=574;x.strokeStyle='#1d2932';x.fillStyle='#162b33';x.lineWidth=5;
 for(let i=0;i<=30;i++){const a=(-150+i*4)*Math.PI/180;const major=i%5===0,r=major?385:399; x.beginPath();x.moveTo(cx+Math.cos(a)*r,cy+Math.sin(a)*r);x.lineTo(cx+Math.cos(a)*425,cy+Math.sin(a)*425);x.stroke();if(major){x.font='bold 44px sans-serif';x.textAlign='center';x.fillText((i/10).toFixed(i===0?0:1),cx+Math.cos(a)*470,cy+Math.sin(a)*470+15);x.fillStyle='#286477';x.font='32px sans-serif';x.fillText((i*.02).toFixed(1),cx+Math.cos(a)*329,cy+Math.sin(a)*329+10);x.fillStyle='#162b33'}}
 x.font='bold 110px sans-serif';x.textAlign='center';x.fillText('A',512,405);x.font='24px sans-serif';x.fillText('0–3 A  /  0–0.6 A',512,650);x.fillText('DC · 30 DIVISIONS',512,80);const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return t}
function PassiveLabel({children,position,className=''}:{children:React.ReactNode;position:[number,number,number];className?:string}){
 return <Html center position={position} zIndexRange={[18,0]} wrapperClass="v2-pass-through" style={{pointerEvents:'none'}}><span className={'v2-scene-label '+className}>{children}</span></Html>
}
function Instrument({device,props,controls}:{device:Device;props:SceneProps;controls:React.RefObject<any>}){
 const gltf=useGLTF(assetURL),session=useLab(s=>s.sessions[s.mode]),place=useLab(s=>s.place),invalidate=useThree(s=>s.invalidate);
 const [dragging,setDragging]=useState(false),drag=useRef<{id:number;dx:number;dz:number;lastAt:number;last:[number,number]|null}|null>(null);
 const plane=useMemo(()=>new THREE.Plane(new THREE.Vector3(0,1,0),0),[]),hit=useMemo(()=>new THREE.Vector3(),[]);
 const model=useMemo(()=>{
  const n=gltf.scene.getObjectByName(({power:'Power',switch:'Switch',lamp:'Lamp',meter:'Meter'} as const)[device])!.clone(true);
  n.traverse(o=>{if(!(o instanceof THREE.Mesh))return;o.castShadow=props.quality!=='low';o.receiveShadow=props.quality!=='low';
   if(o.name==='LampGlass'&&props.quality!=='high')o.material=new THREE.MeshStandardMaterial({name:'Fast transparent bulb glass',color:'#cce4eb',metalness:.04,roughness:.18,transparent:true,opacity:.21,depthWrite:false});
   else o.material=(o.material as THREE.Material).clone();
  });return n;
 },[gltf,device,props.quality]);
 const glow=useMemo(()=>{const list:THREE.Mesh[]=[];model.traverse(o=>{if(o instanceof THREE.Mesh&&(o.name.toLowerCase().includes('filament')||o.name==='LampGlass'))list.push(o)});return list},[model]);
 useEffect(()=>()=>model.traverse(o=>{if(o instanceof THREE.Mesh)(o.material as THREE.Material).dispose()}),[model]);
 const cfgKey=JSON.stringify(session.cfg),q=useMemo(()=>solveCircuit(session.cfg),[cfgKey]);
 useEffect(()=>{for(const o of glow){const m=o.material as THREE.MeshStandardMaterial;m.emissive.set('#ffc359');m.emissiveIntensity=Math.min(o.name==='LampGlass'?.25:8,q.lampPower*(o.name==='LampGlass'?.12:7));m.toneMapped=o.name==='LampGlass'}invalidate()},[glow,q.lampPower,invalidate]);
 const p=session.positions[device],editable=session.started&&!session.submitted&&!session.frozen&&session.inventoryConfirmed;
 const down=(e:ThreeEvent<PointerEvent>)=>{e.stopPropagation();props.onSelect(device);if(!editable||!e.ray.intersectPlane(plane,hit))return;
  drag.current={id:e.pointerId,dx:p[0]-hit.x,dz:p[1]-hit.z,lastAt:0,last:null};(e.target as any).setPointerCapture(e.pointerId);if(controls.current)controls.current.enabled=false;setDragging(true);invalidate();
 };
 const move=(e:ThreeEvent<PointerEvent>)=>{const d=drag.current;if(!d||!e.ray.intersectPlane(plane,hit))return;e.stopPropagation();d.last=[hit.x+d.dx,hit.z+d.dz];if(performance.now()-d.lastAt>42){place(device,d.last);d.lastAt=performance.now()}invalidate()};
 const up=(e:ThreeEvent<PointerEvent>)=>{const d=drag.current;if(!d)return;e.stopPropagation();if(d.last)place(device,d.last);drag.current=null;try{(e.target as any).releasePointerCapture(e.pointerId)}catch{}if(controls.current)controls.current.enabled=true;setDragging(false);invalidate()};
 const blade=useMemo(()=>gltf.scene.getObjectByName('Blade')!.clone(true),[gltf]),dial=useMemo(faceTexture,[]);useEffect(()=>()=>dial.dispose(),[dial]);
 const angle=needleAngle(q.currentKnown===false?0:props.meterObserved,q.meterRange??3),center:[number,number,number]=[0,.087,.02408],tip:[number,number,number]=[.084*Math.cos(angle),.087,.02408+.084*Math.sin(angle)];
 const control=(e:ThreeEvent<PointerEvent>)=>{e.stopPropagation();props.onSelect(device);if(device==='power')useLab.getState().togglePower();if(device==='switch')useLab.getState().toggleSwitch();invalidate()};
 const body:{[key in Device]:{size:[number,number,number];y:number}}={power:{size:[.246,.068,.184],y:.053},switch:{size:[.216,.018,.116],y:.015},lamp:{size:[.154,.018,.154],y:.015},meter:{size:[.244,.064,.212],y:.043}};
 return <group name={'apparatus-'+device} position={[p[0],0,p[1]]}>
  <group onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up}>
   <primitive object={model}/>
   {device==='switch'&&<group position={[-.075,.035,0]} rotation={[0,0,session.cfg.switchClosed?0:.65]}><primitive object={blade}/></group>}
   {device==='meter'&&<><mesh rotation={[-Math.PI/2,0,0]} position={[0,.0846,-.022]}><planeGeometry args={[.21,.144]}/><meshBasicMaterial map={dial}/></mesh><Line points={[center,tip]} color="#cf3d36" lineWidth={2}/><mesh position={center} rotation={[Math.PI/2,0,0]}><cylinderGeometry args={[.004,.004,.003,16]}/><meshStandardMaterial color="#1e3038" metalness={.8} roughness={.22}/></mesh></>}
   <mesh name={'body-hit-'+device} position={[0,body[device].y,0]}><boxGeometry args={body[device].size}/><meshBasicMaterial transparent opacity={0} colorWrite={false} depthWrite={false}/></mesh>
  </group>
  {(device==='power'||device==='switch')&&<mesh name={'control-hit-'+device} position={device==='power'?[.086,.117,-.032]:[.05,.057,0]} onPointerDown={control}><sphereGeometry args={[device==='power'?.021:.025,12,8]}/><meshBasicMaterial transparent opacity={0} colorWrite={false} depthWrite={false}/></mesh>}
  {device==='lamp'&&props.quality!=='low'&&<pointLight position={[0,.13,0]} color="#ffc66b" intensity={Math.min(.35,q.lampPower*.25)} distance={.35} decay={2}/>}
  {(props.selected===device||dragging)&&<mesh rotation={[-Math.PI/2,0,0]} position={[0,.001,0]} raycast={()=>{}}><ringGeometry args={[.132,.137,48]}/><meshBasicMaterial color="#79e6ce" transparent opacity={.7}/></mesh>}
  <PassiveLabel position={[0,.016,device==='meter'?.20:.16]} className={props.selected===device?'selected':''}>{deviceNames[device]}{dragging?' · 移动中':''}</PassiveLabel>
  {device==='power'&&<PassiveLabel position={[0,.122,-.043]} className="v2-source-readout">{session.cfg.voltage.toFixed(1)} V · {session.cfg.power?'ON':'OFF'}</PassiveLabel>}
 </group>
}
function Rig({props}:{props:SceneProps}){
 const session=useLab(s=>s.sessions[s.mode]),controls=useRef<any>(null),{camera,gl,size,scene,invalidate}=useThree();
 const tween=useRef<{from:THREE.Vector3;to:THREE.Vector3;at:number}|null>(null);
 const cfgKey=JSON.stringify(session.cfg),positionsKey=JSON.stringify(session.positions),q=useMemo(()=>solveCircuit(session.cfg),[cfgKey]);
 useEffect(()=>{const dest=props.camera==='top'?new THREE.Vector3(0,1.43,.001):props.camera==='meter'?new THREE.Vector3(session.positions.meter[0],.47,session.positions.meter[1]+.24):props.camera==='front'?new THREE.Vector3(0,.56,1.10):new THREE.Vector3(.73,.76,.91);
  tween.current={from:camera.position.clone(),to:dest,at:performance.now()};if(controls.current)controls.current.target.set(props.camera==='meter'?session.positions.meter[0]:0,.035,props.camera==='meter'?session.positions.meter[1]:0);invalidate();
 },[props.camera]);
 useEffect(()=>{gl.shadowMap.autoUpdate=false;gl.shadowMap.needsUpdate=true;invalidate()},[cfgKey,positionsKey,props.quality,props.meterObserved,props.pending,props.selected,invalidate,gl]);
 const sample=useRef({at:performance.now(),frames:0,fps:0,total:0});
 useFrame(()=>{
  const t=tween.current;if(t&&controls.current?.enabled){const a=Math.min(1,(performance.now()-t.at)/650);camera.position.lerpVectors(t.from,t.to,a*a*(3-2*a));if(a===1)tween.current=null;else invalidate()}
  const v=sample.current;v.frames++;v.total++;const now=performance.now();if(now-v.at>1000){v.fps=v.frames*1000/(now-v.at);v.frames=0;v.at=now}
  const targets:Record<string,{x:number;y:number}>={};const project=(id:string,p:THREE.Vector3)=>{p.project(camera);targets[id]={x:(p.x+1)*size.width/2,y:(1-p.y)*size.height/2}};
  for(const id of terminals)project(id,new THREE.Vector3(...terminalWorld(id,session.positions)));
  for(const d of DEVICES){const p=session.positions[d];project(d,new THREE.Vector3(p[0],.05,p[1]));if(d==='power'||d==='switch')project('control-'+d,new THREE.Vector3(p[0]+(d==='power'?.086:.05),d==='power'?.117:.057,p[1]+(d==='power'?-.032:0)))}
  props.statsRef.current={ready:!!scene.getObjectByName('apparatus-meter'),renderMode:'demand',fps:v.fps,frames:v.total,drawCalls:gl.info.render.calls,triangles:gl.info.render.triangles,geometries:gl.info.memory.geometries,textures:gl.info.memory.textures,targets,camera:camera.position.toArray(),needleAngle:needleAngle(q.currentKnown===false?0:props.meterObserved,q.meterRange??3),currentKnown:q.currentKnown!==false,protected:q.protected===true,renderer:gl.getContext().getParameter(gl.getContext().RENDERER),objects:Object.fromEntries(DEVICES.map(d=>{const o=scene.getObjectByName('apparatus-'+d);return[d,o?o.getWorldPosition(new THREE.Vector3()).toArray():null]}))};
 });
 const restoreControls=(e:ThreeEvent<PointerEvent>)=>{e.stopPropagation();try{(e.target as any).releasePointerCapture(e.pointerId)}catch{}if(controls.current)controls.current.enabled=true;invalidate()};
 return <>
  <color attach="background" args={['#0c1820']}/><ambientLight intensity={props.quality==='low'?1.4:.8}/><hemisphereLight args={['#c4dfeb','#182c33',1.35]}/>
  <directionalLight position={[1,2,1]} intensity={2.2} castShadow={props.quality!=='low'} shadow-mapSize={props.quality==='high'?[1024,1024]:[512,512]} shadow-camera-left={-1} shadow-camera-right={1} shadow-camera-top={1} shadow-camera-bottom={-1} shadow-bias={-.0003}/><pointLight position={[-.6,.6,-.4]} color="#62b9bf" intensity={.35}/>
  {props.quality!=='low'&&<Environment resolution={32} frames={1}><mesh scale={4} position={[0,3,0]} rotation={[Math.PI/2,0,0]}><planeGeometry/><meshBasicMaterial color="#b6ccd7"/></mesh><mesh scale={[2,1,1]} position={[-3,1,0]} rotation={[0,Math.PI/2,0]}><planeGeometry/><meshBasicMaterial color="#486d77"/></mesh></Environment>}
  <mesh receiveShadow position={[0,-.018,0]}><boxGeometry args={[1.55,.036,.96]}/><meshStandardMaterial color="#172b34" roughness={.48} metalness={.38}/></mesh><mesh position={[0,-.042,0]}><boxGeometry args={[1.60,.018,1.01]}/><meshStandardMaterial color="#101b23" roughness={.3} metalness={.7}/></mesh><gridHelper args={[1.5,30,'#31505d','#203946']} position={[0,.0001,0]}/>
  {DEVICES.map(device=><Instrument key={device} device={device} props={props} controls={controls}/>)}
  {terminals.map(t=>{const pos=terminalWorld(t,session.positions),selected=props.pending===t;return <group key={t} position={pos}>
   <mesh name={'terminal-hit-'+t} onPointerDown={e=>{e.stopPropagation();if(controls.current)controls.current.enabled=false;(e.target as any).setPointerCapture(e.pointerId);props.onTerminal(t);invalidate()}} onPointerUp={restoreControls} onPointerCancel={restoreControls}><sphereGeometry args={[.022,12,8]}/><meshBasicMaterial transparent opacity={0} colorWrite={false} depthWrite={false}/></mesh>
   <mesh raycast={()=>{}}><sphereGeometry args={[selected?.014:.010,12,8]}/><meshStandardMaterial color={selected?'#ffe697':t.includes('-')?'#547482':'#cd6262'} emissive={selected?'#b38224':'#000'} emissiveIntensity={selected?.8:0}/></mesh>
   {selected&&<mesh rotation={[-Math.PI/2,0,0]} position={[0,.004,0]} raycast={()=>{}}><ringGeometry args={[.024,.030,40]}/><meshBasicMaterial color="#ffe697" transparent opacity={.95} depthTest={false}/></mesh>}
   <PassiveLabel position={[0,.030,.002]} className={'v2-terminal '+(selected?'selected':'')}>{t==='A06'?'0.6 A':t==='A3'?'3 A':t}{selected?' ●':''}</PassiveLabel>
  </group>})}
  {session.cfg.wires.map((w,i)=><Line key={w.id} points={curvePoints(terminalWorld(w.from,session.positions),terminalWorld(w.to,session.positions))} color={['#e9a96d','#76d1d2','#b0a3e3','#94cba5','#df8c9c'][i%5]} lineWidth={3} onPointerDown={e=>{e.stopPropagation();props.onRemoveWire(w.id);invalidate()}}/>)}
  <OrbitControls ref={controls} makeDefault minDistance={.30} maxDistance={2.8} maxPolarAngle={Math.PI/2.07} enableDamping onChange={()=>invalidate()} target={[0,.035,0]}/>
 </>
}
function LabScene(props:SceneProps){return <div className="scene-canvas v2-scene-canvas" data-testid="scene"><Canvas frameloop="demand" shadows={props.quality!=='low'} dpr={props.quality==='low'?.7:props.quality==='medium'?.9:Math.min(1.35,window.devicePixelRatio)} camera={{position:[.73,.76,.91],fov:43,near:.01,far:20}} gl={{antialias:props.quality!=='low',preserveDrawingBuffer:true,powerPreference:'high-performance'}}><Suspense fallback={null}><Rig props={props}/></Suspense></Canvas><span className="scene-caption">拖动器材本体 · 点击接线柱连接 · 点刀闸或电源旋钮操作 · 空白处旋转/缩放</span></div>}
// Ignore parent clock-only renders; physical state subscriptions above still invalidate.
export default React.memo(LabScene,(a,b)=>a.quality===b.quality&&a.camera===b.camera&&a.selected===b.selected&&a.pending===b.pending&&a.meterObserved===b.meterObserved&&a.statsRef===b.statsRef);
