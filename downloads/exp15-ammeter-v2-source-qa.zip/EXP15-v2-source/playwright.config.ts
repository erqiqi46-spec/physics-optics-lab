import { defineConfig } from '@playwright/test';
const run = process.env.EXP15_BROWSER_RUN;
const suffix = run ? '-' + run.replace(/[^a-zA-Z0-9_-]/g, '') : '';
export default defineConfig({
  testDir: 'tests',
  outputDir: 'evidence/browser-replays' + suffix,
  timeout: 240000,
  expect: { timeout: 20000 },
  workers: 1,
  fullyParallel: false,
  retries: 0,
  reporter: [['list'], ['json', { outputFile: 'evidence/browser-results' + suffix + '.json' }]],
  use: {
    viewport: { width: 1440, height: 1000 },
    headless: true,
    trace: 'on',
    video: 'on',
    screenshot: 'only-on-failure',
    launchOptions: {
      args: ['--no-sandbox', '--enable-precise-memory-info', '--enable-unsafe-swiftshader', '--use-gl=angle', '--use-angle=swiftshader'],
    },
  },
});
