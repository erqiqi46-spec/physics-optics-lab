@echo off
cd /d "%~dp0"
node.exe server.mjs
pause
