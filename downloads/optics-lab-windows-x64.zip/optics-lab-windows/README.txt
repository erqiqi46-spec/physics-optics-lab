﻿Windows x64 本地实验室

1. 将整个 ZIP 解压到普通文件夹。不要在压缩包内直接启动。
2. 双击 START.cmd。
3. 默认浏览器会打开本机实验室。使用期间保持命令窗口开启，结束时关闭它。

已包含官方 Node.js v22.16.0 win-x64 程序，无需安装 Node.js 或 npm，无需访问托管域名。只监听 127.0.0.1，使用自动分配的空闲端口。
仅支持 Windows x64；未在真实 Windows 主机执行，服务逻辑在 Linux Node 验证。
外部字体请求已移除，使用本机后备字体。需要支持 WebGL2 的 Edge 或 Chrome。

源码、测试、截图和科学报告在 source-and-reports.zip 中。
