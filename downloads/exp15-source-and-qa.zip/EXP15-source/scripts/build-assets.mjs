import * as T from 'three';
import {GLTFExporter} from 'three/examples/jsm/exporters/GLTFExporter.js';
import {mergeGeometries,mergeVertices} from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import {writeFile,mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
if(!globalThis.FileReader)globalThis.FileReader=class{readAsArrayBuffer(b){b.arrayBuffer().then(x=>{this.result=x;this.onloadend?.()})}readAsDataURL(b){b.arrayBuffer().then(x=>{this.result=`data:${b.type};base64,${Buffer.from(x).toString('base64')}`;this.onloadend?.()})}};
const scene=new T.Group();scene.name='EXP15_AuthoredElectricalApparatus';
const material=(name,color,metalness,roughness)=>new T.MeshStandardMaterial({name,color,metalness,roughness});
const steel=material('Brushed stainless fasteners','#aabdc2',.87,.25),aluminium=material('Anodized aluminium trim','#738f99',.9,.35),dark=material('Midnight instrument enamel','#203946',.45,.34),rubber=material('Anti slip rubber','#101c23',0,.85),ivory=material('Ivory meter bezel','#d6ddcb',.17,.34),black=material('Black moulded terminal insulation','#17232a',.05,.4),red=material('Red moulded terminal insulation','#ae4245',.05,.35),brass=material('Brass contacts','#c7a65d',.85,.24),copper=material('Copper blade','#b87b50',.86,.28),mint=material('Mint engraved inlay','#75c8b5',.2,.4),ceramic=material('Glazed lamp socket ceramic','#d7d6c8',.12,.24),filament=material('Tungsten filament','#b4a288',.83,.3);
const glass=new T.MeshPhysicalMaterial({name:'Clear bulb glass',color:'#dceef1',metalness:0,roughness:.07,transmission:.92,thickness:.001,ior:1.47,transparent:true,opacity:.72});
const parts={};for(const n of['Power','Switch','Blade','Lamp','Meter']){parts[n]=new T.Group();parts[n].name=n;scene.add(parts[n])}
let serial=0;
function mesh(g,geo,m,n,p=[0,0,0],r=[0,0,0]){const x=new T.Mesh(geo,m);x.name=n+'_'+(++serial);x.position.set(...p);x.rotation.set(...r);x.castShadow=true;x.receiveShadow=true;g.add(x);return x}
function shape(w,h,r){const s=new T.Shape(),x=-w/2,y=-h/2;s.moveTo(x+r,y);s.lineTo(x+w-r,y);s.quadraticCurveTo(x+w,y,x+w,y+r);s.lineTo(x+w,y+h-r);s.quadraticCurveTo(x+w,y+h,x+w-r,y+h);s.lineTo(x+r,y+h);s.quadraticCurveTo(x,y+h,x,y+h-r);s.lineTo(x,y+r);s.quadraticCurveTo(x,y,x+r,y);return s}
function plate(g,w,d,h,r,m,n,p=[0,0,0]){const geo=new T.ExtrudeGeometry(shape(w,d,r),{depth:h,bevelEnabled:true,bevelSegments:3,steps:1,bevelSize:Math.min(.00065,h*.15),bevelThickness:Math.min(.00065,h*.15),curveSegments:10});geo.translate(0,0,-h/2);geo.rotateX(-Math.PI/2);return mesh(g,geo,m,n,p)}
function cyl(g,ra,rb,h,m,n,p=[0,0,0],r=[0,0,0],segments=40){return mesh(g,new T.CylinderGeometry(ra,rb,h,segments),m,n,p,r)}
function tor(g,ra,t,m,n,p=[0,0,0],r=[Math.PI/2,0,0]){return mesh(g,new T.TorusGeometry(ra,t,7,40),m,n,p,r)}
function screw(g,p,rad=.003){cyl(g,rad,rad,.0015,steel,'Machined captive screw',p,[0,0,0],24);mesh(g,new T.BoxGeometry(rad*1.4,.00022,.00055),black,'Recessed screw slot',[p[0],p[1]+.00085,p[2]])}
function feet(g,w,d){for(const x of[-w,w])for(const z of[-d,d])cyl(g,.010,.012,.007,rubber,'Rubber isolator',[x,.0036,z])}
function post(g,x,y,z,col){cyl(g,.012,.013,.008,col,'Insulating terminal shoulder',[x,y-.014,z]);cyl(g,.008,.008,.019,col,'Binding post knurled cap',[x,y-.002,z]);cyl(g,.003,.003,.024,brass,'Conducting terminal pin',[x,y-.005,z]);tor(g,.0082,.0008,steel,'Terminal cap chamfer',[x,y+.007,z]);for(let k=0;k<20;k++){const a=k*Math.PI*2/20;cyl(g,.00045,.00045,.014,col,'Knurled post rib',[x+Math.cos(a)*.008,y-.002,z+Math.sin(a)*.008],[0,0,0],5)}cyl(g,.0023,.0023,.002,black,'Banana socket opening',[x,y+.009,z])}
function bar(g,w,h,p,m=aluminium,n='Engraved panel line'){return mesh(g,new T.BoxGeometry(w,.0003,h),m,n,p)}
// Source unit: folded housing, panel, vent apertures, guard, rubber feet and binding posts.
const pw=parts.Power;feet(pw,.102,.071);plate(pw,.25,.19,.088,.012,dark,'Radiused source housing',[0,.052,0]);plate(pw,.248,.188,.002,.011,aluminium,'Housing machined top lip',[0,.097,0]);plate(pw,.237,.176,.002,.010,dark,'Inset source control deck',[0,.099,0]);
for(const x of[-.107,.107])for(const z of[-.077,.077])screw(pw,[x,.101,z],.0023);
plate(pw,.115,.041,.002,.004,black,'Recessed DC display',[0,.101,-.045]);plate(pw,.102,.029,.0008,.003,mint,'LCD substrate',[0,.1025,-.045]);
for(let i=0;i<10;i++)bar(pw,.030,.0018,[-.095,.101,-.052+i*.006],black,'Cooling vent recess');
cyl(pw,.015,.015,.014,black,'Voltage selection rotary knob',[.086,.108,-.032]);tor(pw,.015,.0008,steel,'Rotary dial metal lip',[.086,.1155,-.032]);bar(pw,.002,.011,[.086,.116,-.036],mint,'Dial index');
post(pw,-.07,.105,.07,red);post(pw,.07,.105,.07,black);
for(let i=0;i<4;i++)bar(pw,.010,.0012,[-.015+i*.010,.101,.017],ivory,'Source maker mark');
// Switch: insulated base, bolted supports, copper fork, separate pivoting knife blade.
const sw=parts.Switch;feet(sw,.084,.041);plate(sw,.22,.12,.016,.012,dark,'Moulded switch mounting base',[0,.016,0]);plate(sw,.208,.108,.002,.010,aluminium,'Switch base trim',[0,.025,0]);plate(sw,.199,.099,.002,.009,dark,'Recessed switch top',[0,.0265,0]);
for(const x of[-.091,.091])for(const z of[-.042,.042])screw(sw,[x,.028,z],.0022);
for(const x of[-.075,.075]){post(sw,x,.035,0,x<0?black:red);plate(sw,.022,.037,.004,.003,brass,'Switch terminal foot',[x,.029,0]);for(const z of[-.013,.013])screw(sw,[x,.032,z],.0018)}
for(const z of[-.006,.006])plate(sw,.016,.003,.019,.0015,copper,'Copper fixed blade clip',[.075,.044,z]);
cyl(sw,.0035,.0035,.026,steel,'Blade pivot axle',[-.075,.041,0],[Math.PI/2,0,0]);
const bl=parts.Blade;plate(bl,.154,.009,.0028,.003,copper,'Copper knife switch moving blade',[.075,0,0]);plate(bl,.039,.025,.009,.006,black,'Insulated switch handle',[.124,.005,0]);for(let i=0;i<6;i++)bar(bl,.002,.020,[.110+i*.004,.010,0],rubber,'Handle grip grooves');cyl(bl,.0045,.0045,.013,brass,'Blade pivot bushing',[0,0,0],[Math.PI/2,0,0]);
// Lamp: ceramic socket, brass screw threads, real curved glass envelope and filament.
const la=parts.Lamp;feet(la,.059,.059);plate(la,.16,.16,.018,.016,dark,'Lamp insulated pedestal',[0,.016,0]);plate(la,.151,.151,.002,.014,aluminium,'Lamp base edge trim',[0,.026,0]);plate(la,.142,.142,.002,.012,dark,'Lamp top mounting inset',[0,.028,0]);
for(const x of[-.057,.057])for(const z of[-.057,.057])screw(la,[x,.030,z],.0022);
post(la,-.061,.040,.045,black);post(la,.061,.040,.045,red);
cyl(la,.040,.045,.013,ceramic,'Ceramic socket flange',[0,.036,-.012]);cyl(la,.027,.036,.027,ceramic,'Ceramic lamp holder',[0,.054,-.012]);for(const x of[-.030,.030])screw(la,[x,.044,-.012],.0024);
cyl(la,.018,.018,.025,brass,'Lamp screw shell',[0,.078,-.012]);for(let i=0;i<7;i++)tor(la,.0182,.0008,steel,'Lamp threaded contact',[0,.069+i*.003,-.012]);
const profile=[new T.Vector2(.014,.086),new T.Vector2(.017,.094),new T.Vector2(.027,.104),new T.Vector2(.038,.119),new T.Vector2(.041,.139),new T.Vector2(.036,.156),new T.Vector2(.023,.170),new T.Vector2(.001,.176)];const bulb=mesh(la,new T.LatheGeometry(profile,48),glass,'LampGlass',[0,0,-.012]);bulb.name='LampGlass';
for(const x of[-.009,.009])cyl(la,.0006,.0006,.037,steel,'Bulb filament support',[x,.112,-.012]);
const curve=[];for(let i=0;i<=80;i++){const q=i/80;curve.push(new T.Vector3(-.009+q*.018,.133+Math.sin(q*Math.PI*16)*.0015,-.012+Math.cos(q*Math.PI*16)*.0015))}mesh(la,new T.TubeGeometry(new T.CatmullRomCurve3(curve),100,.00045,5,false),filament,'FilamentCoil');
// Ammeter: bevelled instrument enclosure, recessed ivory face bezel and protected posts.
const me=parts.Meter;feet(me,.102,.084);plate(me,.25,.22,.069,.016,dark,'Meter insulated precision casing',[0,.043,0]);plate(me,.248,.218,.003,.015,aluminium,'Meter chamfered bezel frame',[0,.079,0]);plate(me,.233,.185,.003,.013,ivory,'Ivory recessed scale surround',[0,.081,-.009]);plate(me,.213,.147,.001,.010,black,'Dynamic scale face recess',[0,.083,-.022]);
for(const x of[-.106,.106])for(const z of[-.083,.068])screw(me,[x,.084,z],.0021);
for(const[x,m]of[[-.085,black],[0,red],[.085,red]])post(me,x,.060,.12,m);
// Mechanical zero adjuster below gauge; upper face itself is rendered as a live canvas in Scene.
cyl(me,.006,.006,.003,steel,'Mechanical zero adjuster',[0,.085,.061]);bar(me,.007,.001,[0,.0868,.061],black,'Zero adjuster slot');
for(const x of[-.111,.111])for(let i=0;i<6;i++)bar(me,.005,.002,[x,.083,-.046+i*.011],black,'Meter bezel side detail');
// Merge by material only within each independently manipulable root; retain named glass child.
scene.updateMatrixWorld(true);const counts={};
for(const[name,g]of Object.entries(parts)){const buckets=new Map(),preserve=[];let count=0;g.traverse(o=>{if(!o.isMesh)return;count++;if(o.name==='LampGlass'){preserve.push(o.clone());return}let geo=o.geometry.clone().applyMatrix4(o.matrixWorld);if(!geo.index)geo=mergeVertices(geo);const arr=buckets.get(o.material)||[];arr.push(geo);buckets.set(o.material,arr)});g.clear();for(const[m,geos]of buckets)mesh(g,mergeGeometries(geos,false),m,name+' '+m.name);for(const o of preserve)g.add(o);g.userData={unit:'metre',originalComponents:count};counts[name]=count}
scene.updateMatrixWorld(true);const glb=await new GLTFExporter().parseAsync(scene,{binary:true,onlyVisible:true});await mkdir(root+'src/assets',{recursive:true});await writeFile(root+'src/assets/instruments.glb',Buffer.from(glb));
const inventory={asset:'instruments.glb',source:'Original compound apparatus authored by build-assets.mjs; no stock placeholders or remote resources',unit:'metre',bytes:glb.byteLength,roots:{},totalTriangles:0,totalMeshes:0,terminals:{Power:{'P+':[-.07,.105,.07],'P-':[.07,.105,.07]},Switch:{S1:[-.075,.035,0],S2:[.075,.035,0]},Lamp:{L1:[-.061,.040,.045],L2:[.061,.040,.045]},Meter:{'A-':[-.085,.060,.12],A06:[0,.060,.12],A3:[.085,.060,.12]}},blade:{pivot:[-.075,.035,0],axis:'z',closedRadians:0,openRadians:Math.PI/5},meterFace:{center:[0,.084,-.022],width:.210,height:.144,normal:'+Y'}};
for(const[name,g]of Object.entries(parts)){let meshes=0,triangles=0;g.traverse(o=>{if(o.isMesh){meshes++;triangles+=(o.geometry.index?.count||o.geometry.attributes.position.count)/3}});const box=new T.Box3().setFromObject(g);inventory.roots[name]={meshes,triangles,authoredComponents:counts[name],min:box.min.toArray(),max:box.max.toArray()};inventory.totalMeshes+=meshes;inventory.totalTriangles+=triangles}
await writeFile(root+'src/assets/asset-inventory.json',JSON.stringify(inventory,null,2));console.log(JSON.stringify(inventory,null,2));
