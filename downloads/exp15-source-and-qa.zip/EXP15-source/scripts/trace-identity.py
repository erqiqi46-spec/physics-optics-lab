from pathlib import Path
import hashlib,zipfile,json
R=Path(__file__).resolve().parents[1];html=(R/'dist/index.html').read_bytes();sha=hashlib.sha256(html).hexdigest();checks=[]
for p in list((R/'test-results').rglob('trace.zip'))+list((R/'evidence/runs/mobile-rerun').rglob('trace.zip')):
 with zipfile.ZipFile(p)as z:
  matches=[]
  for n in z.namelist():
   info=z.getinfo(n)
   if n.startswith('resources/') and info.file_size==len(html):
    body=z.read(n);h=hashlib.sha256(body).hexdigest();matches.append(h);checks.append({'trace':str(p.relative_to(R)),'sha256':h,'matchesFinal':h==sha})
  if not matches:raise Exception('No final HTML response in trace '+str(p))
assert checks and all(x['matchesFinal']for x in checks)
(R/'evidence/trace-build-identity.json').write_text(json.dumps({'finalSha256':sha,'allMatched':True,'traceChecks':checks},indent=2));print('Trace HTML identities checked',len(checks),sha)
