/** Run only after browser correctness suite: sequential cold contexts, no fake clock, no video. */
import {chromium} from '@playwright/test';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const html=resolve('dist/index.html'),url=pathToFileURL(html).href;
const sha=createHash('sha256').update(readFileSync(html)).digest('hex');
mkdirSync('evidence/screenshots',{recursive:true});
const browser=await chromium.launch({headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader','--use-gl=angle','--use-angle=swiftshader','--enable-precise-memory-info']});
const results=[];
try{
 for(const quality of ['low','medium','high']){
  const ctx=await browser.newContext({viewport:{width:1440,height:1000}});await ctx.setOffline(true);
  try{
   const page=await ctx.newPage();const errors=[],remoteRequests=[];page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))remoteRequests.push(r.url())});
   await page.goto(url);await page.getByTestId('start-mode-free').click();await page.getByTestId('start').click();await page.getByLabel('画质').selectOption('low');
   await page.waitForFunction(()=>window.__EXP15?.read().stats.frames>3);
   for(const d of ['power','switch','lamp','meter'])await page.getByTestId('inspect-'+d).click();await page.getByTestId('confirm-inventory').click();
   for(const d of ['power','switch','lamp','meter']){await page.getByTestId('inspect-'+d).click();await page.getByTestId('place-selected').click()}
   for(let i=0;i<5;i++)await page.getByTestId('zero-minus').click();
   for(const [a,b]of [['P+','S1'],['S2','A06'],['A-','L1'],['L2','P-']]){await page.getByTestId('terminal-'+a).click();await page.getByTestId('terminal-'+b).click()}
   await page.getByTestId('power').click();await page.getByTestId('switch').click();
   const condition=await page.evaluate(()=>window.__EXP15.read());
   if(!condition.result.validSeries||condition.session.zeroOffset!==0||condition.result.meterRange!==.6)throw Error('Profile setup is not actual calibrated low-range series circuit');
   await page.evaluate(()=>{const canvas=document.querySelector('canvas'),gl=canvas.getContext('webgl2');let calls=0,triangles=0;const frames=[];for(const name of ['drawArrays','drawElements','drawArraysInstanced','drawElementsInstanced']){const original=gl[name].bind(gl);gl[name]=(...args)=>{calls++;if(args[0]===gl.TRIANGLES){const count=name.startsWith('drawArrays')?args[2]:args[1];const instances=name.endsWith('Instanced')?args.at(-1):1;triangles+=count/3*instances}return original(...args)}}function record(){if(calls){frames.push({at:performance.now(),calls,triangles});if(frames.length>120)frames.shift()}calls=0;triangles=0;requestAnimationFrame(record)}requestAnimationFrame(record);window.__EXP15_GPU_FRAMES=frames});
   const initialFrames=condition.stats.frames;await page.getByLabel('画质').selectOption(quality);await page.waitForFunction(n=>window.__EXP15.read().stats.frames>n+5,initialFrames);await page.getByTestId('camera-overview').click();await page.locator('.scene-area').scrollIntoViewIfNeeded();await page.waitForTimeout(3000);
   const gpu=await page.locator('canvas').first().evaluate(canvas=>{const gl=canvas.getContext('webgl2')||canvas.getContext('webgl');if(!gl)return null;const ext=gl.getExtension('WEBGL_debug_renderer_info');return{renderer:ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),vendor:ext?gl.getParameter(ext.UNMASKED_VENDOR_WEBGL):gl.getParameter(gl.VENDOR),version:gl.getParameter(gl.VERSION)}});
   const samples=[];
   for(let i=0;i<6;i++){await page.waitForTimeout(1000);samples.push(await page.evaluate(()=>{const d=window.__EXP15.read(),m=performance.memory,g=window.__EXP15_GPU_FRAMES?.at(-1);return{at:performance.now(),...d.stats,rendererInfoCalls:d.stats.drawCalls,rendererInfoTriangles:d.stats.triangles,drawCalls:g?.calls,triangles:g?.triangles,heap:m?{used:m.usedJSHeapSize,total:m.totalJSHeapSize,limit:m.jsHeapSizeLimit}:null}}))}
   if(errors.length||remoteRequests.length)throw Error('Browser error or remote request during offline profile: '+JSON.stringify({errors,remoteRequests}));
   const values=samples.map(s=>s.fps).sort((a,b)=>a-b),last=samples.at(-1);
   if(!Number.isFinite(last.drawCalls)||last.drawCalls<20)throw Error('Actual GL draw counter invalid');
   if(values.some(v=>!Number.isFinite(v)||v<=0))throw Error('Invalid FPS sample');
   const row={quality,width:1440,height:1000,devicePixelRatio:await page.evaluate(()=>devicePixelRatio),renderer:gpu?.renderer??last.renderer,gpu,fpsMedian:(values[2]+values[3])/2,fpsMin:values[0],fpsMax:values.at(-1),drawCalls:last.drawCalls,triangles:last.triangles,geometries:last.geometries,textures:last.textures,jsHeapUsedMiB:last.heap?last.heap.used/1048576:null,jsHeapTotalMiB:last.heap?last.heap.total/1048576:null,samples,errors,remoteRequests,condition:{voltage:condition.session.cfg.voltage,lampResistance:condition.session.cfg.lampResistance,meterRange:condition.result.meterRange,current:condition.result.meterCurrent}};
   results.push(row);await page.screenshot({path:`evidence/screenshots/quality-${quality}.png`,fullPage:true});console.log('PROFILE',quality,row.fpsMedian.toFixed(2),'FPS',row.drawCalls,'calls',row.jsHeapUsedMiB?.toFixed(1),'MiB JS heap');
  }finally{await ctx.close()}
 }
}finally{await browser.close()}
writeFileSync('evidence/performance.json',JSON.stringify({htmlSha256:sha,platform:process.platform,browser:'Chromium '+browser.version()+' headless Linux; ANGLE SwiftShader software rendering requested; see actual unmasked renderer per quality',method:'Offline file:// actual UI apparatus inspection, placement, zero adjustment, low-range series circuit; fixed3V/10ohm condition. Each quality uses a fresh sequential context; setup is done at low quality then selected quality renders at least6frames and 3s warmup and six 1s native useFrame samples, no video/no fake clock. Drawing calls/triangles are actual WebGL drawArrays/Elements (including instanced) invocation counts per rAF frame, including offscreen passes. renderer.info raw counts retained separately because environment passes can reset them. JS heap excludes GPU VRAM and native renderer memory. This is not real Windows or phone hardware certification.',results},null,2));
