from pathlib import Path
import zipfile,json
root=Path(__file__).resolve().parents[1]
UNDEFINED=object()
def dec(x,refs=None):
 if refs is None:refs={}
 if not isinstance(x,dict):return x
 if 'ref'in x:return refs[x['ref']]
 if 'o'in x:
  out={}
  if 'id'in x:refs[x['id']]=out
  for i in x['o']:
   v=dec(i['v'],refs)
   if v is not UNDEFINED:out[i['k']]=v
  return out
 if 'a'in x:
  out=[]
  if 'id'in x:refs[x['id']]=out
  out.extend(dec(i,refs)for i in x['a']);return out
 for k in ['n','s','b']:
  if k in x:return x[k]
 if x.get('v')=='undefined':return UNDEFINED
 if x.get('v')in ['null','NaN','Infinity','-Infinity']:return None
 return x
spec=[('教学',['01-teach-normal','02-repeat-and-records','03-teach-returned']),('自由模式',['04-error-reverse','05-error-parallel','05b-error-across-source','06-error-live-rewire','07-extreme-overrange']),('真实3D',['08-bidirectional']),('考核独立',['09-exam-before-submit','10-exam-result']),('考核倒计时',['11-exam-timeout'])]
result=[];provenance=[]
for pattern,names in spec:
 p=next((root/'test-results').glob('*'+pattern+'*/trace.zip'));shots=[]
 with zipfile.ZipFile(p) as z:
  for resource in z.namelist():
   if not resource.endswith('.trace'):continue
   rows=[json.loads(l)for l in z.read(resource).decode().splitlines()]
   for i,x in enumerate(rows):
    if x.get('type')!='before' or x.get('method')!='screenshot':continue
    done=next(j for j in range(i+1,len(rows))if rows[j].get('type')=='after' and rows[j].get('callId')==x['callId'])
    for a in rows[done+1:]:
     if a.get('type')=='after' and 'value'in a.get('result',{}):
      st=dec(a['result']['value'])
      if isinstance(st,dict) and all(k in st for k in ['mode','session','stats','targets']):shots.append(st);provenance.append({'case':names[len(shots)-1],'trace':str(p.relative_to(root)),'screenshotCallId':x['callId'],'readCallId':a['callId']});break
 assert len(shots)==len(names),(pattern,len(shots),len(names))
 result += [{'case':n,'state':st}for n,st in zip(names,shots)]
mobile=[v for v in json.loads((root/'evidence/browser-case-evidence.json').read_text()) if v['case'] in ['12-mobile-touch','13-desktop-720']];assert [v['case']for v in mobile]==['12-mobile-touch','13-desktop-720'];result+=mobile
(root/'evidence/browser-case-evidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));(root/'evidence/snapshot-recovery-provenance.json').write_text(json.dumps({'reason':'Targeted rerun snapshot array overwrote file; exact first5 final-build raw read-only values restored from trace, not regenerated','entries':provenance,'mobileCases':'browser-mobile-rerun.json'},ensure_ascii=False,indent=2));print('Restored',len(result),'actual browser snapshots')

(root/'evidence/cases').mkdir(exist_ok=True)
for row in result:(root/'evidence/cases'/f"{row['case']}.json").write_text(json.dumps(row,ensure_ascii=False,indent=2))
