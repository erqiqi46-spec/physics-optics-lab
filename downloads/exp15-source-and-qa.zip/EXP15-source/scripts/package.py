from pathlib import Path
import zipfile,json,hashlib,shutil
R=Path(__file__).resolve().parents[1];O=Path('/workspace/output');O.mkdir(exist_ok=True)
q=json.loads((R/'evidence/final-acceptance.json').read_text());html=R/'dist/index.html'
assert q['passed'] and hashlib.sha256(html.read_bytes()).hexdigest()==q['htmlSha256']
name='EXP-15-用电流表测量电流.html';shutil.copyfile(html,O/name)
with zipfile.ZipFile(O/'EXP15-ammeter-offline.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p,n in [(html,name),(R/'README.md','使用说明.md'),(R/'source-map.md','source-map.md'),(R/'qa-report.md','qa-report.md'),(R/'src/physics/model-notes.md','物理模型与边界.md'),(R/'THIRD_PARTY_LICENSES.md','THIRD_PARTY_LICENSES.md')]:z.write(p,n)
with zipfile.ZipFile(O/'EXP15-source-and-QA.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in R.rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(R)
  if any(k in ['node_modules','test-results','.git','runs','mobile-replay','playwright-report','history','replay']for k in rel.parts):continue
  if p.suffix=='.webm':continue
  if p.name.endswith('.tsbuildinfo') or p.name=='smoke.mjs' or '__pycache__'in rel.parts:continue
  z.write(p,'EXP15-source/'+str(rel))
with zipfile.ZipFile(O/'EXP15-browser-replays.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in (R/'evidence/replay').glob('*.webm'):z.write(p,p.name)
for stale in O.glob('EXP15-traces-part*.zip'):stale.unlink()
trace_groups=[];group=[];total=0
for p in sorted((R/'evidence/replay').glob('*.zip')):
 if group and total+p.stat().st_size>30_000_000:trace_groups.append(group);group=[];total=0
 group.append(p);total+=p.stat().st_size
if group:trace_groups.append(group)
for i,group in enumerate(trace_groups,1):
 with zipfile.ZipFile(O/f'EXP15-traces-part{i}.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for p in group:z.write(p,p.name)
for f in ['qa-report.md','source-map.md']:shutil.copyfile(R/f,O/('EXP15-'+f))
m={}
for p in O.iterdir():
 if p.is_file() and (p.name.startswith('EXP15-') or p.name.startswith('EXP-15-')):
  if p.suffix=='.zip':
   with zipfile.ZipFile(p)as z:assert z.testzip()is None
  p.chmod(0o644);m[p.name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(O/'EXP15-delivery-manifest.json').write_text(json.dumps(m,indent=2,ensure_ascii=False));print(json.dumps(m,indent=2,ensure_ascii=False))
