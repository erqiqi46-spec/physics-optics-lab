import {readFileSync,writeFileSync,existsSync,mkdirSync,copyFileSync,statSync} from 'node:fs';import{createHash}from'node:crypto';
const j=p=>JSON.parse(readFileSync(p,'utf8'));const unit=j('evidence/unit-results.json'),browser=j('evidence/browser-results.json'),perf=j('evidence/performance.json'),assets=j('src/assets/asset-validation.json'),visual=j('evidence/visual-review.json');const sha=createHash('sha256').update(readFileSync('dist/index.html')).digest('hex');
if(!unit.success||unit.numFailedTests||browser.stats.skipped||browser.stats.flaky||browser.stats.interrupted||browser.errors.length||!assets.passed||!visual.passed||perf.htmlSha256!==sha||perf.results.some(r=>r.errors?.length))throw Error('Acceptance gate failed');
const reports=[browser];if(existsSync('evidence/browser-mobile-rerun.json'))reports.push(j('evidence/browser-mobile-rerun.json'));const selected=new Map();function walk(s){for(const x of s.specs||[])for(const t of x.tests)if(t.status==='expected')selected.set(x.title,{title:x.title,status:t.status,results:t.results});for(const s1 of s.suites||[])walk(s1)}for(const report of reports){if(Date.parse(report.stats.startTime)<statSync('dist/index.html').mtimeMs-1000||report.errors.length||report.stats.interrupted)throw Error('Stale or interrupted verification run');for(const s of report.suites)walk(s)}const cases=[...selected.values()];if(cases.length!==6||cases.some(c=>c.results.at(-1).status!=='passed'))throw Error('Six cases not passed');const identity=j('evidence/trace-build-identity.json');if(!identity.allMatched||identity.finalSha256!==sha)throw Error('Trace identity mismatch');
mkdirSync('evidence/replay',{recursive:true});for(const[i,c]of cases.entries())for(const a of c.results.at(-1).attachments||[])if(a.path&&existsSync(a.path)&&(a.name==='video'||a.name==='trace'))copyFileSync(a.path,`evidence/replay/${i+1}-${a.name}.${a.name==='video'?'webm':'zip'}`);
const nums=j('evidence/numerical-cases.json'),cross=j('evidence/browser-numerical-validation.json');if(!cross.passed)throw Error('Browser analytical validation failed');if(!nums.passed)throw Error('Numerical evidence failed');const md=`# EXP-15 用电流表测量电流 · 验收报告

仅验收EXP-15，不代表21项全系列完成。最终HTML SHA256：\`${sha}\`。

## 教材依据

用户提供人教九年级全一册2022版，第十五章第4节，正文56—57页 / PDF63—64页，实验“用电流表测量电流”。教材与扩展的逐项界限见source-map.md，未取得任何湖南官方原始评分表，全部评价为自定义模拟评分（非官方）。

## 测试轮次说明

${reports.length>1?'首轮5项通过、手机触摸用例失败，保留原始browser-results.json。定位到移动浏览器把细小灯泡附近的触摸吸附到端子按钮后，改用无遮挡的电流表表身执行真实触摸，单独复测该用例并通过，见browser-mobile-rerun.json；应用HTML不变，轨迹响应体哈希一致。这里汇总两轮逐案结果，不声称首轮全绿。':'使用完整单轮通过的浏览器报告。'}

## 实际验证结果

- Vitest：${unit.numPassedTests}/${unit.numTotalTests}项通过；物理网络、极端参数、反接/并联/短接、机械边界、模式隔离、轨迹评分、试触真实闭合和安全归位。
- Playwright：${cases.length}/6类案例在同一构建上逐案通过；在真实Chromium、file://、context.setOffline(true)运行，实际按钮/鼠标/触摸，没有写状态测试接口。原始JSON与逐案操作快照在evidence/，trace另包EXP15-traces-part1.zip、part2.zip，实际视频另包EXP15-browser-replays.zip；均从evidence/replay/已验证文件打包。
- HTML轨迹中的响应体SHA核对一致，未用旧构建冒充最终结果。没有远程CDN和预录动画。
- 器材GLB：原创细化多部件PBR，${assets.triangles??'见资产报告'}三角形；结构/有限顶点/命名/尺度验证见src/assets/asset-validation.json。程序化原创资产不是扫描/CAD计量认证。

|自动化案例|真实现象截图（evidence/screenshots/）|核验|
|---|---|---|
|规范流程、教材两处接表、重复测量、提交归位|01-teach-normal.png、02-repeat-and-records.png、03-teach-returned.png|3行手填记录、实际重新接线与相同条件恢复|
|反接错误|04-error-reverse.png|网络计算负表电流，指针反偏|
|并联错误|05-error-parallel.png|表支路改变，不是虚构读数|
|直接跨源|05b-error-across-source.png|实际低量程跨电源两极，源内阻限流但严重超量程|
|带电换线|06-error-live-rewire.png|实际事件记录、保护断电、重检连接|
|极端参数|07-extreme-overrange.png|6 V、2 Ω、0.6 A端，实际超量程；表针止挡不能当读数|
|双向联动|08-bidirectional.png|鼠标拖动→位置面板、面板→GLB世界坐标；3D端子接线→2D导线；冻结、重置和模式隔离|
|完整考核|09-exam-before-submit.png、10-exam-result.png|默认15分钟、隐藏答案、独立接线读数、归位后100分轨迹；非官方|
|超时与恢复|11-exam-timeout.png|1分钟测试，刷新保留清点和截止时间，超时封存|
|手机与720p|12-mobile-touch.png、13-desktop-720.png|原生CDP touchStart/Move/End拖动；键盘接线；整页无横向溢出|

## 数值与测量差异

节点法使用源内阻0.5 Ω、开关0.02 Ω、3 A表0.04 Ω或0.6 A表0.2 Ω。3 V / 10 Ω规范回路：3 A档0.284090909 A，0.6 A档0.279850746 A。两量程不同是仪表负载效应，不是随机漂移。同一量程下只改变电表在串联回路中的位置，电流不变。仅低量程电表跨源、无其他负载的数值案例得到4.285714286 A（浏览器错误演示保留灯泡支路，故表电流约4.225 A，并非同一拓扑），6 V / 2 Ω低量程为2.205882353 A，均越量程。精确结果及参考偏差见numerical-cases.json；实际浏览器每个关键接线的电流还与独立串并联解析式交叉核验，见browser-numerical-validation.json。

0.6 A档估读0.28 A对模型偏差约+0.000149254 A；1.5 V时估读0.14 A偏差+0.000074627 A。3 A档按0.1 A分度估读，不能把面板三位理论数当作仪表分辨率。记录判定容许半个最小格附近的估读偏差，未宣称真实电表精度。相同条件重复无随机漂移，零位由实际调零状态决定；指针范围外无正常读数。

## 性能实测

${perf.browser??perf.environment??'Linux Chromium，软件渲染'}。1440×1000，关闭视频录像，实际UI建立回路后暖机，6个1秒采样窗；原始帧数、FPS、WebGL调用计数、renderer.info原始值和JS heap见performance.json。软件渲染结果不能代表Windows GPU性能。

|画质|FPS中位数（最小—最大）|绘图调用/帧|三角形/帧|JS heap使用MiB|
|---|---:|---:|---:|---:|
${perf.results.map(r=>`|${r.quality}|${r.fpsMedian.toFixed(1)} (${r.fpsMin.toFixed(1)}—${r.fpsMax.toFixed(1)})|${r.drawCalls}|${r.triangles}|${Number.isFinite(r.jsHeapUsedMiB)?r.jsHeapUsedMiB.toFixed(1):'未提供'}|`).join('\n')}

JS heap不是GPU显存或整机内存；drawCalls与三角形数是对实际WebGL drawArrays/drawElements及实例绘制函数逐帧计数，包含离屏通道，不是操作系统GPU计数器。Environment会重置renderer.info，故该原始值另存但不用作总调用数；首次统计诊断另保存在performance-initial-renderer-info.json。低档简化DPR/阴影，保留器材和计算；高档在软件GPU上慢时应改用低档。

## 限制与后续工作

- 手机上细小器材应先双指放大再操作，邻近端子按钮可能触发浏览器的触摸目标吸附。
- 实测Linux Chromium及模拟手机触摸，未完成Windows Chrome/Edge、真实Android/iOS硬件实测。目标支持现代WebGL2浏览器，不能虚称全部设备通过。
- 采用准静态电阻网络，定值灯丝近似，不模拟温度、热惯性、导线电阻、表头磁电惯性及真实烧毁。灯泡亮度由实际I²R定性驱动，表针使用机械行程限制。异常只在安全虚拟低压模型呈现。
- 原创GLB不是实物扫描，不宣称电影级成品。实际课堂学习效果与评分需教师试用和复核；结论文字只用基础规则检查，不能作正式考试自动阅卷结论。
- 评分安全项重点检查带电换线/调整和归位；反接、并联及超量程使该次读数无效，但不模拟器材损坏的单独罚分。若需按每类故障分别扣分，需扩展并经教师审核规则。
- 本机存储恢复不是服务器收卷；无身份认证、防作弊、防篡改。JSON只导出不导入，移动文件可能改变本地存储域。
- 正常断开开关也会显示开路反馈，只说明当前无闭合回路，不表示器材损坏。
- 开发诊断期间有主动中止的非最终测试轮次，不计入本报告；本报告仅汇总最终构建逐案通过的6类结果，并保留首轮与复测记录。
- 分批源代码和可运行集成快照见batches/；未保存的早期HTML不虚构。最终验收以dist和上述哈希为准。
- 建议后续增加热电灯丝、指针动力学、真实保护曲线、读数视差及跨设备性能测试。

最终判定：本报告所列数值、双向交互、三种模式与独立离线加载案例通过；设备与教学效果限制如上。
`;
writeFileSync('qa-report.md',md);writeFileSync('evidence/final-acceptance.json',JSON.stringify({passed:true,htmlSha256:sha,unitPassed:unit.numPassedTests,browserPassed:cases.length,verificationReports:reports.length,initialUnexpected:browser.stats.unexpected,cases:cases.map(c=>({title:c.title,status:c.status})),scope:'EXP15 only; Linux Chromium offline; emulated phone touch; Windows hardware not certified'},null,2));console.log('ACCEPTED',sha);
