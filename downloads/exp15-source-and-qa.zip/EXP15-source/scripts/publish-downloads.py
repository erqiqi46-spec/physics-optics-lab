"""Publish validated EXP15 delivery to the user's established public downloads folder.
Requires gh authentication. Never prints credentials. Does not change other project files.
"""
import pathlib,json,subprocess,base64,tempfile,hashlib,urllib.request,time
R=pathlib.Path(__file__).resolve().parents[1];O=pathlib.Path('/workspace/output');q=json.loads((R/'evidence/final-acceptance.json').read_text());assert q['passed']
repo='erqiqi46-spec/physics-optics-lab';results=[]
files=[('EXP15-ammeter-offline.zip','exp15-ammeter-offline.zip'),('EXP15-source-and-QA.zip','exp15-source-and-qa.zip'),('EXP15-browser-replays.zip','exp15-browser-replays.zip'),('EXP15-qa-report.md','exp15-qa-report.md')]
files += [(p.name,p.name.lower()) for p in sorted(O.glob('EXP15-traces-part*.zip'))]
for name,remote in files:
 p=O/name;data=p.read_bytes();assert len(data)<99_000_000
 endpoint=f'repos/{repo}/contents/downloads/{remote}'
 old=subprocess.run(['gh','api',endpoint],capture_output=True,text=True)
 payload={'message':'Deliver validated EXP-15 ammeter offline laboratory: '+remote,'branch':'main','content':base64.b64encode(data).decode()}
 if old.returncode==0:
  previous=json.loads(old.stdout)
  gitsha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  if previous['sha']==gitsha:
   url=previous['download_url']
   with urllib.request.urlopen(url,timeout=120)as response:existing=response.read()
   assert hashlib.sha256(existing).digest()==hashlib.sha256(data).digest()
   results.append({'file':name,'url':url,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'unchanged':True,'downloadVerified':True});print('VERIFIED_UNCHANGED',remote,len(data),flush=True);continue
  payload['sha']=previous['sha']
 with tempfile.NamedTemporaryFile(mode='w',prefix='exp15-upload-',suffix='.json',delete=False,dir='/workspace')as f:json.dump(payload,f);tmp=pathlib.Path(f.name)
 try:
  r=subprocess.run(['gh','api','--method','PUT',endpoint,'--input',str(tmp)],capture_output=True,text=True)
  if r.returncode:raise RuntimeError(r.stderr)
  x=json.loads(r.stdout);url=x['content']['download_url'];downloaded=None
  for attempt in range(4):
   try:
    with urllib.request.urlopen(url+'?v='+x['commit']['sha'][:12],timeout=120)as response:downloaded=response.read()
    if hashlib.sha256(downloaded).digest()==hashlib.sha256(data).digest():break
   except Exception:
    if attempt==3:raise
   time.sleep(2)
  assert downloaded is not None and hashlib.sha256(downloaded).digest()==hashlib.sha256(data).digest()
  results.append({'file':name,'url':url,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'commit':x['commit']['sha'],'downloadVerified':True});print('VERIFIED',remote,len(data),flush=True)
 finally:tmp.unlink(missing_ok=True)
(R/'evidence/published-downloads.json').write_text(json.dumps(results,indent=2));(O/'EXP15-download-links.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
