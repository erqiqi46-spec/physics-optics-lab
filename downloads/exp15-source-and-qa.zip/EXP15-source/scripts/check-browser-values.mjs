import{readFileSync,writeFileSync}from'node:fs';
const cases=JSON.parse(readFileSync('evidence/browser-case-evidence.json','utf8'));const checks=[];
function check(name,actual,expected,tolerance=1e-8){const error=Math.abs(actual-expected);checks.push({name,actual,expected,error,tolerance,passed:Number.isFinite(error)&&error<=tolerance})}
const find=n=>{const c=cases.find(x=>x.case===n);if(!c)throw Error('Missing browser case '+n);return c.state};
const low=3/(.5+.02+10+.2);check('normative browser low-range current',find('01-teach-normal').result.meterCurrent,low);
check('reverse browser low-range current',find('04-error-reverse').result.meterCurrent,-low);
const parallelR=1/(1/10+1/.2),parallelSource=3/(.5+.02+parallelR),parallelV=parallelSource*parallelR;
check('parallel browser source current',find('05-error-parallel').result.sourceCurrent,parallelSource);check('parallel browser meter current',find('05-error-parallel').result.meterCurrent,parallelV/.2);
const acrossV=3/(1+.5*(1/.2+1/10.02));check('across-source with retained lamp branch',find('05b-error-across-source').result.meterCurrent,acrossV/.2);
check('extreme actual6V2ohm lowrange',find('07-extreme-overrange').result.meterCurrent,6/(.5+.02+2+.2));
for(const n of ['03-teach-returned','10-exam-result']){const v=find(n);for(const r of v.session.rows){const expected=r.cfg.voltage/(.5+.02+r.cfg.lampResistance+(r.range===.6?.2:.04));check(`${n} row${r.id} stored model`,r.expected.current,expected);check(`${n} row${r.id} independently estimated reading`,r.current,expected,r.division*.51)}}
const passed=checks.length>0&&checks.every(c=>c.passed);writeFileSync('evidence/browser-numerical-validation.json',JSON.stringify({passed,checks,maxAnalyticErrorA:Math.max(...checks.filter(c=>c.tolerance===1e-8).map(c=>c.error))},null,2));if(!passed)throw Error('Browser analytical checks failed');console.log('Browser analytical and reading checks passed',checks.length);
