import type {Terminal} from '../physics/circuit';
export type Device='power'|'switch'|'lamp'|'meter';
export const homes:Record<Device,[number,number]>={power:[-.48,.30],switch:[-.18,.30],lamp:[.15,.30],meter:[.46,.30]};
export const desks:Record<Device,[number,number]>={power:[-.43,-.18],switch:[-.27,.10],lamp:[.18,-.18],meter:[.30,.16]};
export const deviceNames:Record<Device,string>={power:'低压直流电源',switch:'开关',lamp:'小灯泡',meter:'双量程电流表'};
export const terminalDevice:Record<Terminal,Device>={'P+':'power','P-':'power','S1':'switch','S2':'switch','L1':'lamp','L2':'lamp','A-':'meter','A06':'meter','A3':'meter'};
export const terminalLocal:Record<Terminal,[number,number,number]>={'P+':[-.07,.105,.07],'P-':[.07,.105,.07],S1:[-.075,.035,0],S2:[.075,.035,0],L1:[-.061,.040,.045],L2:[.061,.040,.045],'A-':[-.085,.06,.12],A06:[0,.06,.12],A3:[.085,.06,.12]};
export const terminals=Object.keys(terminalLocal) as Terminal[];
export function terminalWorld(t:Terminal,positions:Record<Device,[number,number]>):[number,number,number]{const p=positions[terminalDevice[t]],l=terminalLocal[t];return[p[0]+l[0],l[1],p[1]+l[2]]}
export function constrainPosition(x:number,z:number):[number,number]{return[Math.round(Math.min(.59,Math.max(-.59,x))*100)/100,Math.round(Math.min(.29,Math.max(-.29,z))*100)/100]}
export function curvePoints(a:[number,number,number],b:[number,number,number]):[number,number,number][]{const out:[number,number,number][]=[];for(let i=0;i<=32;i++){const t=i/32;out.push([a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t+.07*Math.sin(Math.PI*t),a[2]+(b[2]-a[2])*t+.025*Math.sin(Math.PI*t)])}return out}
