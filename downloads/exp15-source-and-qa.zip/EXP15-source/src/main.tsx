import React from 'react';import {createRoot} from 'react-dom/client';import App from './App';import './style.css';
class Boundary extends React.Component<{children:React.ReactNode},{error:string}>{state={error:''};static getDerivedStateFromError(e:Error){return{error:e.message}}render(){return this.state.error?<main><h1>实验载入遇到问题</h1><p>{this.state.error}</p><p>请使用支持WebGL2的新版Chrome或Edge。所有资源已经包含在本地HTML中。</p><button onClick={()=>location.reload()}>重新加载</button></main>:this.props.children}}
createRoot(document.getElementById('root')!).render(<Boundary><App/></Boundary>);
