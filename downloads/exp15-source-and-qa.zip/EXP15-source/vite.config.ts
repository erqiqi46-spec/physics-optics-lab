import {defineConfig} from 'vite';import react from '@vitejs/plugin-react';import {viteSingleFile} from 'vite-plugin-singlefile';
export default defineConfig({plugins:[react(),viteSingleFile()],base:'./',assetsInclude:['**/*.glb'],build:{assetsInlineLimit:10000000,chunkSizeWarningLimit:7000},test:{include:['src/**/*.test.ts'],environment:'node'}} as any);
