# EXP-15 用电流表测量电流

独立可操作的3D低压直流实验。只包含本实验，不包括其他20项。

## Windows离线打开

1. 下载 `EXP15-ammeter-offline.zip`，右键“全部解压”。
2. 用新版Chrome或Edge打开 `EXP-15-用电流表测量电流.html`。
3. 不需要Node、不用启动服务器、不依赖远程CDN。浏览器需要WebGL2；图形驱动不支持时会给出错误说明。

所有脚本、样式、GLB和表盘资源均嵌入HTML。单文件可以复制到U盘再拷贝到其他电脑。首次下载需要网络，打开和操作不需要网络。浏览器本地存储仅用于该电脑该文件路径下恢复，移动/改名文件可能改变恢复位置。

## 规范操作建议（教学扩展，教材依据见source-map.md）

- 选择教学、自由或模拟考核；清点低压源、开关、灯泡、电流表四类器材。
- 点击器材名称选中，点击“放到操作区”，或直接拖动3D器材。已放置的器材不能互相穿叠，也不能离开台面安全边界。
- 在关闭电源、断开开关的状态观察表针，使用调零螺丝将零位调好。
- 点击两个接线柱建立一根导线。可直接点击3D端子，也可用右侧等效端子按钮。点击导线或“拆线”按钮拆除。重复连接同一对端子不会多生成导线。
- 示例大量程串联：P+ → S1；S2 → A3；A− → L1；L2 → P−。导线没有方向，电流方向取决于电源和实际节点。
- 开启低压源、短暂试触，观察指针正偏且未越量程。试触使用实际电路状态闭合约0.8秒后自动断开，慢速设备可能稍延迟。
- 开关和电源均断开后，决定是否把S2—A3换成S2—A06。0—0.6 A是30格，每格0.02 A；0—3 A是30格，每格0.1 A。
- 通电后看真实表针，必要时放大表盘，独立填写量程、分度值和电流。勾选清单仅表示自行核验，评分还会检验真实连接和断电轨迹。
- 教材比较电表在串联回路不同位置的示数：保持电源和灯泡不变，把导线改接为P+—S1，S2—L1，L2—A06，A−—P−。在两种位置读数，比较是否一致。不能仅拖动外观位置冒充改变回路位置。
- 可改变一项电源条件后重复测量，再恢复原条件进行真正的重复。至少记录三次；无须为“多记录”反复点击保存相同数据。
- 填结论并提交；随后真正断电、拆线和逐件归位。评价在归位后展示。

## 三种模式

教学模式按真实清点、摆放、调零、试触、读数、记录、提交和归位推进，提供原因和教师变量冻结。

自由实验不限顺序或时间，开放1.5—6 V源、2—30 Ω定值等效灯泡、安全台面范围，可反复接线和观察错误。撤销恢复配置并强制断电，操作日志仍保留。

模拟考核默认15分钟，可在开始前设置1—60分钟及自定义权重。面板参数只读，允许操作器材和离散电池档位，不允许直接输入电压/电阻绕过实验。先清点，实际串联接线并读数；隐藏理论电流和即时正误。刷新恢复截止时间，切换模式计时仍继续。提交后不能补写或修改实验内容，只能进行整理。评分明确非官方，默认10/30/20/20/10/10；依据真实事件、读数与器材归位。结论文字检查较简单，需教师复核，不能作为正式防作弊考试系统。

模式切换会询问保存或丢弃当前模式记录；各模式相互隔离。重置前确认。JSON导出是操作备份/审查材料，不提供跨文件导入；刷新恢复依赖浏览器本机存储。

## 键盘、触摸和镜头

Tab选择按钮、Enter执行端子连接/器材选中/摆放/归位；右侧端子及控制按钮是与3D共用状态的可访问等效操作。鼠标或原生触摸可拖动器材，拖动时禁用OrbitControls；空白处可旋转、滚轮或双指缩放。提供全景、近景、俯视和电表特写；放大表盘是实时仪表视图，不是录像。高/中/低画质可切换，低档减少DPR和阴影，但保持相同物理模型。

## 科学模型

见 `src/physics/model-notes.md`。理想导线合并节点，灯泡、电流表、开关和电源内阻共同构成电阻网络，使用节点法求解。源内阻0.5 Ω；开关闭合0.02 Ω；0.6 A档内阻0.2 Ω、3 A档0.04 Ω；默认灯丝等效10 Ω。实际电流不按小格四舍五入，学生按刻度估读。相同接线反复测量无随机漂移；两量程的负载效应使实际电流略有差异。

正常断开开关时出现开路提示，只表示当前没有闭合回路，并不表示器材损坏。反接会产生负电流与反偏；并联会改变支路电流；直接跨源和极端条件可能导致超量程。表针受机械止挡限制，止挡不是有效刻度读数。故障只在安全虚拟环境呈现，不模拟真实熔断、器材烧毁或火花。亮度由I²R定性驱动，固定电阻不是实际灯丝温度模型。不要把此装置接到市电。

## 源码运行与测试

Node22+，首次安装依赖需要网络：

```sh
npm ci
npm run dev
npm test
npm run build
npx playwright install chromium
npx playwright test
node scripts/profile.mjs
```

`npm run build` 失败时不能继续把旧dist当新版本验收。浏览器脚本使用真正file://、离线context和实际鼠标/触摸/按钮输入；诊断接口只有只读快照，没有写状态接口。所有GLB由原创脚本再生：`npm run assets`；校验：`node scripts/validate-assets.mjs`。

模块：`src/physics/`计算及测试；`src/lesson/`独立模式/事件/评价；`src/interaction/`坐标/约束；Scene与Diagram只消费同一状态。源码包包含GLB、资产生成脚本、测试、截图、数值与性能报告；不包含node_modules。实际浏览器录像另包 `EXP15-browser-replays.zip`，Playwright轨迹另包 `EXP15-traces-part1.zip` 至 `EXP15-traces-part5.zip`（同一GitHub仓库downloads目录，文件直链为小写文件名）。分包用于避免单个下载过大；每个分包是可独立解压的ZIP，不是分卷压缩。使用 `npx playwright show-trace 1-trace.zip` 打开解压出的轨迹。

## 局限与改进

- Windows Chrome/Edge和真实手机实机未在本次云环境获得；实际验收设备/帧率见qa-report.md，不能据此保证所有低端显卡流畅。
- 灯丝定值等效；未模拟温升、指针惯性磁电结构、非理想导线压降、灯泡寿命或真实热保护。
- 程序化原创GLB细化器材不是实物扫描；不宣称电影级成品。
- 教学有效性和评分还需真实教师/学生课堂验证；评分非湖南官方，不含服务器认证、防篡改或防作弊。
- 后续可增加热电灯丝模型、量程保护曲线、读数视差、教师任务编辑器及更多实机性能测量。

## 本次交付下载入口

离线课件解压即可打开，源码和验收材料可按需下载：

- [离线课件](https://raw.githubusercontent.com/erqiqi46-spec/physics-optics-lab/main/downloads/exp15-ammeter-offline.zip)
- [源码、截图、数值测试与报告](https://raw.githubusercontent.com/erqiqi46-spec/physics-optics-lab/main/downloads/exp15-source-and-qa.zip)
- [实际浏览器操作录像](https://raw.githubusercontent.com/erqiqi46-spec/physics-optics-lab/main/downloads/exp15-browser-replays.zip)
- [Playwright轨迹包1](https://raw.githubusercontent.com/erqiqi46-spec/physics-optics-lab/main/downloads/exp15-traces-part1.zip)
- [Playwright轨迹包2](https://raw.githubusercontent.com/erqiqi46-spec/physics-optics-lab/main/downloads/exp15-traces-part2.zip)
- [Playwright轨迹包3](https://raw.githubusercontent.com/erqiqi46-spec/physics-optics-lab/main/downloads/exp15-traces-part3.zip)
- [Playwright轨迹包4](https://raw.githubusercontent.com/erqiqi46-spec/physics-optics-lab/main/downloads/exp15-traces-part4.zip)
- [Playwright轨迹包5](https://raw.githubusercontent.com/erqiqi46-spec/physics-optics-lab/main/downloads/exp15-traces-part5.zip)

每个轨迹ZIP独立解压即可，包内编号与qa-report.md案例顺序对应，不是需要拼接的分卷文件。
