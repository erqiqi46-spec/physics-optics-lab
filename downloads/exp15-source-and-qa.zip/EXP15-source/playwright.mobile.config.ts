import {defineConfig} from '@playwright/test';import base from './playwright.config';
export default defineConfig({...base,outputDir:'evidence/runs/mobile-rerun',reporter:[['list'],['json',{outputFile:'evidence/browser-mobile-rerun.json'}]]});
